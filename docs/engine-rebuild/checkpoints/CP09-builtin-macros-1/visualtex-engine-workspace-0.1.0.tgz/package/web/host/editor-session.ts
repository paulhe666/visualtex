import type {ClipboardFragment,EngineCommand,EngineReply,EngineResponse} from './protocol';
import type {EditorAction,EditorActionResult,EditorSnapshot} from './editing';
import type {LayoutOptions,LayoutSnapshot,SceneQuery,SceneQueryResult} from './layout';

export interface EngineRuntimePort {dispatch(request:string):string}

/** Persistent core owner for one formula. It contains no DOM. A visible
 * EngineEditorHost may attach/detach repeatedly while this owner preserves the
 * same handle, event sequence, document identities, selection and history. */
export class EngineEditorSessionOwner {
  readonly handle:number;
  private state:EditorSnapshot;
  private sequence=0;
  private parked=false;
  private destroyed=false;
  constructor(private readonly runtime:EngineRuntimePort,documentId:string,source=''){
    const created=this.send({op:'create',documentId,source},'session');
    this.handle=created.handle;
    this.state=this.send({op:'inspectEditor',handle:this.handle},'editor').snapshot;
  }
  private send<K extends EngineReply['kind']>(command:EngineCommand,kind:K):Extract<EngineReply,{kind:K}>{
    const response=JSON.parse(this.runtime.dispatch(JSON.stringify({protocol:1,command}))) as EngineResponse;
    if(response.status==='error')throw new Error(`${response.error.code}: ${response.error.message}`);
    if(response.status!=='ok'||response.result.kind!==kind)throw new Error('Unexpected engine response');
    return response.result as Extract<EngineReply,{kind:K}>;
  }
  private active():void{
    if(this.destroyed)throw new Error('Editor session owner disposed');
    if(this.parked)throw new Error('Editor session owner is parked');
  }
  belongsTo(runtime:EngineRuntimePort):boolean{return runtime===this.runtime;}
  get documentId():string{return this.state.document.documentId;}
  get revision():number{return this.state.document.revision;}
  get isParked():boolean{return this.parked;}
  get isDestroyed():boolean{return this.destroyed;}
  inspect():EditorSnapshot{return structuredClone(this.state);}
  current():EditorSnapshot{return this.state;}
  action(action:EditorAction):EditorActionResult{
    this.active();
    const result=this.send({op:'editorAction',handle:this.handle,expectedRevision:this.state.document.revision,eventSequence:++this.sequence,action},'editorAction').result;
    this.state=result.editor;return result;
  }
  replaceSource(source:string):EditorSnapshot{
    this.active();
    this.send({op:'replaceSource',handle:this.handle,expectedRevision:this.state.document.revision,source},'document');
    this.state=this.send({op:'inspectEditor',handle:this.handle},'editor').snapshot;
    return this.inspect();
  }
  copySelection():ClipboardFragment{
    this.active();
    return this.send({op:'copySelection',handle:this.handle,expectedRevision:this.state.document.revision},'clipboard').fragment;
  }
  layout(options:LayoutOptions,includeSvg:boolean):{sceneToken:number;snapshot:LayoutSnapshot;svg:string|null}{
    this.active();
    const result=this.send({op:'layout',handle:this.handle,expectedRevision:this.state.document.revision,options,includeSvg},'layout');
    return {sceneToken:result.sceneToken,snapshot:result.snapshot,svg:result.svg};
  }
  query(sceneToken:number,query:SceneQuery):SceneQueryResult{
    this.active();
    return this.send({op:'queryScene',handle:this.handle,expectedRevision:this.state.document.revision,sceneToken,query},'sceneQuery').result;
  }
  park():void{
    this.active();
    if(this.state.composition)throw new Error('Finish or cancel pending input before parking the editor session');
    this.send({op:'parkSession',handle:this.handle,expectedRevision:this.state.document.revision},'sessionParked');
    this.parked=true;
  }
  resume():void{
    if(this.destroyed)throw new Error('Editor session owner disposed');
    if(!this.parked)return;
    this.send({op:'resumeSession',handle:this.handle,expectedRevision:this.state.document.revision},'sessionResumed');
    this.parked=false;
    this.state=this.send({op:'inspectEditor',handle:this.handle},'editor').snapshot;
  }
  destroy():void{
    if(this.destroyed)return;
    this.send({op:'destroy',handle:this.handle,expectedRevision:this.state.document.revision},'destroyed');
    this.destroyed=true;this.parked=false;
  }
}
