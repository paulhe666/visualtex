use std::collections::BTreeMap;
use std::sync::Arc;
use unicode_segmentation::UnicodeSegmentation;
use crate::error::{EngineError, EngineResult, ErrorCode};
use crate::fonts::{FontAsset, GlyphShape, MathMetrics};
use crate::model::{AtomClass, Node, NodeKind, MAX_DEPTH, MAX_NODES};
use crate::positions::Position;
use crate::scene::{CaretStop, NodeRegion, Rect, Rule, SceneBuilder};
use crate::session::NodeId;
use super::{Cached, Key, MathStyle};

struct LocalGlyph {font_id:String,shape:Arc<GlyphShape>,x:f64,y:f64,scale:f64}
struct Child {fragment:Arc<Fragment>,x:f64,y:f64}
pub(super) struct Fragment {
    pub node_id:NodeId, role:&'static str,
    pub advance:f64,pub ascent:f64,pub descent:f64,pub italic:f64,pub ink:Option<Rect>,pub accent:Option<f64>,
    glyphs:Vec<LocalGlyph>,rules:Vec<Rect>,carets:Vec<(Position,f64,f64,f64)>,children:Vec<Child>,
    // A phantom retains child geometry for editing but contributes no paint.
    suppress_paint:bool,
    pub column_anchors:Vec<crate::scene::GridColumnAnchor>,
    color:Option<crate::paint::RgbColor>,color_change:Option<crate::paint::RgbColor>,
}
impl Fragment {
    pub fn new(node_id:NodeId,role:&'static str)->Self {Self {node_id,role,advance:0.0,ascent:0.0,descent:0.0,italic:0.0,ink:None,accent:None,glyphs:Vec::new(),rules:Vec::new(),carets:Vec::new(),children:Vec::new(),suppress_paint:false,column_anchors:Vec::new(),color:None,color_change:None}}
    fn add_ink(&mut self,r:Rect) {self.ink=Some(self.ink.map_or(r,|old|old.union(r)));}
    pub fn child(&mut self,fragment:Arc<Fragment>,x:f64,y:f64) {
        self.advance=self.advance.max(x+fragment.advance);self.ascent=self.ascent.max(fragment.ascent-y);self.descent=self.descent.max(fragment.descent+y);
        if let Some(ink)=fragment.ink {self.add_ink(ink.translated(x,y));}
        self.children.push(Child {fragment,x,y});
    }
    pub(super) fn glyph(&mut self,font:&FontAsset,shape:Arc<GlyphShape>,x:f64,y:f64,scale:f64) {
        if let Some([a,b,c,d])=shape.ink {let ink=Rect::new(a*scale+x,b*scale+y,c*scale+x,d*scale+y);self.ascent=self.ascent.max(-ink.y_min);self.descent=self.descent.max(ink.y_max);self.add_ink(ink);}
        self.glyphs.push(LocalGlyph {font_id:font.identity.id.clone(),shape,x,y,scale});
    }
    pub fn translate_x(&mut self,delta:f64) {
        self.advance+=delta;self.ink=self.ink.map(|r|r.translated(delta,0.0));self.accent=self.accent.map(|x|x+delta);
        for glyph in &mut self.glyphs{glyph.x+=delta;}
        for rule in &mut self.rules{*rule=rule.translated(delta,0.0);}
        for (_,x,_,_) in &mut self.carets{*x+=delta;}
        for child in &mut self.children{child.x+=delta;}
        for anchor in &mut self.column_anchors{anchor.x+=delta;}
    }
    pub fn rule(&mut self,r:Rect) {self.ascent=self.ascent.max(-r.y_min);self.descent=self.descent.max(r.y_max);self.add_ink(r);self.rules.push(r);}
}
pub(super) struct Builder<'a> {
    pub math_font:&'a FontAsset,pub text_font:&'a FontAsset,pub math:&'a MathMetrics,
    pub fallback_fonts:&'a [&'a FontAsset],
    pub hashes:&'a BTreeMap<NodeId,[u8;32]>,pub cache:&'a mut BTreeMap<Key,Cached>,pub built:usize,pub reused:usize,
    pub variant:crate::styles::MathVariant,
}
impl<'a> Builder<'a> {
    pub fn math_glyph(&self,ch:char)->EngineResult<(&'a FontAsset,u16)> {
        if let Some(id)=self.math_font.glyph_index(ch)? {return Ok((self.math_font,id));}
        for font in self.fallback_fonts {if let Some(id)=font.glyph_index(ch)? {return Ok((*font,id));}}
        // Preserve the existing explicit missing-glyph error. Never return glyph
        // zero, a different codepoint, a browser font, or a stretched substitute.
        self.math_font.glyph_id(ch).map(|id|(self.math_font,id))
    }
}
impl Builder<'_> {
    /// The right half of an aligned pair has an empty ordinary atom at its
    /// left boundary. This is layout context, never a synthesized source node.
    /// Contextual cell rows are built by their grid; children keep normal caches.
    pub(super) fn math_row(&mut self,node:&Node,style:MathStyle,cramped:bool,depth:usize,
        initial:Option<AtomClass>)->EngineResult<Fragment>{
        if depth>MAX_DEPTH {return Err(EngineError::new(ErrorCode::ResourceLimit,"Layout depth budget exceeded"));}
        let NodeKind::Row{entries,..}=&node.kind else{return Err(EngineError::new(ErrorCode::InvalidInput,"Math row requires editable Row"));};
        let scale=style.scale(self.math);let mut f=Fragment::new(node.id,"row");
        let mut classes:Vec<_>=entries.iter().map(|e|if matches!(e.node.kind,NodeKind::Space{..}|NodeKind::ColorChange{..}){None}else{Some(atom_class(&e.node))}).collect();
        let atoms:Vec<_>=classes.iter().enumerate().filter_map(|(i,c)|c.map(|_|i)).collect();
        for (j,&i) in atoms.iter().enumerate(){if classes[i]==Some(AtomClass::Binary){
            let left=if j==0{initial}else{classes[atoms[j-1]]};
            let right=atoms.get(j+1).and_then(|&k|classes[k]);
            if left.is_none_or(|c|matches!(c,AtomClass::Binary|AtomClass::Relation|AtomClass::Open|AtomClass::Punctuation|AtomClass::Operator))
                ||right.is_none_or(|c|matches!(c,AtomClass::Relation|AtomClass::Close|AtomClass::Punctuation)){classes[i]=Some(AtomClass::Ordinary);}
        }}
        let mut previous=initial;let top=-self.math_font.ascent*scale;let bottom=self.math_font.descent*scale;
        f.carets.push((Position::row(node.id,0),0.0,top,bottom));
        for (i,e) in entries.iter().enumerate(){
            if let Some(current)=classes[i]{if let Some(prior)=previous{f.advance+=spacing(prior,current,style)*scale;}previous=Some(current);}
            let child=self.node(&e.node,style,cramped,depth+1)?;
            let x=f.advance;let advance=x+child.advance;f.italic=child.italic;
            if entries.len()==1{f.accent=child.accent.map(|a|a+x);}
            f.child(child,x,0.0);f.advance=advance;
            f.carets.push((Position::row(node.id,i+1),f.advance,top,bottom));
        }
        if entries.is_empty(){f.advance=0.5*scale;f.ascent=(-top).max(0.0);f.descent=bottom.max(0.0);}
        Ok(f)
    }
    pub fn node(&mut self,node:&Node,style:MathStyle,cramped:bool,depth:usize)->EngineResult<Arc<Fragment>> {
        if depth>MAX_DEPTH {return Err(EngineError::new(ErrorCode::ResourceLimit,"Layout depth budget exceeded"));}
        let key=(node.id,style,cramped,self.variant);let hash=self.hashes[&node.id];
        if let Some(c)=self.cache.get(&key) {if c.fingerprint==hash {self.reused+=1;return Ok(Arc::clone(&c.fragment));}}
        self.built+=1;
        let scale=style.scale(self.math);
        let mut f=match &node.kind {
            NodeKind::Row {..}=>self.math_row(node,style,cramped,depth,None)?,
            NodeKind::Grid {environment,columns,rows,..}=>self.grid(node.id,*environment,columns,rows,style,depth)?,
            NodeKind::GridRow {cells,..}=>self.grid_row(node.id,cells,style,cramped,depth)?,
            NodeKind::Symbol {value,class,..}=> {
                let mut f=Fragment::new(node.id,"symbol");
                let single_glyph=value.chars().count()==1;
                for ch in value.chars() {
                    let rendered=if self.variant==crate::styles::MathVariant::Default {math_character(ch,*class)}
                        else {crate::styles::map_character(ch,self.variant)};
                    let (font,gid)=self.math_glyph(rendered)?;
                    let shape=font.glyph(gid)?;
                    let advance=shape.advance*scale;f.italic=shape.italic_correction*scale;
                    if single_glyph {f.accent=Some(font.accent_attachment(gid)?*scale);}
                    f.glyph(font,shape,f.advance,0.0,scale);f.advance+=advance;
                }
                f
            }
            NodeKind::Text {command,text,..}=> {
                let mut f=Fragment::new(node.id,if command=="\\operatorname"{"operatorName"}else{"text"});
                let font=if command=="\\operatorname"{self.math_font}else{self.text_font};let run=font.shape_text(text)?;
                f.advance=run.advance*scale;f.ascent=font.ascent*scale;f.descent=font.descent*scale;
                let mut boundaries:Vec<_>=text.grapheme_indices(true).map(|(b,_)|b).collect();boundaries.push(text.len());
                for (i,byte) in boundaries.into_iter().enumerate() {
                    let x=if byte==text.len() {run.advance} else {run.glyphs.iter().find(|g|g.cluster as usize>=byte).map_or(run.advance,|g|g.pen_x)};
                    f.carets.push((Position::text(node.id,i),x*scale,-f.ascent,f.descent));
                }
                for g in run.glyphs {f.glyph(font,g.shape,g.x*scale,g.y*scale,scale);}f
            }
            NodeKind::Fraction {command,numerator,denominator,..}=>self.fraction(node.id,command,numerator,denominator,style,cramped,depth)?,
            NodeKind::Scripts {base,slots}=>self.scripts(node.id,base,slots,style,cramped,depth)?,
            NodeKind::Radical {degree,radicand,..}=>self.radical(node.id,degree.as_deref(),radicand,style,depth)?,
            NodeKind::Fence {left,body,right,..}=>self.fence(node.id,left,body,right,style,cramped,depth)?,
            NodeKind::Accent {command,body,..}=>self.accent(node.id,command,body,style,cramped,depth)?,
            NodeKind::Annotation {command,above,annotation,base,..}=>self.annotation(node.id,command,*above,annotation,base,style,cramped,depth)?,
            NodeKind::LargeOperator {command,parts}=>self.large_operator(node.id,command,parts,style,cramped,depth)?,
            NodeKind::GeneralOperator {body,parts,..}=>self.general_operator(node.id,body,parts,style,cramped,depth)?,
            NodeKind::MacroCall {macro_kind,arguments,..}=>self.builtin_macro(node.id,*macro_kind,arguments,style,cramped,depth)?,
            NodeKind::Style {variant,body,..}=> {
                let previous=self.variant;self.variant=*variant;
                let child=self.node(body,style,cramped,depth+1);self.variant=previous;
                let child=child?;let mut f=Fragment::new(node.id,"style");
                f.italic=child.italic;f.accent=child.accent;f.child(child,0.0,0.0);f
            }
            NodeKind::Color {spec,body,..}=> {
                let child=self.node(body,style,cramped,depth+1)?;
                let mut f=Fragment::new(node.id,"color");f.color=Some(spec.color);
                f.italic=child.italic;f.accent=child.accent;f.child(child,0.0,0.0);f
            }
            NodeKind::ColorChange {spec}=> {
                let mut f=Fragment::new(node.id,"colorChange");f.color_change=Some(spec.color);f
            }
            NodeKind::Boxed {body,..}=> {
                // AMS boxed bodies are display-style even inside a script.
                // Padding is a documented engine default; rule thickness comes
                // from the active math font, not screen pixels or CSS borders.
                let child=self.node(body,MathStyle::Display,false,depth+1)?;
                let rule=self.math.fraction_rule;let gap=0.3;
                let logical=Rect::new(child.advance.min(0.0),-child.ascent,child.advance.max(0.0),child.descent);
                let bounds=child.ink.map_or(logical,|ink|logical.union(ink));
                let margin=gap+rule;let width=bounds.width()+2.0*margin;
                let top=bounds.y_min-margin;let bottom=bounds.y_max+margin;
                let mut f=Fragment::new(node.id,"boxed");
                f.child(child,margin-bounds.x_min,0.0);
                f.rule(Rect::new(0.0,top,width,top+rule));
                f.rule(Rect::new(0.0,bottom-rule,width,bottom));
                f.rule(Rect::new(0.0,top+rule,rule,bottom-rule));
                f.rule(Rect::new(width-rule,top+rule,width,bottom-rule));
                f.advance=width;f
            }
            NodeKind::Space {command,width_mu}=> {
                let mut f=Fragment::new(node.id,"space");
                f.advance=f64::from(*width_mu)/18.0*crate::spacing::space_scale(command,scale);f
            }
            NodeKind::Phantom {axis,body,..}=> {
                use crate::spacing::PhantomAxis;
                let child=self.node(body,style,cramped,depth+1)?;
                let mut f=Fragment::new(node.id,"phantom");
                f.advance=if *axis==PhantomAxis::Vertical {0.0}else{child.advance};
                if *axis!=PhantomAxis::Horizontal {f.ascent=child.ascent;f.descent=child.descent;}
                // Do not call child(): its ink and unused dimension must not
                // enlarge the phantom. Child carets/regions remain navigable.
                f.children.push(Child{fragment:child,x:0.0,y:0.0});
                f.suppress_paint=true;f
            }
            NodeKind::EmptySlot {..}=> {let mut f=Fragment::new(node.id,"emptySlot");f.advance=0.5*scale;f.ascent=self.math_font.ascent*scale;f.descent=self.math_font.descent*scale;f}
            NodeKind::UnparsedSource {..}=>return Err(EngineError::new(ErrorCode::UnsupportedSyntax,"Opaque source cannot be typeset by K0")),
        };
        f.ascent=f.ascent.max(0.0);f.descent=f.descent.max(0.0);
        if ![f.advance,f.ascent,f.descent,f.italic].into_iter().all(f64::is_finite) || f.advance.abs()>1_000_000.0 {
            return Err(EngineError::new(ErrorCode::ResourceLimit,"Layout geometry exceeds its finite extent budget"));
        }
        let f=Arc::new(f);if self.cache.len()>=MAX_NODES*4 {self.cache.clear();}
        self.cache.insert(key,Cached {fingerprint:hash,fragment:Arc::clone(&f)});Ok(f)
    }
}
fn atom_class(node:&Node)->AtomClass {match &node.kind {NodeKind::LargeOperator {..}|NodeKind::GeneralOperator {..}=>AtomClass::Operator,NodeKind::Symbol {class,..}=>*class,NodeKind::Text {command,..} if command=="\\operatorname"=>AtomClass::Operator,NodeKind::Fraction {..}|NodeKind::Fence {..}|NodeKind::Grid {..}|NodeKind::MacroCall {..}=>AtomClass::Inner,NodeKind::Scripts {base,..}|NodeKind::Accent {body:base,..}|NodeKind::Style {body:base,..}|NodeKind::Color {body:base,..}=>atom_class(base),NodeKind::Annotation {command,base,..}=>match command.as_str(){"\\stackrel"=>AtomClass::Relation,"\\stackbin"=>AtomClass::Binary,_=>atom_class(base)}, NodeKind::Row {entries,..} if entries.len()==1=>atom_class(&entries[0].node),_=>AtomClass::Ordinary}}
fn math_character(c:char,class:AtomClass)->char {
    if class!=AtomClass::Ordinary {return c;}
    crate::styles::default_math_character(c)
}
fn spacing(a:AtomClass,b:AtomClass,style:MathStyle)->f64 {
    use AtomClass::*;
    let idx=|a|match a {Ordinary|Number=>0,Operator=>1,Binary=>2,Relation=>3,Open=>4,Close=>5,Punctuation=>6,Inner=>7};
    const MU:[[u8;8];8]=[[0,3,4,5,0,0,0,3],[3,3,0,5,0,0,0,3],[4,4,0,0,4,0,0,4],[5,5,0,0,5,0,0,5],[0,0,0,0,0,0,0,0],[0,3,4,5,0,0,0,3],[3,3,0,3,3,3,3,3],[3,3,4,5,3,0,3,3]];
    if matches!(style,MathStyle::Script|MathStyle::ScriptScript) && !matches!((a,b),(Ordinary|Number|Close|Inner,Operator)|(Operator,Ordinary|Number|Operator)) {return 0.0;}
    f64::from(MU[idx(a)][idx(b)])/18.0
}
pub(super) fn flatten(f:&Fragment,x:f64,y:f64,depth:usize,scene:&mut SceneBuilder)->EngineResult<()> {
    flatten_paint(f,x,y,depth,true,None,scene)
}
fn flatten_paint(f:&Fragment,x:f64,y:f64,depth:usize,paint:bool,color:Option<crate::paint::RgbColor>,scene:&mut SceneBuilder)->EngineResult<()> {
    let paint=paint&&!f.suppress_paint;
    let color=f.color.or(color);
    if depth>MAX_DEPTH || scene.snapshot.glyphs.len()+f.glyphs.len()>16_384 || scene.snapshot.carets.len()+f.carets.len()>32_768 {
        return Err(EngineError::new(ErrorCode::ResourceLimit,"Scene budget exceeded"));
    }
    for anchor in &f.column_anchors {let mut anchor=anchor.clone();anchor.x+=x;scene.snapshot.grid_columns.push(anchor);}
    scene.snapshot.regions.push(NodeRegion {node_id:f.node_id,role:f.role.into(),logical:Rect::new(x.min(x+f.advance),y-f.ascent,x.max(x+f.advance),y+f.descent),ink:if paint {f.ink.map(|r|r.translated(x,y))}else{None},depth});
    if paint {
        for g in &f.glyphs {scene.glyph(f.node_id,&g.font_id,Arc::clone(&g.shape),g.x+x,g.y+y,g.scale,color);}
        for r in &f.rules {scene.snapshot.rules.push(Rule {node_id:f.node_id,rect:r.translated(x,y),color});}
    }
    for (position,cx,top,bottom) in &f.carets {scene.snapshot.carets.push(CaretStop {position:*position,x:x+cx,baseline:y,top:y+top,bottom:y+bottom,depth});}
    let mut current_color=color;
    for child in &f.children {
        flatten_paint(&child.fragment,x+child.x,y+child.y,depth+1,paint,current_color,scene)?;
        // A leaf declaration updates its owning row only. Changes inside a
        // nested row/wrapper never escape to this row's following siblings.
        if let Some(next)=child.fragment.color_change {current_color=Some(next);}
    }Ok(())
}
