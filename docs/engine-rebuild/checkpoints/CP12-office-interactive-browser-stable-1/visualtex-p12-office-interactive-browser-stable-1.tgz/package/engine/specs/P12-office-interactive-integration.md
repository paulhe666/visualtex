# P12 Windows Office interactive core integration

Status: browser-stable; real Office gate blocked by external companion certificate state.

## Scope

P12 switches only the interactive Windows Office editor surface to the verified VisualTeX core editor. It does not change the Office Session wire DTO, `useOfficeSession`, Tauri Office routes/state, C# Contracts, Word/PowerPoint VSTO document algorithms, COM/OLE storage, numbering, references, or the hidden `vsto-convert` batch runtime.

The production Windows Office bundle contains the core editor/WASM/font resources. Runtime ownership remains explicit: desktop and interactive Office editor generations may select core after preflight; `vsto-convert` is not allowed to select or load the core editor.

## Ownership and stale-result rules

Interactive Office core export is exposed through `CoreEditorExportPort`. The port carries the retained core owner, core document identity/revision, and verified font-layout resolver. Office export requests are bound to the current `sessionId + formulaId + core documentId + revision + owner` tuple. Any Session switch, formula switch, owner replacement, or revision change retires an in-flight export before it can PATCH the Session.

Initial Session hydration does not mark the formula dirty and does not create a core edit transaction. Core content history remains the only content-history owner while the interactive formula is core-owned; the existing Office Undo/Redo buttons delegate to core history rather than maintaining a second legacy content history.

## Export behavior

Interactive core-owned formulas use the P11 `coreOfficeCompatibility` adapter. SVG, Presentation MathML, natural CSS-pixel geometry, baseline and optional PNG all come from the same retained core revision. MathType output keeps Times-family preview semantics and P11 ruler-stop generation. Word OMML keeps the MathML-only/preserved-geometry path. The existing Session PATCH/commit/completed handshake remains unchanged.

Autosave is two-stage for core-owned formulas: source/state are persisted immediately through the existing Session save path; the asynchronous export PATCH is accepted only if the exact Session/formula/owner/revision is still current. Explicit Apply waits for the current core export before sending the existing commit signal. Cancel continues to use the existing Session cancellation/close path and never asks core to set Office Session status.

Tagged formulas remain outside the P12 core gate because the current core tree does not own the Office equation-tag wrapper. This is an explicit eligibility rule, not a MathJax fallback inside a core session.

## Hidden converter boundary

`vsto-convert` remains P13 territory. It does not mount the core editor, create a core input bridge, request the core WASM/font assets, or use P11 core export in P12. Existing `generateSessionExportResult()` behavior remains the hidden converter path, including OMML MathML-only behavior and legacy MathJax SVG where currently required.

## Verified browser gates

The production Windows Office bundle has been exercised in an isolated real Edge instance with a mock companion implementing the existing Session routes. The browser gates cover: interactive core selection; no MathLive field in the core-owned editor; verified WASM/font resource load; initial clean hydration; real keyboard edit; immediate source PATCH; same-revision SVG/MathML/PNG/baseline export; rapid-edit stale export rejection; Session-switch stale owner rejection; Office Undo/Redo routed to core history; theme synchronization; Apply through the existing Session commit handshake; Cancel through the existing cancellation path; and `vsto-convert` remaining legacy and not loading core resources.

P11 compatibility verification is rerun after P12 changes and must remain PASS.

## Real Office gate

P12 is not complete until the project plan's real Ribbon/UI matrix passes on dedicated test documents: VisualTeX OLE, OMML and MathType edit/insert paths; inline/display; numbered/unnumbered as applicable; cancel/X/auto-commit; repeated Apply/window reuse; save/reopen; no paragraph/default-font pollution; no duplicate Session/object; and user documents/processes untouched.

The current real-Ribbon attempt was stopped before Session creation because the shared OfficeIntegration registry points at the isolated debug companion identity `com.visualtex.studio.p10acceptance`, whose registered certificate thumbprint is not present in the CurrentUser Root store. VSTO fails at `VisualTeXSessionClient` configuration validation before the Office editor WebView opens. P12 does not change the shared registry or trust store to manufacture a pass. This external gate is recorded as blocked, not failed product behavior.

## Stop rule

Do not enter P13 while the real P12 Office gate is blocked or failing. Do not modify WordFormulaService, numbering, COM/OLE contracts, Session routes, registry, MSI or certificate trust to make P12 pass.
