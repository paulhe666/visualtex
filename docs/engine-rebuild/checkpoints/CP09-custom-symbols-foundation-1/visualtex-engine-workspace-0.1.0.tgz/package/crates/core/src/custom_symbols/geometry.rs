//! Bounded vector compiler. Author paths are preserved in the resource snapshot;
//! supported segments become absolute em-space curves. No DOM, SVG markup,
//! system-font lookup, CSS mask, raster tracing or similar-glyph substitution.
use super::*;
use std::f64::consts::PI;
type Point=[f64;2];
fn coord(v:&Value,key:&str)->EngineResult<f64>{let n=number(v,key)?;if n.abs()>100_000.0{Err(bad("Artwork coordinate exceeds the legacy limit"))}else{Ok(n)}}
fn nonnegative(v:&Value,key:&str)->EngineResult<f64>{let n=coord(v,key)?;if n<0.0{Err(bad("Artwork size cannot be negative"))}else{Ok(n)}}
fn line(out:&mut Vec<PathOp>,p:Point){out.push(PathOp::Line(p));}
fn rect(x:f64,y:f64,w:f64,h:f64,reverse:bool)->Vec<PathOp>{
    let points=if reverse{[[x,y],[x,y+h],[x+w,y+h],[x+w,y]]}else{[[x,y],[x+w,y],[x+w,y+h],[x,y+h]]};
    vec![PathOp::Move(points[0]),PathOp::Line(points[1]),PathOp::Line(points[2]),PathOp::Line(points[3]),PathOp::Close]
}
// Cubic approximation of analytic circles/ellipses, with 16 fixed sectors.
// This does not modify imported glyph curves. Same sector count at every zoom.
fn ellipse(x:f64,y:f64,rx:f64,ry:f64,reverse:bool)->Vec<PathOp>{
    let mut out=vec![PathOp::Move([x+rx,y])];let direction=if reverse{-1.0}else{1.0};
    for i in 0..16 {let a=direction*i as f64*PI/8.0;let b=direction*(i+1)as f64*PI/8.0;let k=4.0/3.0*((b-a)/4.0).tan();
        out.push(PathOp::Cubic([x+rx*(a.cos()-k*a.sin()),y+ry*(a.sin()+k*a.cos()),x+rx*(b.cos()+k*b.sin()),y+ry*(b.sin()-k*b.cos()),x+rx*b.cos(),y+ry*b.sin()]));}
    out.push(PathOp::Close);out
}
fn circle_ring(x:f64,y:f64,r:f64,w:f64)->Vec<PathOp>{let mut out=ellipse(x,y,r+w/2.0,r+w/2.0,false);if r>w/2.0{out.extend(ellipse(x,y,r-w/2.0,r-w/2.0,true));}out}
fn stroke_line(x1:f64,y1:f64,x2:f64,y2:f64,w:f64,cap:&str)->Vec<PathOp>{
    let dx=x2-x1;let dy=y2-y1;let length=dx.hypot(dy);let half=w/2.0;
    if length==0.0{return match cap{"round"=>ellipse(x1,y1,half,half,false),"square"=>rect(x1-half,y1-half,w,w,false),_=>Vec::new()};}
    let (ux,uy)=(dx/length,dy/length);let (nx,ny)=(-uy*half,ux*half);let ext=if cap=="square"{half}else{0.0};
    // Same winding as the circular caps: nonzero fill must form their union,
    // not cancel the overlapping half-discs at the segment ends.
    let mut out=vec![PathOp::Move([x1-ux*ext-nx,y1-uy*ext-ny]),PathOp::Line([x2+ux*ext-nx,y2+uy*ext-ny]),PathOp::Line([x2+ux*ext+nx,y2+uy*ext+ny]),PathOp::Line([x1-ux*ext+nx,y1-uy*ext+ny]),PathOp::Close];
    if cap=="round"{out.extend(ellipse(x1,y1,half,half,false));out.extend(ellipse(x2,y2,half,half,false));}out
}
#[derive(Clone,Copy)]
struct Matrix([f64;6]);
impl Matrix {
    fn identity()->Self{Self([1.,0.,0.,1.,0.,0.])}
    fn mul(self,b:Self)->Self{let [a,b0,c,d,e,f]=self.0;let [g,h,i,j,k,l]=b.0;Self([a*g+c*h,b0*g+d*h,a*i+c*j,b0*i+d*j,a*k+c*l+e,b0*k+d*l+f])}
    fn translate(x:f64,y:f64)->Self{Self([1.,0.,0.,1.,x,y])}
    fn point(self,[x,y]:Point)->EngineResult<Point>{let [a,b,c,d,e,f]=self.0;let p=[a*x+c*y+e,b*x+d*y+f];
        if p.iter().any(|v|!v.is_finite()||v.abs()>10_000_000.0){return Err(limit("Transformed artwork exceeds the vector coordinate budget"));}Ok(p)}
}
fn matrix(value:Option<&Value>)->EngineResult<Matrix>{
    let Some(v)=value else{return Ok(Matrix::identity())};if !v.is_object(){return Err(bad("Artwork transform must be an object"));}
    let get=|key,default|optional_number(v,key,default);
    let(tx,ty,ox,oy)=(get("translateX",0.)?,get("translateY",0.)?,get("originX",0.)?,get("originY",0.)?);
    let(sx,sy)=(get("scaleX",1.)?,get("scaleY",1.)?);if sx==0.||sy==0.{return Err(bad("Artwork transform cannot have a zero scale"));}
    let angle=get("rotateDeg",0.)?*PI/180.;let skewx=(get("skewXDeg",0.)?*PI/180.).tan();let skewy=(get("skewYDeg",0.)?*PI/180.).tan();
    let base=if let Some(array)=v.get("matrix") {let a=array.as_array().filter(|a|a.len()==6).ok_or_else(||bad("Artwork matrix needs six values"))?;let mut n=[0.;6];for(i,v)in a.iter().enumerate(){n[i]=v.as_f64().filter(|n|n.is_finite()&&n.abs()<=100_000.).ok_or_else(||bad("Invalid artwork matrix coordinate"))?;}if (n[0]*n[3]-n[1]*n[2]).abs()<1e-7{return Err(bad("Artwork matrix is singular"));}Matrix(n)}else{Matrix::identity()};
    let result=Matrix::translate(tx,ty).mul(Matrix::translate(ox,oy)).mul(Matrix([angle.cos(),angle.sin(),-angle.sin(),angle.cos(),0.,0.]))
        .mul(Matrix([1.,0.,skewx,1.,0.,0.])).mul(Matrix([1.,skewy,0.,1.,0.,0.])).mul(Matrix([sx,0.,0.,sy,0.,0.])).mul(Matrix::translate(-ox,-oy)).mul(base);
    if result.0.iter().any(|v|!v.is_finite()||v.abs()>1e8){return Err(bad("Artwork transform is non-finite or excessive"));}Ok(result)
}
fn transform(path:Vec<PathOp>,matrix:Matrix,ascent:f64)->EngineResult<ArtworkPath>{
    let mut result=Vec::with_capacity(path.len());let mut bounds:Option<Rect>=None;
    let mut map=|p:Point|->EngineResult<Point>{let [x,y]=matrix.point(p)?;let q=|n:f64|(n*1e9).round()/1e9;let p=[q(x/1000.),q(y/1000.-ascent)];
        let r=Rect::new(p[0],p[1],p[0],p[1]);bounds=Some(bounds.map_or(r,|b|b.union(r)));Ok(p)};
    for op in path {result.push(match op{
        PathOp::Move(p)=>PathOp::Move(map(p)?),PathOp::Line(p)=>PathOp::Line(map(p)?),
        PathOp::Quad(p)=>{let a=map([p[0],p[1]])?;let b=map([p[2],p[3]])?;PathOp::Quad([a[0],a[1],b[0],b[1]])},
        PathOp::Cubic(p)=>{let a=map([p[0],p[1]])?;let b=map([p[2],p[3]])?;let c=map([p[4],p[5]])?;PathOp::Cubic([a[0],a[1],b[0],b[1],c[0],c[1]])},PathOp::Close=>PathOp::Close});}
    // Convex control-point hull is conservative: never clips a custom outline.
    // Its logical advance/ascent/descent remain the authored metrics, not this hull.
    Ok(ArtworkPath{path:result,ink:bounds.unwrap_or(Rect::new(0.,0.,0.,0.))})
}
pub(super) fn compile(shape:&Value,ascent:f64)->EngineResult<Vec<ArtworkPath>>{
    if !shape.is_object(){return Err(bad("Artwork shape must be an object"));}
    let kind=string(shape,"kind")?;let m=matrix(shape.get("transform"))?;
    if let Some(op)=shape.get("operation"){if op!="erase"{return Err(bad("Unknown artwork operation"));}return Err(unsupported("Erase artwork is preserved; vector boolean subtraction is not connected yet"));}
    if shape.get("clipRect").is_some(){return Err(unsupported("Clipped artwork is preserved; vector clipping is not connected yet"));}
    if kind=="text"{return Err(unsupported("System-font text artwork needs an explicit verified font binding; no browser-font fallback is permitted"));}
    let fill=match shape.get("fill"){None=>kind!="line",Some(Value::Bool(b))=>*b,_=>return Err(bad("Invalid artwork fill value"))};
    let stroke=optional_number(shape,"strokeWidth",if kind=="line"{50.}else{0.})?;
    if !(0.0..=100_000.).contains(&stroke){return Err(bad("Invalid artwork stroke width"));}
    let cap=shape.get("lineCap").map_or(Ok("butt"),|v|v.as_str().ok_or_else(||bad("Invalid line cap")))?;
    let join=shape.get("lineJoin").map_or(Ok("miter"),|v|v.as_str().ok_or_else(||bad("Invalid line join")))?;
    if !matches!(cap,"butt"|"round"|"square")||!matches!(join,"miter"|"round"|"bevel"){return Err(bad("Unsupported line cap/join value"));}
    let mut paths=Vec::new();
    match kind{
        "path"=>{let path=parse_path(string(shape,"d")?)?;if stroke>0.{return Err(unsupported("General path stroking is preserved; outline compiler is not connected yet"));}if fill{paths.push(path);}},
        "line"=>{let(x1,y1,x2,y2)=(coord(shape,"x1")?,coord(shape,"y1")?,coord(shape,"x2")?,coord(shape,"y2")?);if stroke>0.{paths.push(stroke_line(x1,y1,x2,y2,stroke,cap));}},
        "circle"=>{let(x,y,r)=(coord(shape,"cx")?,coord(shape,"cy")?,nonnegative(shape,"r")?);if fill&&r>0.{paths.push(ellipse(x,y,r,r,false));}if stroke>0.&&r>0.{paths.push(circle_ring(x,y,r,stroke));}},
        "ellipse"=>{let(x,y,rx,ry)=(coord(shape,"cx")?,coord(shape,"cy")?,nonnegative(shape,"rx")?,nonnegative(shape,"ry")?);if stroke>0.{return Err(unsupported("General ellipse stroking is preserved; stroke offsets must not be approximated by a smaller ellipse"));}if fill&&rx>0.&&ry>0.{paths.push(ellipse(x,y,rx,ry,false));}},
        "rect"=>{let(x,y,w,h)=(coord(shape,"x")?,coord(shape,"y")?,nonnegative(shape,"width")?,nonnegative(shape,"height")?);
            if optional_number(shape,"rx",0.)?!=0.||optional_number(shape,"ry",0.)?!=0.{return Err(unsupported("Rounded rectangles are preserved; rounded geometry is not connected yet"));}
            if fill&&w>0.&&h>0.{paths.push(rect(x,y,w,h,false));}if stroke>0.&&w>0.&&h>0.{if join!="miter"{return Err(unsupported("Round/bevel rectangle stroke joins are not connected yet"));}
                let half=stroke/2.;let mut path=rect(x-half,y-half,w+stroke,h+stroke,false);if w>stroke&&h>stroke{path.extend(rect(x+half,y+half,w-stroke,h-stroke,true));}paths.push(path);}},
        "polygon"=>{let points=shape["points"].as_array().filter(|p|(2..=256).contains(&p.len())).ok_or_else(||bad("Invalid polygon vertex count"))?;let mut path=Vec::new();
            for (i,p) in points.iter().enumerate(){let p=p.as_array().filter(|p|p.len()==2).ok_or_else(||bad("Invalid polygon vertex"))?;let mut xy=[0.;2];for k in 0..2{xy[k]=p[k].as_f64().filter(|n|n.is_finite()&&n.abs()<=100_000.).ok_or_else(||bad("Invalid polygon coordinate"))?;}path.push(if i==0{PathOp::Move(xy)}else{PathOp::Line(xy)});}path.push(PathOp::Close);
            if stroke>0.{return Err(unsupported("Polygon stroke joins are preserved; general path stroking is not connected yet"));}if fill{paths.push(path);}},
        _=>return Err(bad("Unknown custom artwork shape kind")),
    }
    paths.into_iter().filter(|p|!p.is_empty()).map(|p|transform(p,m,ascent)).collect()
}
struct Scanner<'a>{bytes:&'a[u8],at:usize}
impl Scanner<'_>{
    fn skip(&mut self){while self.bytes.get(self.at).is_some_and(|b|b.is_ascii_whitespace()||*b==b','){self.at+=1;}}
    fn number(&mut self)->EngineResult<f64>{self.skip();let start=self.at;if self.bytes.get(self.at).is_some_and(|b|matches!(b,b'+'|b'-')){self.at+=1;}
        let mut digits=0;while self.bytes.get(self.at).is_some_and(u8::is_ascii_digit){self.at+=1;digits+=1;}
        if self.bytes.get(self.at)==Some(&b'.'){self.at+=1;while self.bytes.get(self.at).is_some_and(u8::is_ascii_digit){self.at+=1;digits+=1;}}
        if digits==0{return Err(bad("Malformed SVG path number"));}
        if self.bytes.get(self.at).is_some_and(|b|matches!(b,b'e'|b'E')){self.at+=1;if self.bytes.get(self.at).is_some_and(|b|matches!(b,b'+'|b'-')){self.at+=1;}let exponent=self.at;while self.bytes.get(self.at).is_some_and(u8::is_ascii_digit){self.at+=1;}if self.at==exponent{return Err(bad("Malformed SVG path exponent"));}}
        let n=std::str::from_utf8(&self.bytes[start..self.at]).ok().and_then(|s|s.parse::<f64>().ok()).filter(|n|n.is_finite()&&n.abs()<=100_000.).ok_or_else(||bad("SVG path number exceeds the coordinate budget"))?;Ok(n)
    }
    fn point(&mut self,current:Point,relative:bool)->EngineResult<Point>{let p=[self.number()?,self.number()?];let p=if relative{[p[0]+current[0],p[1]+current[1]]}else{p};if p.iter().any(|n|n.abs()>100_000.){return Err(bad("Relative SVG path exceeds the coordinate budget"));}Ok(p)}
}
fn parse_path(source:&str)->EngineResult<Vec<PathOp>>{
    if source.is_empty()||source.len()>24_000{return Err(limit("SVG path source exceeds the legacy path budget"));}
    let mut s=Scanner{bytes:source.as_bytes(),at:0};let mut out=Vec::new();let mut current=[0.;2];let mut start=current;let mut command=None;let mut previous=0u8;let mut control=current;
    loop{s.skip();let Some(&next)=s.bytes.get(s.at)else{break};
        if next.is_ascii_alphabetic(){command=Some(next);s.at+=1;}
        let c=command.ok_or_else(||bad("SVG path requires an initial move command"))?;let upper=c.to_ascii_uppercase();let relative=c.is_ascii_lowercase();
        if out.is_empty()&&upper!=b'M'{return Err(bad("SVG path must begin with moveto"));}
        match upper {
            b'M'=>{current=s.point(current,relative)?;start=current;out.push(PathOp::Move(current));command=Some(if relative{b'l'}else{b'L'});},
            b'L'=>{current=s.point(current,relative)?;line(&mut out,current);},
            b'H'=>{let x=s.number()?;current[0]=x+if relative{current[0]}else{0.};line(&mut out,current);},
            b'V'=>{let y=s.number()?;current[1]=y+if relative{current[1]}else{0.};line(&mut out,current);},
            b'C'=>{let a=s.point(current,relative)?;let b=s.point(current,relative)?;let end=s.point(current,relative)?;out.push(PathOp::Cubic([a[0],a[1],b[0],b[1],end[0],end[1]]));control=b;current=end;},
            b'S'=>{let a=if matches!(previous,b'C'|b'S'){[2.*current[0]-control[0],2.*current[1]-control[1]]}else{current};let b=s.point(current,relative)?;let end=s.point(current,relative)?;out.push(PathOp::Cubic([a[0],a[1],b[0],b[1],end[0],end[1]]));control=b;current=end;},
            b'Q'=>{let a=s.point(current,relative)?;let end=s.point(current,relative)?;out.push(PathOp::Quad([a[0],a[1],end[0],end[1]]));control=a;current=end;},
            b'T'=>{let a=if matches!(previous,b'Q'|b'T'){[2.*current[0]-control[0],2.*current[1]-control[1]]}else{current};let end=s.point(current,relative)?;out.push(PathOp::Quad([a[0],a[1],end[0],end[1]]));control=a;current=end;},
            b'Z'=>{out.push(PathOp::Close);current=start;command=None;},
            b'A'=>return Err(unsupported("SVG elliptical-arc path segments are preserved; arc conversion is not connected yet")),
            _=>return Err(bad("Unsupported or unsafe SVG path token")),
        }
        if current.iter().any(|v|v.abs()>100_000.){return Err(bad("SVG path exceeds the coordinate budget"));}
        if out.len()>16_384{return Err(limit("SVG path exceeds the segment budget"));}previous=upper;
    }
    if out.is_empty(){return Err(bad("Empty SVG path"));}Ok(out)
}
