//! Contained mathematical grids. Column identities are metadata, not caret
//! positions or source offsets. Rows/cells are independently identified nodes.
use serde::{Deserialize, Serialize};
use crate::{error::EngineResult, model::IdAllocator};

pub const MAX_GRID_ROWS: usize = 256;
pub const MAX_GRID_COLUMNS: usize = 64;

#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Serialize, Deserialize)]
#[serde(transparent)]
pub struct GridColumnId(pub u32);
impl GridColumnId {
    pub fn allocate(ids: &mut IdAllocator) -> EngineResult<Self> { Ok(Self(ids.allocate()?.0)) }
}

/// Only implemented environments are enumerated. Matrix/cases/aligned extend
/// this type with their own column/alignment policy in subsequent P08 slices.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub enum GridKind { Gathered }
impl GridKind {
    pub fn name(self) -> &'static str { match self { Self::Gathered => "gathered" } }
    pub fn from_name(name: &str) -> Option<Self> { match name { "gathered" => Some(Self::Gathered), _ => None } }
    pub fn accepts_columns(self, count: usize) -> bool { match self { Self::Gathered => count == 1 } }
}
