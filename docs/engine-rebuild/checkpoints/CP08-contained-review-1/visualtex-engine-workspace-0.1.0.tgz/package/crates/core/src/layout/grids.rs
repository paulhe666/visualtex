//! Contained gathered layout: shared column width and explicit row baselines.
//! No DOM table measurements or separate per-line editor instances are used.
use std::sync::Arc;
use crate::{error::{EngineError,EngineResult,ErrorCode},grids::{GridColumnId,GridKind},
    model::Node,scene::{GridColumnAnchor,Rect},session::NodeId};
use super::{MathStyle,boxes::{Builder,Fragment}};

fn extent(fragment:&Fragment)->Rect {
    let logical=Rect::new(fragment.advance.min(0.0),-fragment.ascent,fragment.advance.max(0.0),fragment.descent);
    fragment.ink.map_or(logical,|ink|logical.union(ink))
}
impl Builder<'_>{
    pub(super) fn grid_row(&mut self,id:NodeId,cells:&[Arc<Node>],style:MathStyle,
        cramped:bool,depth:usize)->EngineResult<Fragment>{
        if cells.len()!=1 {return Err(EngineError::new(ErrorCode::UnsupportedSyntax,"This gathered slice requires one cell per row"));}
        let child=self.node(&cells[0],style,cramped,depth+1)?;
        let advance=child.advance;let mut row=Fragment::new(id,"gridRow");row.child(child,0.0,0.0);row.advance=advance;Ok(row)
    }
    pub(super) fn grid(&mut self,id:NodeId,environment:GridKind,columns:&[GridColumnId],rows:&[Arc<Node>],
        ambient:MathStyle,depth:usize)->EngineResult<Fragment>{
        if !environment.accepts_columns(columns.len()) || rows.is_empty(){
            return Err(EngineError::new(ErrorCode::InvalidInput,"Invalid gathered dimensions"));
        }
        // gathered is a display-style subenvironment. The parent mathematical
        // axis still determines its vertical placement as one inline box.
        let row_style=MathStyle::Display;
        let local=row_style.scale(self.math);
        // Documented grid defaults, not claims of MATH constants: 0.8/0.2em
        // minimum row strut and 0.3em clear inter-row gap. Taller content wins.
        let gap=0.3*local;let mut fragments=Vec::with_capacity(rows.len());let mut width:f64=0.0;
        let mut height=0.0;let mut previous_descent=0.0;
        for (i,row) in rows.iter().enumerate(){
            let fragment=self.node(row,row_style,false,depth+1)?;let bounds=extent(&fragment);
            width=width.max(bounds.width());
            let ascent=fragment.ascent.max(0.8*local);let descent=fragment.descent.max(0.2*local);
            let baseline=if i==0{ascent}else{height+previous_descent+gap+ascent};
            height=baseline;previous_descent=descent;
            fragments.push((fragment,bounds,baseline));
        }
        height+=previous_descent;
        let axis=self.math.axis*ambient.scale(self.math);let shift=-height/2.0-axis;
        let mut result=Fragment::new(id,"grid");
        for (row,bounds,baseline) in fragments {
            let x=(width-bounds.width())/2.0-bounds.x_min;
            result.child(row,x,baseline+shift);
        }
        result.advance=width;result.ascent=height/2.0+axis;result.descent=(height/2.0-axis).max(0.0);
        result.column_anchors.push(GridColumnAnchor{grid_id:id,column_id:columns[0],index:0,x:0.0,width});
        Ok(result)
    }
}
