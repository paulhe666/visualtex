//! Contained mathematical grids. Column identities are metadata, not caret
//! positions or source offsets. Rows/cells are independently identified nodes.
use serde::{Deserialize, Serialize};
use crate::{error::EngineResult, model::IdAllocator};

pub const MAX_GRID_ROWS: usize = 256;
pub const MAX_GRID_COLUMNS: usize = 64;

#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Serialize, Deserialize)]
#[serde(transparent)]
pub struct GridColumnId(pub u32);
impl GridColumnId {
    pub fn allocate(ids: &mut IdAllocator) -> EngineResult<Self> { Ok(Self(ids.allocate()?.0)) }
}

/// Each supported environment owns its column policy. Aligned remains outside
/// this slice; accepting a name alone is not a capability declaration.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub enum GridKind { Gathered, Matrix, Cases }
impl GridKind {
    pub fn name(self) -> &'static str { match self { Self::Gathered => "gathered", Self::Matrix => "matrix", Self::Cases => "cases" } }
    pub fn from_name(name: &str) -> Option<Self> {
        match name { "gathered" => Some(Self::Gathered), "matrix" => Some(Self::Matrix), "cases" => Some(Self::Cases), _ => None }
    }
    pub fn accepts_columns(self, count: usize) -> bool {
        match self { Self::Gathered => count == 1, Self::Matrix => (1..=MAX_GRID_COLUMNS).contains(&count), Self::Cases => count == 2 }
    }
}
