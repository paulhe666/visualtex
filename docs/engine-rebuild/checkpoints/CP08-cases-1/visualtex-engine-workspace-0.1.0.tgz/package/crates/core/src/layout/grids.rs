//! Contained gathered layout: shared column width and explicit row baselines.
//! No DOM table measurements or separate per-line editor instances are used.
use std::sync::Arc;
use crate::{error::{EngineError,EngineResult,ErrorCode},grids::{GridColumnId,GridKind},
    model::{Node,NodeKind},scene::{GridColumnAnchor,Rect},session::NodeId};
use super::{MathStyle,boxes::{Builder,Fragment}};

fn extent(fragment:&Fragment)->Rect {
    let logical=Rect::new(fragment.advance.min(0.0),-fragment.ascent,fragment.advance.max(0.0),fragment.descent);
    fragment.ink.map_or(logical,|ink|logical.union(ink))
}
impl Builder<'_>{
    pub(super) fn grid_row(&mut self,id:NodeId,cells:&[Arc<Node>],style:MathStyle,
        cramped:bool,depth:usize)->EngineResult<Fragment>{
        if cells.len()!=1 {return Err(EngineError::new(ErrorCode::UnsupportedSyntax,"This gathered slice requires one cell per row"));}
        let child=self.node(&cells[0],style,cramped,depth+1)?;
        let advance=child.advance;let mut row=Fragment::new(id,"gridRow");row.child(child,0.0,0.0);row.advance=advance;Ok(row)
    }
    pub(super) fn grid(&mut self,id:NodeId,environment:GridKind,columns:&[GridColumnId],rows:&[Arc<Node>],
        ambient:MathStyle,depth:usize)->EngineResult<Fragment>{
        if !environment.accepts_columns(columns.len()) || rows.is_empty(){
            return Err(EngineError::new(ErrorCode::InvalidInput,"Invalid gathered dimensions"));
        }
        if environment!=GridKind::Gathered {return self.cell_grid(id,environment,columns,rows,ambient,depth);}
        // gathered is a display-style subenvironment. The parent mathematical
        // axis still determines its vertical placement as one inline box.
        let row_style=MathStyle::Display;
        let local=row_style.scale(self.math);
        // Documented grid defaults, not claims of MATH constants: 0.8/0.2em
        // minimum row strut and 0.3em clear inter-row gap. Taller content wins.
        let gap=0.3*local;let mut fragments=Vec::with_capacity(rows.len());let mut width:f64=0.0;
        let mut height=0.0;let mut previous_descent=0.0;
        for (i,row) in rows.iter().enumerate(){
            let fragment=self.node(row,row_style,false,depth+1)?;let bounds=extent(&fragment);
            width=width.max(bounds.width());
            let ascent=fragment.ascent.max(0.8*local);let descent=fragment.descent.max(0.2*local);
            let baseline=if i==0{ascent}else{height+previous_descent+gap+ascent};
            height=baseline;previous_descent=descent;
            fragments.push((fragment,bounds,baseline));
        }
        height+=previous_descent;
        let axis=self.math.axis*ambient.scale(self.math);let shift=-height/2.0-axis;
        let mut result=Fragment::new(id,"grid");
        for (row,bounds,baseline) in fragments {
            let x=(width-bounds.width())/2.0-bounds.x_min;
            result.child(row,x,baseline+shift);
        }
        result.advance=width;result.ascent=height/2.0+axis;result.descent=(height/2.0-axis).max(0.0);
        result.column_anchors.push(GridColumnAnchor{grid_id:id,column_id:columns[0],index:0,x:0.0,width});
        Ok(result)
    }

    fn cell_grid(&mut self,id:NodeId,environment:GridKind,columns:&[GridColumnId],rows:&[Arc<Node>],
        ambient:MathStyle,depth:usize)->EngineResult<Fragment>{
        // Matrix cells are text-style math. The environment owns the shared
        // column constraints: a row cannot be cached with context-free widths.
        // Cell subtrees remain cached normally by node identity/style/hash.
        let style=MathStyle::Text;let scale=style.scale(self.math);
        let mut widths=vec![0.0_f64;columns.len()];let mut measured=Vec::with_capacity(rows.len());
        for row in rows {
            let NodeKind::GridRow{cells,..}=&row.kind else {
                return Err(EngineError::new(ErrorCode::InvalidInput,"Matrix child is not a grid row"));
            };
            if cells.len()!=columns.len(){return Err(EngineError::new(ErrorCode::InvalidInput,"Matrix cells do not match its columns"));}
            let mut content=Vec::with_capacity(cells.len());
            let mut ascent=0.8*scale;let mut descent=0.2*scale;
            for (column,cell) in cells.iter().enumerate(){
                let fragment=self.node(cell,style,false,depth+2)?;let bounds=extent(&fragment);
                widths[column]=widths[column].max(bounds.width());
                ascent=ascent.max(-bounds.y_min);descent=descent.max(bounds.y_max);
                content.push((fragment,bounds));
            }
            measured.push((row.id,content,ascent,descent));
        }
        let column_gap=scale;let row_gap=0.3*scale;
        let mut starts=Vec::with_capacity(columns.len());let mut width=0.0;
        for cell_width in &widths {starts.push(width);width+=cell_width+column_gap;}
        width-=column_gap;
        let height: f64=measured.iter().map(|(_,_,a,d)|a+d).sum::<f64>()+row_gap*(rows.len()-1)as f64;
        let axis=self.math.axis*ambient.scale(self.math);let mut y=-height/2.0-axis;
        let mut result=Fragment::new(id,"grid");
        for (row_id,cells,ascent,descent) in measured {
            y+=ascent;let mut row=Fragment::new(row_id,"gridRow");self.built+=1;
            for (column,(cell,bounds)) in cells.into_iter().enumerate(){
                let alignment=if environment==GridKind::Cases{0.0}else{(widths[column]-bounds.width())/2.0};
                let x=starts[column]+alignment-bounds.x_min;
                row.child(cell,x,0.0);
            }
            row.advance=width;row.ascent=ascent;row.descent=descent;
            result.child(Arc::new(row),0.0,y);y+=descent+row_gap;
        }
        result.advance=width;result.ascent=height/2.0+axis;result.descent=(height/2.0-axis).max(0.0);
        for (index,column_id) in columns.iter().enumerate(){
            result.column_anchors.push(GridColumnAnchor{grid_id:id,column_id:*column_id,index,x:starts[index],width:widths[index]});
        }
        if environment==GridKind::Cases {
            // The brace is a genuine font construction owned by the same grid.
            // It is not a CSS border or a separate editable fence/host.
            let brace_scale=ambient.scale(self.math);
            let glyph=crate::stretch::vertical(self.math_font,self.math_font.glyph_id('{')?,height/brace_scale)?;
            result.translate_x(glyph.width*brace_scale+0.15*brace_scale);
            let top=-axis-glyph.height*brace_scale/2.0;
            for piece in glyph.pieces {result.glyph(self.math_font,piece.shape,0.0,top+piece.y*brace_scale,brace_scale);}
        }
        Ok(result)
    }
}
