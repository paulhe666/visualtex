# P09 immutable custom-symbol foundation

Status: implemented foundation; advanced legacy artwork remains explicitly bounded below. This is not a P09-complete claim.

## Ownership

A custom symbol inserted into a formula is bound to an immutable `SymbolAsset` snapshot. The snapshot contains the exact legacy definition JSON, a content SHA-256, math role, limits behavior, metrics and compiled self-owned vector geometry. Rendering never looks up a later same-name library record. A later library change therefore cannot silently alter an existing formula.

The document/session owns a bounded `SymbolCatalog`. Node identity and asset identity are separate. Copy/duplicate allocates fresh mathematical NodeIds but retains the same immutable asset content identity. Rich clipboard may carry the exact frozen definition; the destination validates and freezes it before inserting, and conflicting same-name/different-content resources fail atomically.

## Language and layout

Registered commands are parsed as native `CustomSymbol` nodes. Unknown commands remain unknown; the parser never invents a symbol from a command name alone. Reserved core/VisualTeX commands cannot be shadowed.

Role participates in normal atom spacing. Operator symbols use the existing ordered script/limits tail and may use `auto`, `limits` or `nolimits` as their frozen default. Explicit formula-local limits directives override the default without modifying the asset.

Metrics are authored layout inputs. Artwork is a separate scene resource and never masquerades as a font glyph. Font-size changes scale the natural formula output without rebuilding a different asset.

## Vector safety

Supported vector artwork is parsed and validated by Rust. Raw authored SVG/HTML/CSS is never inserted into the DOM or output SVG. The host independently validates artwork node ownership, SHA format, finite geometry, path bounds and paint order before replacing a visible scene.

Current supported legacy shapes include path geometry (M/L/H/V/C/S/Q/T/A/Z, including relative forms), line, circle, ellipse, rectangle, rounded rectangle and polygon. Fill/stroke/stroke-width/line-cap/line-join semantics stay as real SVG vector paint under affine transforms instead of being pre-expanded into approximate outlines. Elliptical arcs are deterministically converted to bounded cubic geometry. Color inheritance remains explicit scene paint.

`clipRect` is supported without flattening it to a final bounding box. Imported/base `transform.matrix` stays inside the clip, while user translate/scale/skew/rotate stays outside it: outer user transform -> clip rectangle -> inner/base matrix. Rust SVG export and the self-owned DOM view preserve the same nesting with generated `<g>`/`<clipPath>` elements; authored SVG/HTML/CSS is still never injected.

The remaining deliberately unsupported legacy artwork features are system-font `text` shapes without an explicit verified font-outline binding and `erase`/boolean-subtraction artwork. Any asset containing one of those unsupported layers remains non-exportable and no partial symbol is drawn. Text support must bind a real validated font outline rather than a browser `font-family` fallback. Erase support must be scoped to artwork inside the same immutable custom asset and must never subtract neighboring formula glyphs.

## Clipboard

P09 structural clipboard carries only identity-free structure plus referenced immutable definitions. It does not carry live NodeIds, session handles or document identities. Pasting a custom symbol into a session that does not yet own the asset freezes the included definition first. Same command/id with different asset content is a conflict.

## Acceptance evidence

`custom_symbols_review.rs` covers resource freezing, validation, insertion, source edits, copy/duplicate/history, operator limits, vector scene validation, rich clipboard and fail-closed unsupported artwork.

`custom-symbol-parity-review.mjs` compares Native and actual WASM responses field-by-field for three representative symbol roles plus affine-stroke and layered-clip definitions, four math styles, two natural sizes, editing/history, rich clipboard and invalid resources. The clip gate requires exact Native/WASM SVG parity and verifies that clip nesting stays between outer and inner transforms.

`custom-symbol-browser-review.mjs` uses an owned Edge instance with real pointer/keyboard/clipboard events, three formula hosts, 45 zoom/DPR artwork-pointer cases, structural insertion and cross-session frozen-asset transfer. It also inspects the generated DOM to verify outer transform -> clip group -> inner matrix without browser-font or raw-markup fallback.

No Office, production application, MathLive or MathJax path is exercised or enabled by this checkpoint.