// Real native/WASM geometry comparison using the same injected font bytes.
// Fonts are read-only local fixtures. No source font or production asset is copied.
import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { createInterface } from 'node:readline';
import { once } from 'node:events';
import { createHash } from 'node:crypto';
import { readFileSync } from 'node:fs';
import { createRequire } from 'node:module';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
const root=resolve(dirname(fileURLToPath(import.meta.url)), '..');
const paths={
  math:process.env.VISUALTEX_TEST_MATH_FONT ?? resolve(root,'../apps/windows/src-windows/artifacts/office-fonts/latinmodern-math.otf'),
  text:process.env.VISUALTEX_TEST_TEXT_FONT ?? 'C:\\Windows\\Fonts\\NotoSansSC-VF.ttf',
};
const expected={
  math:'6075562b771f8b82f0c179e363389684f2dd09de30038269e2628e504bd7be0f',
  text:'763146584cf0710223441356b4395e279021b0806c196614377a7a0174ae074a',
};
const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
const bytes=Object.fromEntries(Object.entries(paths).map(([kind,path])=>[kind,readFileSync(path)]));
for (const kind of Object.keys(bytes)) assert.equal(sha(bytes[kind]),expected[kind],`Fixed ${kind} font fixture differs; do not refresh a golden hash to conceal this.`);
const nativePath=resolve(root,`target/debug/visualtex-engine-test-cli${process.platform==='win32'?'.exe':''}`);
const wasmPath=resolve(root,'web/pkg-node/visualtex_engine_wasm_bg.wasm');
const {EngineRuntime}=createRequire(import.meta.url)(resolve(root,'web/pkg-node/visualtex_engine_wasm.js'));
const wasm=new EngineRuntime();
assert.equal(JSON.parse(wasm.registerFont(new Uint8Array([0,1,2]),0)).status,'error');
const fontIds={};const registrations={};
for (const kind of Object.keys(bytes)) {
  const response=JSON.parse(wasm.registerFont(bytes[kind],0));assert.equal(response.status,'ok',JSON.stringify(response));
  assert.equal(response.result.kind,'fontRegistered');
  const font=response.result.font;assert.equal(font.sha256,expected[kind]);assert.equal(font.faceIndex,0);
  fontIds[kind]=font.id;registrations[kind]=font;
  assert.deepEqual(JSON.parse(wasm.registerFont(bytes[kind],0)),response,'Identical bytes must deduplicate');
}
const native=spawn(nativePath,['--font',paths.math,'--font',paths.text],{stdio:['pipe','pipe','pipe']});
const lines=createInterface({input:native.stdout,crlfDelay:Infinity})[Symbol.asyncIterator]();
let stderr='';native.stderr.on('data',data=>{stderr=(stderr+data.toString()).slice(-12000);});
const timer=setTimeout(()=>native.kill(),90000);
const transcript=createHash('sha256');let cases=0,scenes=0,maxNumericDifference=0;
function equivalent(a,b,path='response') {
  if(typeof a==='number' && typeof b==='number') {
    assert.ok(Number.isFinite(a) && Number.isFinite(b),`nonfinite ${path}`);
    const difference=Math.abs(a-b);maxNumericDifference=Math.max(maxNumericDifference,difference);
    assert.ok(difference<=1e-9,`${path}: ${a} != ${b}`);return;
  }
  if(a===null || b===null || typeof a!=='object' || typeof b!=='object') {assert.equal(a,b,path);return;}
  assert.equal(Array.isArray(a),Array.isArray(b),path);assert.deepEqual(Object.keys(a),Object.keys(b),path);
  for(const key of Object.keys(a)) equivalent(a[key],b[key],`${path}.${key}`);
}
async function send(command,error=null) {
  const input=JSON.stringify({protocol:1,command});const a=JSON.parse(wasm.dispatch(input));
  if(!native.stdin.write(input+'\n')) await once(native.stdin,'drain');
  const next=await lines.next();assert.equal(next.done,false,stderr);const b=JSON.parse(next.value);
  equivalent(a,b,`case${cases}:${command.op}`);transcript.update(input+'\n'+next.value+'\n');cases++;
  if(error) {assert.equal(a.status,'error');assert.equal(a.error.code,error);return a;}
  assert.equal(a.status,'ok',JSON.stringify(a));return a.result;
}
const defaults={mathFont:fontIds.math,textFont:fontIds.text,style:'display',fontSizePx:16,paddingEm:0.125};
const requestLayout=(handle,revision=0,options={},includeSvg=true,error=null)=>send({op:'layout',handle,expectedRevision:revision,options:{...defaults,...options},includeSvg},error);
function validate(scene,svg) {
  scenes++;assert.ok(scene.width>0&&scene.height>0&&scene.baseline>=0&&scene.baseline<=scene.height);
  assert.equal(scene.width,scene.widthEm*scene.fontSizePx);assert.equal(scene.height,scene.heightEm*scene.fontSizePx);
  assert.ok(scene.carets.length>0);assert.equal(new Set(scene.regions.map(r=>r.nodeId)).size,scene.regions.length);
  for(const g of scene.glyphs) {const resource=scene.resources[g.resource];assert.ok(resource);assert.ok(resource.shape.glyphId>0);
    if(resource.shape.ink) {const [a,b,c,d]=resource.shape.ink;
      assert.ok(a*g.scale+g.x>=-1e-9&&b*g.scale+g.y>=-1e-9);
      assert.ok(c*g.scale+g.x<=scene.widthEm+1e-9&&d*g.scale+g.y<=scene.heightEm+1e-9);
    }
  }
  if(svg!==null) {assert.ok(scene.exportReady);assert.ok(svg.startsWith('<svg ')&&svg.endsWith('</svg>'));
    for(const forbidden of ['<text','<image','<script','foreignObject','href=','NaN','Infinity']) assert.ok(!svg.includes(forbidden),forbidden);
  }
}
const sources=[
  'x+1',String.raw`\frac{x}{y}`,String.raw`\frac{x_1+\text{速度}}{y^2}`,
  String.raw`\text{中文 Café office AV}`,String.raw`\frac{\frac{a}{b}}{x^{y^2}}`,
  String.raw`x^{\dfrac{a}{b}}+\frac{\tfrac{c}{d}}{y}`,
  String.raw`x_1^2+\alpha=\beta`,String.raw`\text{<svg \& x>}`,
  String.raw`\sqrt{x}`,String.raw`\sqrt[n+1]{x^2}`,
  String.raw`\sqrt[{\sqrt[3]{n}}]{\frac{x_1+\text{速度}}{y^2}}`,
  String.raw`\sqrt{\dfrac{1}{\dfrac{2}{\dfrac{3}{4}}}}`,
  String.raw`\left(\frac{x}{y}\right)`,String.raw`\left.\sqrt[n]{x}\right]`,
  String.raw`\left\{\dfrac{x}{\dfrac{y}{z}}\right.`,
  String.raw`\left[\left|\sqrt[3]{x^2}\right|+\text{速度}\right]`,
];
try {
  for(const [i,source] of sources.entries()) {
    const created=await send({op:'create',documentId:`layout-parity-${i}`,source});const h=created.handle;
    for(const style of ['display','text','script','scriptScript']) {
      const first=await requestLayout(h,0,{style});validate(first.snapshot,first.svg);
      const again=await requestLayout(h,0,{style});validate(again.snapshot,again.svg);
      assert.equal(again.snapshot.rebuiltFragments,0);assert.equal(again.svg,first.svg);
      const scaled=await requestLayout(h,0,{style,fontSizePx:32});validate(scaled.snapshot,scaled.svg);
      assert.equal(scaled.snapshot.width,first.snapshot.width*2);assert.equal(scaled.snapshot.baseline,first.snapshot.baseline*2);
      assert.deepEqual(scaled.snapshot.glyphs,first.snapshot.glyphs);assert.equal(scaled.snapshot.rebuiltFragments,0);
    }
    await requestLayout(h,99,{},true,'staleRevision');
    await requestLayout(h,0,{mathFont:'unregistered'},true,'invalidInput');
    await send({op:'destroy',handle:h,expectedRevision:0});
    await requestLayout(h,0,{},true,'invalidHandle');
  }
  const source=String.raw`\frac{x_1+\text{速度}}{y^2}`;
  const h=(await send({op:'create',documentId:'layout-edit-parity',source})).handle;
  const initial=await requestLayout(h);validate(initial.snapshot,initial.svg);
  const at=source.indexOf('1');
  await send({op:'patchSource',handle:h,expectedRevision:0,edit:{startUtf16:at,endUtf16:at+1,replacement:'3'}});
  const edited=await requestLayout(h,1);validate(edited.snapshot,edited.svg);
  assert.notEqual(edited.svg,initial.svg);assert.ok(edited.snapshot.reusedFragments>0);
  assert.ok(edited.snapshot.rebuiltFragments<initial.snapshot.rebuiltFragments);
  await send({op:'editorAction',handle:h,expectedRevision:1,eventSequence:1,action:{kind:'undo'}});
  const restored=await requestLayout(h,2);validate(restored.snapshot,restored.svg);assert.equal(restored.svg,initial.svg);
  const editor=(await send({op:'inspectEditor',handle:h,expectedRevision:2})).snapshot;
  assert.equal(editor.document.source,source);
  const chinese=editor.document.analysis.tree.entries[0].node.numerator.entries.find(e=>e.node.kind==='text').node;
  const caret={kind:'text',nodeId:chinese.id,grapheme:2,affinity:'after'};
  await send({op:'editorAction',handle:h,expectedRevision:2,eventSequence:2,action:{kind:'setSelection',selection:{kind:'range',anchor:caret,focus:caret}}});
  const begin=await send({op:'editorAction',handle:h,expectedRevision:2,eventSequence:3,action:{kind:'beginComposition',mode:'text'}});
  const id=begin.result.editor.composition.id;
  await send({op:'editorAction',handle:h,expectedRevision:2,eventSequence:4,action:{kind:'updateComposition',id,preedit:'率'}});
  const preview=await requestLayout(h,2);assert.equal(preview.svg,initial.svg,'Composition preview may not rewrite committed math');
  await send({op:'editorAction',handle:h,expectedRevision:2,eventSequence:5,action:{kind:'commitComposition',id,text:null}});
  const committed=await requestLayout(h,3);validate(committed.snapshot,committed.svg);assert.notEqual(committed.svg,initial.svg);
  assert.equal(committed.snapshot.fonts[1].id,fontIds.text);
  await send({op:'destroy',handle:h,expectedRevision:3});

  {
    const h=(await send({op:'create',documentId:'root-editor-parity',source:''})).handle;
    let revision=0, sequence=0;
    const action=async action=>{const r=await send({op:'editorAction',handle:h,expectedRevision:revision,eventSequence:++sequence,action});revision=r.result.editor.document.revision;return r.result.editor;};
    const edit=command=>action({kind:'edit',command,groupId:null});
    await edit({kind:'insertStructure',structure:'indexedRoot'});
    await edit({kind:'insertText',text:'3',mode:'math'});
    await action({kind:'moveHorizontal',direction:'right',extend:false});
    const done=await edit({kind:'insertText',text:'x',mode:'math'});
    assert.equal(done.document.source,String.raw`\sqrt[3]{x}`);
    const initial=await requestLayout(h,revision);validate(initial.snapshot,initial.svg);
    const beforeIds=done.document.analysis.tree.entries[0].node;
    const row={kind:'row',nodeId:done.document.analysis.tree.id,offset:0,affinity:'after'};
    await action({kind:'setSelection',selection:{kind:'range',anchor:row,focus:{...row,offset:1}}});
    const copy=await edit({kind:'duplicateSelection'});
    assert.equal(copy.document.analysis.facts.radicals,2);
    assert.notEqual(copy.document.analysis.tree.entries[1].node.radicand.id,beforeIds.radicand.id);
    await action({kind:'undo'});
    const restored=await requestLayout(h,revision);validate(restored.snapshot,restored.svg);assert.equal(restored.svg,initial.svg);
    await send({op:'destroy',handle:h,expectedRevision:revision});
  }
  {
    const h=(await send({op:'create',documentId:'fence-editor-parity',source:''})).handle;
    let revision=0,sequence=0;
    const action=async action=>{const r=await send({op:'editorAction',handle:h,expectedRevision:revision,eventSequence:++sequence,action});revision=r.result.editor.document.revision;return r.result;};
    const edit=command=>action({kind:'edit',command,groupId:null});
    await edit({kind:'typeDelimiter',text:'('});await edit({kind:'typeDelimiter',text:'['});
    await edit({kind:'insertText',text:'x',mode:'math'});
    await edit({kind:'typeDelimiter',text:')'});
    const before=await requestLayout(h,revision);validate(before.snapshot,before.svg);
    const closedInner=await edit({kind:'typeDelimiter',text:']'});
    assert.equal(closedInner.contentChanged,false);
    const closedOuter=await edit({kind:'typeDelimiter',text:')'});
    assert.equal(closedOuter.contentChanged,false);
    assert.equal(closedOuter.editor.document.source,String.raw`\left(\left[x)\right]\right)`);
    const after=await requestLayout(h,revision);assert.equal(after.svg,before.svg);assert.equal(after.snapshot.rebuiltFragments,0);
    await action({kind:'undo'});const undone=await requestLayout(h,revision);validate(undone.snapshot,undone.svg);
    await send({op:'destroy',handle:h,expectedRevision:revision});
  }
  for(const [i,draft] of ['', '{}','%only comment',String.raw`\frac{}{} `,String.raw`\frac{{}}{y}`,String.raw`x^{{}}`,String.raw`\sqrt[]{x}`,String.raw`\sqrt{}`,String.raw`\left(\right)`].entries()) {
    const h=(await send({op:'create',documentId:`blank-${i}`,source:draft})).handle;
    const result=await requestLayout(h,0,{},false);validate(result.snapshot,result.svg);assert.equal(result.snapshot.exportReady,false);
    await requestLayout(h,0,{},true,'incompleteSource');await send({op:'destroy',handle:h,expectedRevision:0});
  }
  for(const [i,[source,error]] of [[String.raw`\hat{x}`,'unsupportedSyntax'],[String.raw`\frac{x}{`,'incompleteSource']].entries()) {
    const h=(await send({op:'create',documentId:`unsupported-${i}`,source})).handle;
    await requestLayout(h,0,{},true,error);const doc=await send({op:'inspectDocument',handle:h});assert.equal(doc.snapshot.source,source);
    await send({op:'destroy',handle:h,expectedRevision:0});
  }
  assert.equal((await send({op:'stats'})).activeSessions,0);
  console.log(JSON.stringify({status:'PASS',actualNativeExecution:true,actualWasmExecution:true,requestCases:cases,validatedScenes:scenes,
    maxNumericDifference,geometricToleranceEm:1e-9,exactSvgParity:true,fonts:registrations,
    nativeSha256:sha(readFileSync(nativePath)),wasmSha256:sha(readFileSync(wasmPath)),transcriptSha256:transcript.digest('hex'),
    scope:'Headless K0 geometry, real font shaping, SVG, cache and composition-state parity. No actual OS IME, browser input or Office UI acceptance.'},null,2));
} finally {
  clearTimeout(timer);wasm.free();native.stdin.end();lines.return?.();
  if(native.exitCode===null) native.kill();
}
