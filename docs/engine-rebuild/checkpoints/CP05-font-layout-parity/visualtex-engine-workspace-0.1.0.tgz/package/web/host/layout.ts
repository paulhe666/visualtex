// Internal geometry only. Office export units and DTOs remain unchanged.
import type { Position } from './editing';
export type MathStyle = 'display' | 'text' | 'script' | 'scriptScript';
export interface LayoutOptions {
  mathFont: string;
  textFont: string | null;
  style: MathStyle;
  fontSizePx: number;
  paddingEm: number;
}
export interface FontIdentity {
  id: string;
  sha256: string;
  faceIndex: number;
  unitsPerEm: number;
  variationAxes: [string, number][];
}
export interface Rect { xMin: number; yMin: number; xMax: number; yMax: number }
export type PathOp =
  | { op: 'move' | 'line'; points: [number, number] }
  | { op: 'quad'; points: [number, number, number, number] }
  | { op: 'cubic'; points: [number, number, number, number, number, number] }
  | { op: 'close' };
export interface GlyphShape {
  glyphId: number;
  advance: number;
  ink: [number, number, number, number] | null;
  italicCorrection: number;
  path: PathOp[];
}
export interface CaretStop {
  position: Position;
  x: number;
  baseline: number;
  top: number;
  bottom: number;
  depth: number;
}
export interface LayoutSnapshot {
  documentId: string;
  revision: number;
  sourceId: number;
  fontSizePx: number;
  width: number;
  height: number;
  baseline: number;
  widthEm: number;
  heightEm: number;
  baselineEm: number;
  advanceEm: number;
  ink: Rect | null;
  fonts: FontIdentity[];
  resources: { fontId: string; shape: GlyphShape }[];
  glyphs: { nodeId: number; resource: number; x: number; y: number; scale: number }[];
  rules: { nodeId: number; rect: Rect }[];
  carets: CaretStop[];
  regions: { nodeId: number; role: string; logical: Rect; ink: Rect | null; depth: number }[];
  exportReady: boolean;
  rebuiltFragments: number;
  reusedFragments: number;
}
