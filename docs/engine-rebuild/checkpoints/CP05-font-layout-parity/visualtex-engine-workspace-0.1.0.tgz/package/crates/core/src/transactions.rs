//! Mathematical tree operations. Source parsing is used only for explicit
//! PasteLatex; ordinary typing, navigation and deletion never reparse LaTeX.
use std::collections::BTreeSet;
use std::sync::Arc;
use serde::{Deserialize, Serialize};
use unicode_segmentation::UnicodeSegmentation;
use crate::error::{EngineError, EngineResult, ErrorCode};
use crate::model::{Grouping, IdAllocator, Node, NodeKind, RowEntry, ScriptKind, ScriptSlot};
use crate::parser::{self, ParseResult};
use crate::position_map::{PositionMap, PositionStep, merge_text_map};
use crate::positions::{Horizontal, NormalizedRange, Position, Selection, TreeIndex, grapheme_byte, invalid_position};
use crate::projection::project_tree;
use crate::session::NodeId;
use crate::source::{MAX_SOURCE_BYTES, SourceText};
use crate::symbols::{literal_class, named_symbol};

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub enum InputMode { Math, Text }

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub enum StructureKind { Fraction, Superscript, Subscript, Text }

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(tag = "kind", rename_all = "camelCase", rename_all_fields = "camelCase", deny_unknown_fields)]
pub enum EditCommand {
    InsertText { text: String, mode: InputMode },
    ReplaceRange { text: String, mode: InputMode },
    InsertStructure { structure: StructureKind },
    DeleteBackward,
    DeleteForward,
    PasteLatex { latex: String },
    DuplicateSelection,
    SplitText,
    MergeText { direction: Horizontal },
    SetStyle { style: String },
}

pub struct PreparedEdit {
    pub document: Arc<ParseResult>,
    pub selection: Selection,
    pub position_map: PositionMap,
    pub changed: bool,
}

pub fn prepare(document: &Arc<ParseResult>, selection: &Selection, command: &EditCommand,
    source_id: u32, ids: &mut IdAllocator) -> EngineResult<PreparedEdit>
{
    if !document.complete {
        return Err(EngineError::new(ErrorCode::IncompleteSource, "Resolve the current source draft before a visual edit"));
    }
    if !document.supported {
        return Err(EngineError::new(ErrorCode::UnsupportedSyntax, "Unsupported source remains preserved; resolve it explicitly before a visual edit"));
    }
    TreeIndex::new(&document.tree)?.validate_selection(selection)?;
    let mut working_ids = ids.clone();
    let mut builder = Builder { tree: Arc::clone(&document.tree), selection: selection.clone(),
        ids: &mut working_ids, overrides: Vec::new(), changed: false };
    match command {
        EditCommand::InsertText { text, mode } | EditCommand::ReplaceRange { text, mode } => builder.insert_text(text, *mode)?,
        EditCommand::InsertStructure { structure } => builder.insert_structure(*structure)?,
        EditCommand::DeleteBackward => builder.delete(Horizontal::Left)?,
        EditCommand::DeleteForward => builder.delete(Horizontal::Right)?,
        EditCommand::PasteLatex { latex } => builder.paste(latex, source_id)?,
        EditCommand::DuplicateSelection => builder.duplicate()?,
        EditCommand::SplitText => builder.split_command()?,
        EditCommand::MergeText { direction } => builder.merge(*direction)?,
        EditCommand::SetStyle { .. } => return Err(EngineError::new(ErrorCode::UnsupportedSyntax, "Style nodes are not implemented by the K0 capability")),
    }
    if builder.changed {
        crate::model::validate_tree(&builder.tree)?;
        let normalized = normalize_literal_clusters(&builder.tree);
        if !Arc::ptr_eq(&normalized, &builder.tree) {
            let normalization_map = PositionMap::between(&builder.tree, &normalized, Vec::new())?;
            builder.selection = normalization_map.apply_selection(&builder.selection, &TreeIndex::new(&normalized)?)?;
            builder.tree = normalized;
        }
    }
    let result = if builder.changed {
        if source_id <= document.source.id() {
            return Err(EngineError::new(ErrorCode::InvalidInput, "Visual edits require a fresh source identity"));
        }
        project_tree(builder.tree, source_id)?
    } else { Arc::clone(document) };
    let new_index = TreeIndex::new(&result.tree)?;
    new_index.validate_selection(&builder.selection)?;
    let position_map = PositionMap::between(&document.tree, &result.tree, builder.overrides)?;
    let prepared = PreparedEdit { document: result, selection: builder.selection, position_map, changed: builder.changed };
    // Speculative paste roots or other temporary nodes are not document edits.
    // A no-op must leave the monotonic identity allocator unchanged as well.
    if prepared.changed { *ids = working_ids; }
    Ok(prepared)
}

struct Builder<'a> {
    tree: Arc<Node>,
    selection: Selection,
    ids: &'a mut IdAllocator,
    overrides: Vec<PositionStep>,
    changed: bool,
}

impl Builder<'_> {
    fn node(&mut self, kind: NodeKind) -> EngineResult<Arc<Node>> {
        Ok(Arc::new(Node { id: self.ids.allocate()?, origin: None, kind }))
    }
    fn row(&mut self, grouping: Grouping, entries: Vec<RowEntry>) -> EngineResult<Arc<Node>> {
        self.node(NodeKind::Row { grouping, entries, trailing: String::new() })
    }
    fn normalized(&self) -> EngineResult<NormalizedRange> {
        TreeIndex::new(&self.tree)?.normalize_range(&self.selection)
    }
    fn update(&mut self, id: NodeId, f: impl FnOnce(&mut Node) -> EngineResult<()>) -> EngineResult<()> {
        self.tree = update_node(&self.tree, id, f)?;
        self.changed = true;
        Ok(())
    }
    fn row_entries(&self, id: NodeId) -> EngineResult<Vec<RowEntry>> {
        let node = self.tree.find(id).ok_or_else(invalid_position)?;
        match &node.kind { NodeKind::Row { entries, .. } => Ok(entries.clone()), _ => Err(invalid_position()) }
    }
    fn splice_row(&mut self, id: NodeId, start: usize, end: usize, mut replacement: Vec<RowEntry>, preserve_trivia: bool) -> EngineResult<()> {
        let old_entries = self.row_entries(id)?;
        if start > end || end > old_entries.len() { return Err(invalid_position()); }
        let mut surviving = BTreeSet::new();
        for entry in &replacement { entry.node.visit(&mut |node| { surviving.insert(node.id); }); }
        let mut removed = BTreeSet::new();
        for entry in &old_entries[start..end] {
            entry.node.visit(&mut |node| { if !surviving.contains(&node.id) { removed.insert(node.id); } });
        }
        self.update(id, move |node| {
            let NodeKind::Row { entries, trailing, .. } = &mut node.kind else { return Err(invalid_position()); };
            if start > end || end > entries.len() { return Err(invalid_position()); }
            let trivia = if preserve_trivia { entries[start..end].iter().map(|e| e.leading.as_str()).collect::<String>() } else { String::new() };
            if !trivia.is_empty() {
                if let Some(first) = replacement.first_mut() { first.leading.insert_str(0, &trivia); }
                else if let Some(next) = entries.get_mut(end) { next.leading.insert_str(0, &trivia); }
                else { trailing.insert_str(0, &trivia); }
            }
            entries.splice(start..end, replacement);
            Ok(())
        })?;
        // Include transient split nodes, not just IDs from the original tree.
        // Their source anchors may have been introduced by an earlier step in
        // this same transaction before that fragment was replaced/deleted.
        for node_id in removed {
            self.overrides.push(PositionStep::Removed { node_id, fallback: Position::row(id, start) });
        }
        Ok(())
    }
    fn replace_text(&mut self, id: NodeId, start: usize, end: usize, replacement: &str) -> EngineResult<()> {
        if replacement.len() > MAX_SOURCE_BYTES { return Err(EngineError::new(ErrorCode::ResourceLimit, "Text insertion exceeds the source budget")); }
        let old = self.tree.find(id).ok_or_else(invalid_position)?;
        let NodeKind::Text { text, .. } = &old.kind else { return Err(invalid_position()); };
        let byte_start = grapheme_byte(text, start)?;
        let byte_end = grapheme_byte(text, end)?;
        if byte_start > byte_end { return Err(invalid_position()); }
        if &text[byte_start..byte_end] == replacement {
            self.selection = Selection::caret(Position::text(id, end));
            return Ok(());
        }
        let mut new_text = text.clone();
        new_text.replace_range(byte_start..byte_end, replacement);
        let caret_byte = byte_start + replacement.len();
        let mut boundaries: Vec<_> = new_text.grapheme_indices(true).map(|(b,_)| b).collect();
        boundaries.push(new_text.len());
        let caret = match boundaries.binary_search(&caret_byte) { Ok(i) | Err(i) => i };
        self.update(id, move |node| {
            let NodeKind::Text { text, .. } = &mut node.kind else { return Err(invalid_position()); };
            *text = new_text; Ok(())
        })?;
        self.selection = Selection::caret(Position::text(id, caret));
        Ok(())
    }
    fn math_entries(&mut self, text: &str) -> EngineResult<Vec<RowEntry>> {
        if text.len() > MAX_SOURCE_BYTES { return Err(EngineError::new(ErrorCode::ResourceLimit, "Math insertion exceeds the source budget")); }
        let mut entries = Vec::new();
        for grapheme in text.graphemes(true) {
            if entries.len() >= crate::model::MAX_NODES {
                return Err(EngineError::new(ErrorCode::ResourceLimit, "Inserted math atoms exceed the node budget"));
            }
            if grapheme.chars().all(char::is_whitespace) { continue; }
            if grapheme.chars().any(char::is_control) || matches!(grapheme, "\\" | "^" | "_" | "~") {
                return Err(EngineError::new(ErrorCode::UnsupportedSyntax, "Use a structural command or explicit LaTeX paste for this math input"));
            }
            let escaped = match grapheme { "{" => Some("\\{"), "}" => Some("\\}"), "%" => Some("\\%"),
                "&" => Some("\\&"), "#" => Some("\\#"), "$" => Some("\\$"), _ => None };
            let (value, class, command) = if let Some(command) = escaped {
                let (value, class) = named_symbol(command).unwrap(); (value.to_owned(), class, Some(command.into()))
            } else {
                if grapheme == "'" { return Err(EngineError::new(ErrorCode::UnsupportedSyntax, "Prime notation is outside the K0 structural capability")); }
                (grapheme.to_owned(), literal_class(grapheme), None)
            };
            entries.push(RowEntry { leading: String::new(), node: self.node(NodeKind::Symbol { value, class, command })? });
        }
        Ok(entries)
    }
    fn insert_text(&mut self, text: &str, mode: InputMode) -> EngineResult<()> {
        let range = self.normalized()?;
        if let NormalizedRange::Text { node_id, start, end } = range {
            return self.replace_text(node_id, start as usize, end as usize, text);
        }
        let NormalizedRange::Row { node_id, start, end, .. } = range else { unreachable!() };
        if text.is_empty() {
            if start != end { self.splice_row(node_id, start as usize, end as usize, Vec::new(), true)?; }
            self.selection = Selection::caret(Position::row(node_id, start as usize));
            return Ok(());
        }
        if mode == InputMode::Text && start == end {
            let entries = self.row_entries(node_id)?;
            if start > 0 {
                if let NodeKind::Text { text: previous, .. } = &entries[start as usize - 1].node.kind {
                    return self.replace_text(entries[start as usize - 1].node.id, previous.graphemes(true).count(), previous.graphemes(true).count(), text);
                }
            }
            if let Some(entry) = entries.get(start as usize) {
                if matches!(entry.node.kind, NodeKind::Text { .. }) { return self.replace_text(entry.node.id, 0, 0, text); }
            }
        }
        let entries = match mode {
            InputMode::Math => self.math_entries(text)?,
            InputMode::Text => vec![RowEntry { leading: String::new(), node: self.node(NodeKind::Text {
                command: "\\text".into(), before_body: String::new(), text: text.into() })? }],
        };
        if entries.is_empty() && start == end { return Ok(()); }
        let count = entries.len();
        let text_target = if mode == InputMode::Text { Some(entries[0].node.id) } else { None };
        self.splice_row(node_id, start as usize, end as usize, entries, true)?;
        self.selection = Selection::caret(match text_target {
            Some(id) => Position::text(id, text.graphemes(true).count()),
            None => Position::row(node_id, start as usize + count),
        });
        Ok(())
    }
    fn split_text(&mut self, id: NodeId, at: usize) -> EngineResult<(NodeId, NodeId, usize)> {
        let index = TreeIndex::new(&self.tree)?;
        let (row, offset) = index.row_owner(id)?;
        let old = index.node(id)?;
        let NodeKind::Text { command, before_body, text } = &old.kind else { return Err(invalid_position()); };
        let byte = grapheme_byte(text, at)?;
        let mut left = old.clone(); left.origin = None;
        if let NodeKind::Text { text: value, .. } = &mut left.kind { *value = text[..byte].into(); }
        let right_kind = NodeKind::Text { command: command.clone(), before_body: String::new(), text: text[byte..].into() };
        let _ = before_body;
        let right = self.node(right_kind)?;
        let right_id = right.id;
        self.splice_row(row, offset, offset + 1, vec![
            RowEntry { leading: String::new(), node: Arc::new(left) }, RowEntry { leading: String::new(), node: right },
        ], true)?;
        self.overrides.push(PositionStep::TextSplit { node_id: id, right_id, at: at as u32 });
        self.selection = Selection::caret(Position::text(right_id, 0));
        Ok((row, right_id, offset + 1))
    }
    /// Structural insertion inside text first splits only that TextRun. The
    /// unselected prefix/suffix remain editable text with explicit position maps.
    fn ensure_row_range(&mut self) -> EngineResult<(NodeId, usize, usize)> {
        match self.normalized()? {
            NormalizedRange::Row { node_id, start, end, .. } => Ok((node_id, start as usize, end as usize)),
            NormalizedRange::Text { node_id, start, end } => {
                let index = TreeIndex::new(&self.tree)?;
                let (row, offset) = index.row_owner(node_id)?;
                let NodeKind::Text { text, .. } = &index.node(node_id)?.kind else { return Err(invalid_position()); };
                let len = text.graphemes(true).count();
                let (start, end) = (start as usize, end as usize);
                if start == end {
                    if start == 0 { return Ok((row, offset, offset)); }
                    if start == len { return Ok((row, offset + 1, offset + 1)); }
                    self.split_text(node_id, start)?;
                    return Ok((row, offset + 1, offset + 1));
                }
                if end < len { self.split_text(node_id, end)?; }
                if start > 0 {
                    self.split_text(node_id, start)?;
                    Ok((row, offset + 1, offset + 2))
                } else { Ok((row, offset, offset + 1)) }
            }
        }
    }
    fn insert_structure(&mut self, structure: StructureKind) -> EngineResult<()> {
        let (row, mut start, end) = self.ensure_row_range()?;
        let mut entries = self.row_entries(row)?;
        if matches!(structure, StructureKind::Superscript | StructureKind::Subscript) && start == end && start > 0 {
            let script = if structure == StructureKind::Superscript { ScriptKind::Superscript } else { ScriptKind::Subscript };
            if let NodeKind::Scripts { slots, .. } = &entries[start - 1].node.kind {
                if let Some(slot) = slots.iter().find(|slot| slot.script == script) {
                    self.selection = Selection::caret(Position::row(slot.argument.id, 0)); return Ok(());
                }
                let target = entries[start - 1].node.id;
                let argument = self.row(Grouping::Braced, Vec::new())?;
                let arg_id = argument.id;
                self.update(target, move |node| {
                    let NodeKind::Scripts { slots, .. } = &mut node.kind else { return Err(invalid_position()); };
                    slots.push(ScriptSlot { script, before_marker: String::new(), before_argument: String::new(), argument }); Ok(())
                })?;
                self.selection = Selection::caret(Position::row(arg_id, 0)); return Ok(());
            }
            start -= 1;
        }
        let selected = entries.drain(start..end).collect::<Vec<_>>();
        let (node, focus) = match structure {
            StructureKind::Fraction => {
                let numerator = self.row(Grouping::Braced, selected)?;
                let denominator = self.row(Grouping::Braced, Vec::new())?;
                let focus = if numerator.is_empty_row() { numerator.id } else { denominator.id };
                let node = self.node(NodeKind::Fraction { command: "\\frac".into(), before_numerator: String::new(),
                    numerator, before_denominator: String::new(), denominator })?;
                (node, Position::row(focus, 0))
            }
            StructureKind::Superscript | StructureKind::Subscript => {
                let grouping = if selected.len() == 1 && !matches!(selected[0].node.kind, NodeKind::Scripts { .. }) { Grouping::Bare } else { Grouping::Braced };
                let base = self.row(grouping, selected)?;
                let argument = self.row(Grouping::Braced, Vec::new())?;
                let focus = if base.is_empty_row() { base.id } else { argument.id };
                let script = if structure == StructureKind::Superscript { ScriptKind::Superscript } else { ScriptKind::Subscript };
                let node = self.node(NodeKind::Scripts { base, slots: vec![ScriptSlot { script, before_marker: String::new(),
                    before_argument: String::new(), argument }] })?;
                (node, Position::row(focus, 0))
            }
            StructureKind::Text => {
                let mut text = String::new();
                for entry in selected { text.push_str(&crate::model::latex(&entry.node, crate::model::LatexMode::Lossless)); }
                let node = self.node(NodeKind::Text { command: "\\text".into(), before_body: String::new(), text })?;
                let focus = Position::text(node.id, 0); (node, focus)
            }
        };
        self.splice_row(row, start, end, vec![RowEntry { leading: String::new(), node }], false)?;
        self.selection = Selection::caret(focus); Ok(())
    }
    fn delete(&mut self, direction: Horizontal) -> EngineResult<()> {
        let range = self.normalized()?;
        match range {
            NormalizedRange::Text { node_id, start, end } => {
                if start != end { return self.replace_text(node_id, start as usize, end as usize, ""); }
                let NodeKind::Text { text, .. } = &self.tree.find(node_id).unwrap().kind else { unreachable!() };
                let count = text.graphemes(true).count() as u32;
                if direction == Horizontal::Left && start > 0 { return self.replace_text(node_id, start as usize - 1, start as usize, ""); }
                if direction == Horizontal::Right && start < count { return self.replace_text(node_id, start as usize, start as usize + 1, ""); }
                self.selection = TreeIndex::new(&self.tree)?.move_horizontal(&self.selection, direction, false)?;
                Ok(())
            }
            NormalizedRange::Row { node_id, start, end, .. } => {
                if start != end {
                    self.splice_row(node_id, start as usize, end as usize, Vec::new(), true)?;
                    self.selection = Selection::caret(Position::row(node_id, start as usize)); return Ok(());
                }
                let entries = self.row_entries(node_id)?;
                let offset = if direction == Horizontal::Left { start.checked_sub(1).map(|v| v as usize) }
                    else { ((start as usize) < entries.len()).then_some(start as usize) };
                let Some(offset) = offset else {
                    self.selection = TreeIndex::new(&self.tree)?.move_horizontal(&self.selection, direction, false)?;
                    return Ok(());
                };
                let target = &entries[offset].node;
                match &target.kind {
                    NodeKind::Symbol { .. } | NodeKind::EmptySlot { .. } => {
                        self.splice_row(node_id, offset, offset+1, Vec::new(), true)?;
                        self.selection = Selection::caret(Position::row(node_id, offset));
                    }
                    NodeKind::Text { text, .. } => {
                        let count = text.graphemes(true).count();
                        if count == 0 {
                            self.splice_row(node_id, offset, offset+1, Vec::new(), true)?;
                            self.selection = Selection::caret(Position::row(node_id, offset));
                        } else if direction == Horizontal::Left { self.replace_text(target.id, count-1, count, "")?; }
                        else { self.replace_text(target.id, 0, 1, "")?; }
                    }
                    _ => { self.selection = Selection::Node { node_id: target.id }; }
                }
                Ok(())
            }
        }
    }
    fn paste(&mut self, latex: &str, source_id: u32) -> EngineResult<()> {
        let root_id = self.ids.allocate()?;
        let parsed = parser::parse(SourceText::new(source_id, latex)?, root_id, self.ids)?;
        if !parsed.complete { return Err(EngineError::new(ErrorCode::IncompleteSource, "Pasted source is incomplete; original document is unchanged")); }
        if !parsed.supported { return Err(EngineError::new(ErrorCode::UnsupportedSyntax, "Pasted source exceeds the current visual capability; original document is unchanged")); }
        let NodeKind::Row { entries, trailing, .. } = &parsed.tree.kind else { unreachable!() };
        let mut replacement = entries.clone();
        // Preserve final pasted trivia by attaching it to the insertion's next
        // neighbor (or row tail); do not silently discard source comments.
        let (row, start, end) = self.ensure_row_range()?;
        let count = replacement.len();
        if count == 0 && start == end && trailing.is_empty() { return Ok(()); }
        self.splice_row(row, start, end, std::mem::take(&mut replacement), true)?;
        if !trailing.is_empty() {
            let trailing = trailing.clone();
            self.update(row, move |node| {
                let NodeKind::Row { entries, trailing: tail, .. } = &mut node.kind else { return Err(invalid_position()); };
                if let Some(next) = entries.get_mut(start+count) { next.leading.insert_str(0, &trailing); }
                else { tail.insert_str(0, &trailing); }
                Ok(())
            })?;
        }
        self.selection = Selection::caret(Position::row(row, start+count)); Ok(())
    }
    fn duplicate(&mut self) -> EngineResult<()> {
        match self.normalized()? {
            NormalizedRange::Text { node_id, start, end } => {
                if start == end { return Ok(()); }
                let NodeKind::Text { text, .. } = &self.tree.find(node_id).unwrap().kind else { unreachable!() };
                let copy = text[grapheme_byte(text, start as usize)?..grapheme_byte(text, end as usize)?].to_owned();
                self.replace_text(node_id, end as usize, end as usize, &copy)
            }
            NormalizedRange::Row { node_id, start, end, .. } => {
                if start == end { return Ok(()); }
                let entries = self.row_entries(node_id)?;
                let mut copies = Vec::new();
                for entry in &entries[start as usize..end as usize] {
                    copies.push(RowEntry { leading: entry.leading.clone(), node: clone_with_fresh_ids(&entry.node, self.ids)? });
                }
                self.splice_row(node_id, end as usize, end as usize, copies, true)?;
                self.selection = Selection::Range { anchor: Position::row(node_id, end as usize),
                    focus: Position::row(node_id, (end + end - start) as usize) };
                Ok(())
            }
        }
    }
    fn split_command(&mut self) -> EngineResult<()> {
        let NormalizedRange::Text { node_id, start, end } = self.normalized()? else {
            return Err(EngineError::new(ErrorCode::InvalidPosition, "Text split requires a text caret")); };
        if start != end { return Err(EngineError::new(ErrorCode::InvalidPosition, "Text split requires a collapsed caret")); }
        self.split_text(node_id, start as usize).map(|_| ())
    }
    fn merge(&mut self, direction: Horizontal) -> EngineResult<()> {
        let range = self.normalized()?;
        let (row, boundary) = match range {
            NormalizedRange::Row { node_id, start, end, .. } if start == end => (node_id, start as usize),
            NormalizedRange::Text { node_id, start, end } if start == end => {
                let index = TreeIndex::new(&self.tree)?;
                let (row, offset) = index.row_owner(node_id)?;
                let NodeKind::Text { text, .. } = &index.node(node_id)?.kind else { return Err(invalid_position()); };
                let at_boundary = if direction == Horizontal::Left { start == 0 }
                    else { start as usize == text.graphemes(true).count() };
                if !at_boundary {
                    return Err(EngineError::new(ErrorCode::InvalidPosition, "Text merge requires the matching start or end boundary"));
                }
                (row, if direction == Horizontal::Left { offset } else { offset+1 })
            }
            _ => return Err(EngineError::new(ErrorCode::InvalidPosition, "Text merge requires a caret next to adjacent text runs")),
        };
        let entries = self.row_entries(row)?;
        if boundary == 0 || boundary >= entries.len() { return Err(invalid_position()); }
        let left = &entries[boundary-1].node; let right = &entries[boundary].node;
        let (NodeKind::Text { text: a, command: ac, .. }, NodeKind::Text { text: b, command: bc, .. }) = (&left.kind, &right.kind)
            else { return Err(EngineError::new(ErrorCode::InvalidPosition, "Only adjacent matching text runs can merge")); };
        if ac != bc { return Err(EngineError::new(ErrorCode::UnsupportedSyntax, "Text styles differ")); }
        let merged = format!("{a}{b}");
        let left_map = merge_text_map(left.id, left.id, a, &merged, 0)?;
        let right_map = merge_text_map(right.id, left.id, b, &merged, a.len())?;
        let focus = Position::text(left.id, a.graphemes(true).count());
        let mut combined = left.as_ref().clone(); combined.origin = None;
        if let NodeKind::Text { text, .. } = &mut combined.kind { *text = merged; }
        // Preserve text-relative anchors before the splice records a fallback
        // for the removed right node; otherwise its positions collapse too early.
        self.overrides.extend([left_map, right_map]);
        self.splice_row(row, boundary-1, boundary+1, vec![RowEntry { leading: String::new(), node: Arc::new(combined) }], true)?;
        self.selection = Selection::caret(focus); Ok(())
    }
}

/// A Unicode grapheme can span two separately delivered input events. Only
/// literal adjacent math atoms with no source trivia between them may join.
/// Untouched subtrees are never normalized speculatively.
fn normalize_literal_clusters(node: &Arc<Node>) -> Arc<Node> {
    if node.origin.is_some() { return Arc::clone(node); }
    let mut result = node.as_ref().clone();
    let mut changed = false;
    let mut normalize_child = |child: &mut Arc<Node>| {
        let next = normalize_literal_clusters(child);
        if !Arc::ptr_eq(child, &next) { *child = next; changed = true; }
    };
    match &mut result.kind {
        NodeKind::Row { entries, .. } => {
            for entry in entries.iter_mut() { normalize_child(&mut entry.node); }
            let mut index = 0;
            while index + 1 < entries.len() {
                let combined = match (&entries[index].node.kind, &entries[index+1].node.kind) {
                    (NodeKind::Symbol { value: a, command: None, .. }, NodeKind::Symbol { value: b, command: None, .. })
                        if entries[index+1].leading.is_empty() => {
                            let text = format!("{a}{b}");
                            (text.graphemes(true).count() == 1).then_some(text)
                        }
                    _ => None,
                };
                if let Some(text) = combined {
                    let left = Arc::make_mut(&mut entries[index].node);
                    left.origin = None;
                    left.kind = NodeKind::Symbol { class: literal_class(&text), value: text, command: None };
                    entries.remove(index+1); changed = true;
                } else { index += 1; }
            }
        }
        NodeKind::Fraction { numerator, denominator, .. } => { normalize_child(numerator); normalize_child(denominator); }
        NodeKind::Scripts { base, slots } => { normalize_child(base); for slot in slots { normalize_child(&mut slot.argument); } }
        _ => {}
    }
    if changed { Arc::new(result) } else { Arc::clone(node) }
}

pub fn clone_with_fresh_ids(node: &Arc<Node>, ids: &mut IdAllocator) -> EngineResult<Arc<Node>> {
    let mut result = node.as_ref().clone();
    result.id = ids.allocate()?;
    match &mut result.kind {
        NodeKind::Row { entries, .. } => for entry in entries { entry.node = clone_with_fresh_ids(&entry.node, ids)?; },
        NodeKind::Fraction { numerator, denominator, .. } => {
            *numerator = clone_with_fresh_ids(numerator, ids)?; *denominator = clone_with_fresh_ids(denominator, ids)?;
        }
        NodeKind::Scripts { base, slots } => {
            *base = clone_with_fresh_ids(base, ids)?;
            for slot in slots { slot.argument = clone_with_fresh_ids(&slot.argument, ids)?; }
        }
        _ => {}
    }
    Ok(Arc::new(result))
}

fn update_node(root: &Arc<Node>, target: NodeId, f: impl FnOnce(&mut Node) -> EngineResult<()>) -> EngineResult<Arc<Node>> {
    let index = TreeIndex::new(root)?;
    let mut path = Vec::new(); let mut current = target;
    loop {
        path.push(current);
        let entry = index.nodes.get(&current).ok_or_else(invalid_position)?;
        match entry.parent { Some(parent) => current = parent, None => break }
    }
    path.reverse();
    fn apply<F: FnOnce(&mut Node) -> EngineResult<()>>(node: &Arc<Node>, path: &[NodeId], f: &mut Option<F>) -> EngineResult<Arc<Node>> {
        if path.first() != Some(&node.id) { return Err(invalid_position()); }
        let mut changed = node.as_ref().clone(); changed.origin = None;
        if path.len() == 1 { f.take().ok_or_else(invalid_position)?(&mut changed)?; }
        else {
            let next = path[1]; let mut found = false;
            let mut visit = |child: &mut Arc<Node>| -> EngineResult<()> {
                if child.id == next { *child = apply(child, &path[1..], f)?; found = true; } Ok(())
            };
            match &mut changed.kind {
                NodeKind::Row { entries, .. } => for entry in entries { visit(&mut entry.node)?; },
                NodeKind::Fraction { numerator, denominator, .. } => { visit(numerator)?; visit(denominator)?; }
                NodeKind::Scripts { base, slots } => { visit(base)?; for slot in slots { visit(&mut slot.argument)?; } }
                _ => {}
            }
            if !found { return Err(invalid_position()); }
        }
        Ok(Arc::new(changed))
    }
    apply(root, &path, &mut Some(f))
}
