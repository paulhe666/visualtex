// Internal engine v1 only. These types are NOT Office DTOs or persisted Office metadata.
export type NodeId = number;
export type Revision = number;
export type SessionHandle = number;
export interface SessionSnapshot {
  documentId: string;
  revision: Revision;
  rootId: NodeId;
  source: string;
}
export type EngineCommand =
  | { op: 'create'; documentId: string }
  | { op: 'inspect'; handle: SessionHandle; expectedRevision?: Revision }
  | { op: 'destroy'; handle: SessionHandle; expectedRevision: Revision }
  | { op: 'stats' };
export interface EngineRequest { protocol: 1; command: EngineCommand }
export type EngineReply =
  | { kind: 'session'; handle: SessionHandle; snapshot: SessionSnapshot }
  | { kind: 'destroyed'; handle: SessionHandle }
  | { kind: 'stats'; protocol: 1; activeSessions: number };
export type EngineErrorCode =
  | 'invalidInput' | 'unsupportedProtocol' | 'invalidHandle' | 'conflict'
  | 'staleRevision' | 'resourceLimit' | 'invalidPosition' | 'unsupportedSyntax'
  | 'incompleteSource' | 'missingFont';
export type EngineResponse =
  | { status: 'ok'; result: EngineReply }
  | { status: 'error'; error: { code: EngineErrorCode; message: string } };
