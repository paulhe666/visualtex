use serde::{Deserialize, Serialize};
use crate::error::{EngineError, EngineResult, ErrorCode};

/// Local to a document; never an Office formulaId, source offset or JS pointer.
#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Serialize, Deserialize)]
#[serde(transparent)]
pub struct NodeId(pub u32);

#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Serialize, Deserialize)]
#[serde(transparent)]
pub struct Revision(pub u32);

#[derive(Debug, Clone, PartialEq, Eq, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct SessionSnapshot {
    pub document_id: String,
    pub revision: Revision,
    pub root_id: NodeId,
    pub source: String,
}

/// The only writer of a document. P02 creates empty sessions; syntax/edit modules
/// extend this type rather than introducing a second state store.
pub struct EngineSession {
    document_id: String,
    revision: Revision,
    root_id: NodeId,
    next_node_id: u32,
}

impl EngineSession {
    pub fn new(document_id: String) -> EngineResult<Self> {
        if document_id.trim().is_empty() || document_id.len() > 256 || document_id.chars().any(char::is_control) {
            return Err(EngineError::new(ErrorCode::InvalidInput, "documentId must be a nonempty opaque identifier of at most 256 UTF-8 bytes"));
        }
        Ok(Self { document_id, revision: Revision(0), root_id: NodeId(1), next_node_id: 2 })
    }
    pub fn document_id(&self) -> &str { &self.document_id }
    pub fn revision(&self) -> Revision { self.revision }
    pub fn check_revision(&self, expected: Revision) -> EngineResult<()> {
        if self.revision != expected {
            return Err(EngineError::new(ErrorCode::StaleRevision, "Request revision does not match the document"));
        }
        Ok(())
    }
    pub fn allocate_node_id(&mut self) -> EngineResult<NodeId> {
        let next = self.next_node_id.checked_add(1)
            .ok_or_else(|| EngineError::new(ErrorCode::ResourceLimit, "Node identity space exhausted"))?;
        let id = NodeId(self.next_node_id);
        self.next_node_id = next;
        Ok(id)
    }
    pub fn snapshot(&self) -> SessionSnapshot {
        SessionSnapshot { document_id: self.document_id.clone(), revision: self.revision,
            root_id: self.root_id, source: String::new() }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn identities_are_monotonic_and_not_text_hashes() {
        let mut s = EngineSession::new("doc-a".into()).unwrap();
        assert_eq!(s.allocate_node_id().unwrap(), NodeId(2));
        assert_eq!(s.allocate_node_id().unwrap(), NodeId(3));
        assert_eq!(s.snapshot().root_id, NodeId(1));
    }
    #[test]
    fn validates_document_identity_without_normalizing_it() {
        for id in ["", "   ", "a\0b"] { assert!(EngineSession::new(id.into()).is_err()); }
        assert!(EngineSession::new("x".repeat(257)).is_err());
        assert_eq!(EngineSession::new("文档-A".into()).unwrap().document_id(), "文档-A");
    }
}
