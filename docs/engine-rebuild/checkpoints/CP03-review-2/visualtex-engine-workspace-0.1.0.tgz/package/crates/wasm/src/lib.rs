use wasm_bindgen::prelude::*;
use visualtex_engine_core::Runtime;

/// The JS object owns the runtime. Generated bindings copy request/response
/// strings; consumers must call free() when disposing the host. No raw pointers
/// or mutable document objects cross this boundary.
#[wasm_bindgen]
pub struct EngineRuntime {
    inner: Runtime,
}

#[wasm_bindgen]
impl EngineRuntime {
    #[wasm_bindgen(constructor)]
    pub fn new() -> Self { Self { inner: Runtime::default() } }

    pub fn dispatch(&mut self, request: &str) -> String {
        self.inner.dispatch_json(request)
    }

    #[wasm_bindgen(getter, js_name = activeSessions)]
    pub fn active_sessions(&self) -> u32 { self.inner.active_sessions() as u32 }
}

impl Default for EngineRuntime {
    fn default() -> Self { Self::new() }
}
