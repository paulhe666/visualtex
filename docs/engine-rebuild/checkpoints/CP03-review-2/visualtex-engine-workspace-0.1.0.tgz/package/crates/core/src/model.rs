use std::collections::BTreeSet;
use std::sync::Arc;
use serde::Serialize;
use crate::error::{EngineError, EngineResult, ErrorCode};
use crate::session::NodeId;
use crate::source::SourceSlice;

pub const MAX_NODES: usize = 8192;
pub const MAX_DEPTH: usize = 64;

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize)]
#[serde(rename_all = "camelCase")]
pub enum AtomClass { Ordinary, Number, Binary, Relation, Open, Close, Punctuation, Operator, Inner }

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize)]
#[serde(rename_all = "camelCase")]
pub enum Grouping { Bare, Braced }

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize)]
#[serde(rename_all = "camelCase")]
pub enum ScriptKind { Superscript, Subscript }

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct RowEntry {
    pub leading: String,
    pub node: Arc<Node>,
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct ScriptSlot {
    pub script: ScriptKind,
    pub before_marker: String,
    pub before_argument: String,
    pub argument: Arc<Node>,
}

#[derive(Debug, Clone, Serialize)]
#[serde(tag = "kind", rename_all = "camelCase", rename_all_fields = "camelCase")]
pub enum NodeKind {
    Row { grouping: Grouping, entries: Vec<RowEntry>, trailing: String },
    Symbol { value: String, class: AtomClass, command: Option<String> },
    Text { command: String, before_body: String, text: String },
    Fraction {
        command: String,
        before_numerator: String,
        numerator: Arc<Node>,
        before_denominator: String,
        denominator: Arc<Node>,
    },
    Scripts { base: Arc<Node>, slots: Vec<ScriptSlot> },
    EmptySlot { label: String },
    UnparsedSource { raw: String },
}

#[derive(Debug, Clone, Serialize)]
pub struct Node {
    pub id: NodeId,
    pub origin: Option<SourceSlice>,
    #[serde(flatten)]
    pub kind: NodeKind,
}

impl Node {
    pub fn empty_row(id: NodeId, grouping: Grouping) -> Arc<Self> {
        Arc::new(Self { id, origin: None,
            kind: NodeKind::Row { grouping, entries: Vec::new(), trailing: String::new() } })
    }

    pub fn children(&self) -> Vec<&Node> {
        match &self.kind {
            NodeKind::Row { entries, .. } => entries.iter().map(|entry| entry.node.as_ref()).collect(),
            NodeKind::Fraction { numerator, denominator, .. } => vec![numerator, denominator],
            NodeKind::Scripts { base, slots } => {
                let mut nodes = vec![base.as_ref()];
                nodes.extend(slots.iter().map(|slot| slot.argument.as_ref()));
                nodes
            }
            _ => Vec::new(),
        }
    }

    pub fn find(&self, id: NodeId) -> Option<&Node> {
        if self.id == id { return Some(self); }
        self.children().into_iter().find_map(|child| child.find(id))
    }

    pub fn visit(&self, f: &mut impl FnMut(&Node)) {
        f(self);
        for child in self.children() { child.visit(f); }
    }

    pub fn is_row(&self) -> bool { matches!(self.kind, NodeKind::Row { .. }) }

    pub fn is_empty_row(&self) -> bool {
        matches!(&self.kind, NodeKind::Row { entries, .. } if entries.is_empty())
    }

    pub fn has_unfilled_slots(&self) -> bool {
        match &self.kind {
            NodeKind::EmptySlot { .. } => true,
            NodeKind::Fraction { numerator, denominator, .. } => {
                numerator.is_empty_row() || denominator.is_empty_row()
                    || numerator.has_unfilled_slots() || denominator.has_unfilled_slots()
            }
            NodeKind::Scripts { base, slots } => base.has_unfilled_slots()
                || slots.iter().any(|slot| slot.argument.is_empty_row() || slot.argument.has_unfilled_slots()),
            _ => self.children().iter().any(|child| child.has_unfilled_slots()),
        }
    }
}

#[derive(Debug, Clone)]
pub struct IdAllocator { next: u32 }

impl IdAllocator {
    pub fn new(next: u32) -> Self { Self { next } }
    pub fn next_unused(&self) -> u32 { self.next }
    pub fn allocate(&mut self) -> EngineResult<NodeId> {
        if self.next == 0 {
            return Err(EngineError::new(ErrorCode::ResourceLimit, "Invalid node identity allocator"));
        }
        let next = self.next.checked_add(1)
            .ok_or_else(|| EngineError::new(ErrorCode::ResourceLimit, "Node identity space exhausted"))?;
        let id = NodeId(self.next);
        self.next = next;
        Ok(id)
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum LatexMode { Lossless, Canonical }

pub fn latex(node: &Node, mode: LatexMode) -> String {
    let mut output = String::new();
    emit(node, mode, false, &mut output);
    output
}

fn emit(node: &Node, mode: LatexMode, argument: bool, output: &mut String) {
    if mode == LatexMode::Lossless {
        if let Some(origin) = &node.origin {
            output.push_str(origin.text());
            return;
        }
    }
    match &node.kind {
        NodeKind::Row { grouping, entries, trailing } => {
            let braced = *grouping == Grouping::Braced || argument;
            if braced { output.push('{'); }
            let mut previous_ends_in_control_word = false;
            for entry in entries {
                if mode == LatexMode::Lossless && !entry.leading.is_empty() {
                    output.push_str(&entry.leading);
                    // Trivia belongs to the source, not the formula token.
                    previous_ends_in_control_word = false;
                }
                let mut boundary = output.len();
                emit(&entry.node, mode, false, output);
                // Inspect emitted bytes, not just the immediate node kind: a
                // scripted base or nested bare row may also start with a letter.
                // This is required after structural edits in lossless mode too;
                // otherwise preserving "\\alpha" then inserting x creates the
                // unrelated command "\\alphax". Untouched origins remain exact.
                if previous_ends_in_control_word
                    && output.as_bytes().get(boundary).is_some_and(u8::is_ascii_alphabetic)
                {
                    output.insert(boundary, ' ');
                    boundary += 1;
                }
                if output.len() > boundary {
                    // Only examine this fragment, avoiding quadratic rescans of
                    // long rows of ordinary letters when serializing each atom.
                    previous_ends_in_control_word = ends_control_word(&output[boundary..]);
                }
            }
            if mode == LatexMode::Lossless { output.push_str(trailing); }
            if braced { output.push('}'); }
        }
        NodeKind::Symbol { value, command, .. } => output.push_str(command.as_deref().unwrap_or(value)),
        NodeKind::Text { command, before_body, text } => {
            output.push_str(command);
            if mode == LatexMode::Lossless { output.push_str(before_body); }
            output.push('{');
            escape_text(text, output);
            output.push('}');
        }
        NodeKind::Fraction { command, before_numerator, numerator, before_denominator, denominator } => {
            output.push_str(command);
            if mode == LatexMode::Lossless { output.push_str(before_numerator); }
            emit(numerator, mode, true, output);
            if mode == LatexMode::Lossless { output.push_str(before_denominator); }
            emit(denominator, mode, true, output);
        }
        NodeKind::Scripts { base, slots } => {
            emit(base, mode, false, output);
            for slot in slots {
                if mode == LatexMode::Lossless { output.push_str(&slot.before_marker); }
                output.push(match slot.script { ScriptKind::Superscript => '^', ScriptKind::Subscript => '_' });
                if mode == LatexMode::Lossless { output.push_str(&slot.before_argument); }
                emit(&slot.argument, mode, true, output);
            }
        }
        NodeKind::EmptySlot { label } => {
            output.push_str("\\placeholder{");
            escape_text(label, output);
            output.push('}');
        }
        NodeKind::UnparsedSource { raw } => output.push_str(raw),
    }
}

fn ends_control_word(output: &str) -> bool {
    let bytes = output.as_bytes();
    let mut index = bytes.len();
    while index > 0 && bytes[index - 1].is_ascii_alphabetic() { index -= 1; }
    if index == bytes.len() { return false; }
    let word_start = index;
    while index > 0 && bytes[index - 1] == b'\\' { index -= 1; }
    // A doubled backslash is a control symbol, not the start of a control word.
    (word_start - index) % 2 == 1
}

fn escape_text(text: &str, output: &mut String) {
    for ch in text.chars() {
        match ch {
            '\\' => output.push_str("\\textbackslash{}"),
            '^' => output.push_str("\\textasciicircum{}"),
            '~' => output.push_str("\\textasciitilde{}"),
            '{' | '}' | '$' | '&' | '#' | '_' | '%' => { output.push('\\'); output.push(ch); }
            _ => output.push(ch),
        }
    }
}

#[derive(Debug, Default, Clone, PartialEq, Eq, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct TreeFacts {
    pub nodes: usize,
    pub rows: usize,
    pub fractions: usize,
    pub scripts: usize,
    pub text_runs: usize,
    pub empty_slots: usize,
    pub unparsed_sources: usize,
}

pub fn validate_tree(root: &Node) -> EngineResult<TreeFacts> {
    fn visit(node: &Node, depth: usize, seen: &mut BTreeSet<NodeId>, facts: &mut TreeFacts) -> EngineResult<()> {
        if depth > MAX_DEPTH || facts.nodes >= MAX_NODES {
            return Err(EngineError::new(ErrorCode::ResourceLimit, "Math tree depth or node budget exhausted"));
        }
        if node.id.0 == 0 || !seen.insert(node.id) {
            return Err(EngineError::new(ErrorCode::InvalidInput, "Math tree contains duplicate or zero node identities"));
        }
        facts.nodes += 1;
        match &node.kind {
            NodeKind::Row { .. } => facts.rows += 1,
            NodeKind::Fraction { numerator, denominator, .. } => {
                facts.fractions += 1;
                if !numerator.is_row() || !denominator.is_row() {
                    return Err(EngineError::new(ErrorCode::InvalidInput, "Fraction arguments must be editable rows"));
                }
            }
            NodeKind::Scripts { slots, .. } => {
                facts.scripts += 1;
                if slots.iter().any(|slot| !slot.argument.is_row()) {
                    return Err(EngineError::new(ErrorCode::InvalidInput, "Script arguments must be editable rows"));
                }
            }
            NodeKind::Text { .. } => facts.text_runs += 1,
            NodeKind::EmptySlot { .. } => facts.empty_slots += 1,
            NodeKind::UnparsedSource { .. } => facts.unparsed_sources += 1,
            _ => {}
        }
        for child in node.children() { visit(child, depth + 1, seen, facts)?; }
        Ok(())
    }
    let mut facts = TreeFacts::default();
    visit(root, 0, &mut BTreeSet::new(), &mut facts)?;
    Ok(facts)
}
