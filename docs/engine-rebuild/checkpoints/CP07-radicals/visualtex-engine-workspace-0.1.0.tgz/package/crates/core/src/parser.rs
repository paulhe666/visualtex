use std::sync::Arc;
use serde::Serialize;
use crate::error::{EngineError, EngineResult, ErrorCode};
use crate::model::{self, Grouping, IdAllocator, Node, NodeKind, RowEntry, ScriptKind, ScriptSlot, TreeFacts, MAX_DEPTH, MAX_NODES};
use crate::session::NodeId;
use crate::source::{SourceSpan, SourceText, Token, TokenKind, tokenize};
use crate::symbols::{literal_class, named_symbol};

const MAX_DIAGNOSTICS: usize = 128;

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize)]
#[serde(rename_all = "camelCase")]
pub enum Severity { Error, Unsupported }

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize)]
#[serde(rename_all = "camelCase")]
pub enum DiagnosticCode {
    MissingArgument, UnclosedGroup, UnexpectedClosingBrace, MissingBase,
    DuplicateScript, UnknownCommand, UnsupportedTextCommand, UnfinishedCommand,
    UnsupportedToken, UnbracedStructure, UnclosedOptionalArgument,
}

#[derive(Debug, Clone, Serialize)]
pub struct Diagnostic {
    pub code: DiagnosticCode,
    pub severity: Severity,
    pub span: SourceSpan,
    pub message: String,
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct ParseResult {
    #[serde(skip)]
    pub source: Arc<SourceText>,
    pub tree: Arc<Node>,
    pub tokens: Vec<Token>,
    pub diagnostics: Vec<Diagnostic>,
    pub facts: TreeFacts,
    pub complete: bool,
    pub supported: bool,
    pub exportable: bool,
}

/// Parse into an owned mathematical tree while keeping an exact lexical source
/// range for every unchanged node. No TeX expansion or third-party renderer runs.
pub fn parse(source: Arc<SourceText>, root_id: NodeId, ids: &mut IdAllocator) -> EngineResult<ParseResult> {
    let tokens = tokenize(&source)?;
    parse_tokens(source, tokens, root_id, ids)
}

pub(crate) fn parse_tokens(source: Arc<SourceText>, tokens: Vec<Token>, root_id: NodeId, ids: &mut IdAllocator) -> EngineResult<ParseResult> {
    let end_position = source.len();
    let mut parser = Parser { source: Arc::clone(&source), tokens, at: 0, ids, end_position,
        diagnostics: Vec::new(), nodes: 0 };
    let tree = parser.row(Grouping::Bare, Some(root_id), 0)?;
    assemble(source, tree, parser.tokens, parser.diagnostics)
}

pub(crate) fn assemble(source: Arc<SourceText>, tree: Arc<Node>, tokens: Vec<Token>, mut diagnostics: Vec<Diagnostic>) -> EngineResult<ParseResult> {
    if diagnostics.len() > MAX_DIAGNOSTICS {
        return Err(EngineError::new(ErrorCode::ResourceLimit, "Diagnostic budget exhausted"));
    }
    diagnostics.sort_by_key(|d| (d.span.byte_start, d.span.byte_end));
    let facts = model::validate_tree(&tree)?;
    let complete = !diagnostics.iter().any(|d| d.severity == Severity::Error);
    let supported = !diagnostics.iter().any(|d| d.severity == Severity::Unsupported);
    let exportable = complete && supported && tree.has_formula_content() && !tree.has_unfilled_slots();
    Ok(ParseResult { source, tree, tokens, diagnostics, facts, complete, supported, exportable })
}

/// Parse a proven, token-aligned closed group using global source coordinates.
/// None means the edit escaped that group; the caller must parse the formula.
pub(crate) fn parse_braced_fragment(source: Arc<SourceText>, all_tokens: &[Token], start: usize, end: usize) -> EngineResult<Option<ParseResult>> {
    let first = all_tokens.partition_point(|t| t.span.byte_end as usize <= start);
    let after = all_tokens.partition_point(|t| (t.span.byte_start as usize) < end);
    let tokens = all_tokens[first..after].to_vec();
    if !tokens.first().is_some_and(|t| t.kind == TokenKind::OpenBrace && t.span.byte_start as usize == start)
        || !tokens.last().is_some_and(|t| t.kind == TokenKind::CloseBrace && t.span.byte_end as usize == end)
    {
        return Ok(None);
    }
    let mut ids = IdAllocator::new(2);
    let mut parser = Parser { source: Arc::clone(&source), tokens, at: 0, ids: &mut ids,
        end_position: end, diagnostics: Vec::new(), nodes: 0 };
    let tree = parser.row(Grouping::Braced, Some(NodeId(1)), 0)?;
    if parser.at != parser.tokens.len() || parser.diagnostics.iter().any(|d| d.severity == Severity::Error) {
        return Ok(None);
    }
    Ok(Some(assemble(source, tree, parser.tokens, parser.diagnostics)?))
}

struct Parser<'a> {
    source: Arc<SourceText>,
    tokens: Vec<Token>,
    at: usize,
    ids: &'a mut IdAllocator,
    diagnostics: Vec<Diagnostic>,
    nodes: usize,
    end_position: usize,
}

impl Parser<'_> {
    fn position(&self) -> usize {
        self.tokens.get(self.at).map_or(self.end_position, |t| t.span.byte_start as usize)
    }

    fn kind(&self) -> Option<TokenKind> { self.tokens.get(self.at).map(|t| t.kind) }

    fn text(&self) -> &str {
        self.tokens.get(self.at).map_or("", |t| t.text(&self.source))
    }

    fn depth(&self, depth: usize) -> EngineResult<()> {
        if depth > MAX_DEPTH {
            Err(EngineError::new(ErrorCode::ResourceLimit, "Parser nesting budget exhausted"))
        } else { Ok(()) }
    }

    fn diagnostic(&mut self, code: DiagnosticCode, severity: Severity, start: usize, end: usize, message: &str) -> EngineResult<()> {
        if self.diagnostics.len() >= MAX_DIAGNOSTICS {
            return Err(EngineError::new(ErrorCode::ResourceLimit, "Diagnostic budget exhausted"));
        }
        self.diagnostics.push(Diagnostic { code, severity, span: self.source.span(start, end)?, message: message.into() });
        Ok(())
    }

    fn make(&mut self, kind: NodeKind, start: usize, end: usize, id: Option<NodeId>) -> EngineResult<Arc<Node>> {
        if self.nodes >= MAX_NODES {
            return Err(EngineError::new(ErrorCode::ResourceLimit, "Parser node budget exhausted"));
        }
        self.nodes += 1;
        Ok(Arc::new(Node { id: match id { Some(id) => id, None => self.ids.allocate()? },
            origin: Some(self.source.slice(start, end)?), kind }))
    }

    fn trivia(&mut self) -> String {
        let start = self.position();
        while self.tokens.get(self.at).is_some_and(Token::is_trivia) { self.at += 1; }
        self.source.text()[start..self.position()].to_owned()
    }

    fn row(&mut self, grouping: Grouping, id: Option<NodeId>, depth: usize) -> EngineResult<Arc<Node>> {
        self.depth(depth)?;
        let start = self.position();
        if grouping == Grouping::Braced { self.at += 1; }
        let mut entries = Vec::new();
        let trailing;
        loop {
            let leading = self.trivia();
            if self.kind().is_none() {
                trailing = leading;
                if grouping == Grouping::Braced {
                    self.diagnostic(DiagnosticCode::UnclosedGroup, Severity::Error, start, self.position(), "Group is missing its closing brace")?;
                }
                break;
            }
            if grouping == Grouping::Braced && self.kind() == Some(TokenKind::CloseBrace) {
                trailing = leading;
                self.at += 1;
                break;
            }
            let before = self.at;
            let atom = self.atom(depth + 1, true)?;
            let node = self.attach_scripts(atom, depth + 1)?;
            if self.at <= before {
                return Err(EngineError::new(ErrorCode::InvalidInput, "Parser failed to advance"));
            }
            entries.push(RowEntry { leading, node });
        }
        self.make(NodeKind::Row { grouping, entries, trailing }, start, self.position(), id)
    }

    fn atom(&mut self, depth: usize, allow_structure: bool) -> EngineResult<Arc<Node>> {
        self.depth(depth)?;
        let start = self.position();
        let Some(token) = self.tokens.get(self.at).cloned() else {
            self.diagnostic(DiagnosticCode::MissingArgument, Severity::Error, start, start, "Expected a math atom")?;
            return self.make(NodeKind::EmptySlot { label: String::new() }, start, start, None);
        };
        let raw = token.text(&self.source).to_owned();
        match token.kind {
            TokenKind::OpenBrace => self.row(Grouping::Braced, None, depth),
            TokenKind::CloseBrace => {
                self.at += 1;
                self.diagnostic(DiagnosticCode::UnexpectedClosingBrace, Severity::Error, start, self.position(), "Unexpected closing brace")?;
                self.make(NodeKind::UnparsedSource { raw }, start, self.position(), None)
            }
            TokenKind::Superscript | TokenKind::Subscript => {
                self.diagnostic(DiagnosticCode::MissingBase, Severity::Error, start, start, "Script has no base")?;
                self.make(NodeKind::EmptySlot { label: String::new() }, start, start, None)
            }
            TokenKind::ControlWord | TokenKind::ControlSymbol => {
                self.at += 1;
                if let Some((value, class)) = named_symbol(&raw) {
                    return self.make(NodeKind::Symbol { value: value.into(), class, command: Some(raw) }, start, self.position(), None);
                }
                let structural = matches!(raw.as_str(), "\\frac" | "\\dfrac" | "\\tfrac" | "\\sqrt" | "\\text" | "\\placeholder");
                if structural && !allow_structure {
                    self.diagnostic(DiagnosticCode::UnbracedStructure, Severity::Error, start, self.position(), "A structural command used as an argument requires braces")?;
                    return self.make(NodeKind::UnparsedSource { raw }, start, self.position(), None);
                }
                match raw.as_str() {
                    "\\frac" | "\\dfrac" | "\\tfrac" => {
                        let (before_numerator, numerator) = self.argument(depth + 1)?;
                        let (before_denominator, denominator) = self.argument(depth + 1)?;
                        self.make(NodeKind::Fraction { command: raw, before_numerator, numerator, before_denominator, denominator }, start, self.position(), None)
                    }
                    "\\sqrt" => {
                        let (before_degree, degree) = self.optional_degree(depth + 1)?;
                        let (before_radicand, radicand) = self.argument(depth + 1)?;
                        self.make(NodeKind::Radical { command: raw, before_degree, degree, before_radicand, radicand }, start, self.position(), None)
                    }
                    "\\text" | "\\placeholder" => {
                        let before_body = self.trivia();
                        let (body_start, body_end) = self.text_body()?;
                        let text = self.decode_text(body_start, body_end)?;
                        if raw == "\\placeholder" {
                            self.make(NodeKind::EmptySlot { label: text }, start, self.position(), None)
                        } else {
                            self.make(NodeKind::Text { command: raw, before_body, text }, start, self.position(), None)
                        }
                    }
                    "\\" => {
                        self.diagnostic(DiagnosticCode::UnfinishedCommand, Severity::Error, start, self.position(), "Command is not yet complete")?;
                        self.make(NodeKind::UnparsedSource { raw }, start, self.position(), None)
                    }
                    _ => {
                        self.capture_opaque_arguments()?;
                        self.diagnostic(DiagnosticCode::UnknownCommand, Severity::Unsupported, start, self.position(), "Command is not supported by the current engine capability")?;
                        let raw = self.source.text()[start..self.position()].to_owned();
                        self.make(NodeKind::UnparsedSource { raw }, start, self.position(), None)
                    }
                }
            }
            TokenKind::Character => {
                self.at += 1;
                if matches!(raw.as_str(), "$" | "&" | "#" | "~" | "'") || raw.chars().any(char::is_control) {
                    self.diagnostic(DiagnosticCode::UnsupportedToken, Severity::Unsupported, start, self.position(), "Token requires a language feature outside the current capability")?;
                    self.make(NodeKind::UnparsedSource { raw }, start, self.position(), None)
                } else {
                    self.make(NodeKind::Symbol { class: literal_class(&raw), value: raw, command: None }, start, self.position(), None)
                }
            }
            TokenKind::Space | TokenKind::Comment => {
                Err(EngineError::new(ErrorCode::InvalidInput, "Unexpected trivia at atom boundary"))
            }
        }
    }

    fn optional_degree(&mut self, depth: usize) -> EngineResult<(String, Option<Arc<Node>>)> {
        self.depth(depth)?;
        let saved = self.at;
        let before = self.trivia();
        if self.kind() != Some(TokenKind::Character) || self.text() != "[" {
            self.at = saved;
            return Ok((String::new(), None));
        }
        self.at += 1;
        let start = self.position();
        let first = self.at;
        let mut end_at = first;
        let mut braces = 0usize;
        let mut closed = false;
        // Delimited TeX arguments are scanned before their command bodies.
        // Do not allow a nested command to consume an unprotected outer ']'.
        while let Some(token) = self.tokens.get(end_at) {
            match token.kind {
                TokenKind::OpenBrace => braces += 1,
                TokenKind::CloseBrace if braces == 0 => break,
                TokenKind::CloseBrace => braces -= 1,
                TokenKind::Character if braces == 0 && token.text(&self.source) == "]" => { closed = true; break; }
                _ => {}
            }
            if braces > MAX_DEPTH { return Err(EngineError::new(ErrorCode::ResourceLimit, "Root index nesting budget exhausted")); }
            end_at += 1;
        }
        let end = self.tokens.get(end_at).map_or(self.end_position, |t| t.span.byte_start as usize);
        let mut nested = Parser { source: Arc::clone(&self.source), tokens: self.tokens[first..end_at].to_vec(),
            at: 0, ids: &mut *self.ids, end_position: end, diagnostics: Vec::new(), nodes: self.nodes };
        let row = nested.row(Grouping::Bare, None, depth + 1)?;
        self.nodes = nested.nodes;
        self.diagnostics.extend(nested.diagnostics);
        self.at = end_at + usize::from(closed);
        if !closed {
            self.diagnostic(DiagnosticCode::UnclosedOptionalArgument, Severity::Error, start, end, "Root index is missing its closing bracket")?;
        }
        // A protected index [{...}] uses that explicit group as its editable
        // row. Do not grow redundant nested rows on each save/reopen cycle.
        let row = match &row.kind {
            NodeKind::Row { entries, trailing, .. } if entries.len() == 1 && entries[0].leading.is_empty() && trailing.is_empty()
                && matches!(entries[0].node.kind, NodeKind::Row { grouping: Grouping::Braced, .. }) => Arc::clone(&entries[0].node),
            _ => row,
        };
        Ok((before, Some(row)))
    }

    fn argument(&mut self, depth: usize) -> EngineResult<(String, Arc<Node>)> {
        self.depth(depth)?;
        let before = self.trivia();
        let start = self.position();
        if self.kind() == Some(TokenKind::OpenBrace) {
            return Ok((before, self.row(Grouping::Braced, None, depth)?));
        }
        if matches!(self.kind(), None | Some(TokenKind::CloseBrace | TokenKind::Superscript | TokenKind::Subscript)) {
            self.diagnostic(DiagnosticCode::MissingArgument, Severity::Error, start, start, "Required argument is missing")?;
            let row = self.make(NodeKind::Row { grouping: Grouping::Bare, entries: Vec::new(), trailing: String::new() }, start, start, None)?;
            return Ok((before, row));
        }
        let node = self.atom(depth + 1, false)?;
        let row = self.make(NodeKind::Row { grouping: Grouping::Bare,
            entries: vec![RowEntry { leading: String::new(), node }], trailing: String::new() }, start, self.position(), None)?;
        Ok((before, row))
    }

    fn attach_scripts(&mut self, base: Arc<Node>, depth: usize) -> EngineResult<Arc<Node>> {
        let start = base.origin.as_ref().map_or(self.position(), |o| o.span.byte_start as usize);
        let mut slots: Vec<ScriptSlot> = Vec::new();
        loop {
            let saved = self.at;
            let before_marker = self.trivia();
            let script = match self.kind() {
                Some(TokenKind::Superscript) => ScriptKind::Superscript,
                Some(TokenKind::Subscript) => ScriptKind::Subscript,
                _ => { self.at = saved; break; }
            };
            let marker = self.position();
            self.at += 1;
            if slots.iter().any(|slot| slot.script == script) {
                self.diagnostic(DiagnosticCode::DuplicateScript, Severity::Error, marker, self.position(), "A base cannot have the same script twice")?;
            }
            let (before_argument, argument) = self.argument(depth + 1)?;
            slots.push(ScriptSlot { script, before_marker, before_argument, argument });
        }
        if slots.is_empty() { Ok(base) }
        else {
            // The base is an editable container too. A symbol's TeX spelling
            // remains unbraced; this row adds positions, not source characters.
            let base = if base.is_row() { base } else {
                let end = base.origin.as_ref().map_or(start, |o| o.span.byte_end as usize);
                self.make(NodeKind::Row { grouping: Grouping::Bare,
                    entries: vec![RowEntry { leading: String::new(), node: base }], trailing: String::new() }, start, end, None)?
            };
            self.make(NodeKind::Scripts { base, slots }, start, self.position(), None)
        }
    }

    fn text_body(&mut self) -> EngineResult<(usize, usize)> {
        let start = self.position();
        if self.kind() != Some(TokenKind::OpenBrace) {
            if matches!(self.kind(), None | Some(TokenKind::CloseBrace | TokenKind::Superscript | TokenKind::Subscript)) {
                self.diagnostic(DiagnosticCode::MissingArgument, Severity::Error, start, start, "Text argument is missing")?;
                return Ok((start, start));
            }
            self.at += 1;
            return Ok((start, self.position()));
        }
        self.at += 1;
        let body_start = self.position();
        let mut nesting = 1;
        while let Some(kind) = self.kind() {
            match kind {
                TokenKind::OpenBrace => {
                    nesting += 1;
                    if nesting > MAX_DEPTH { return Err(EngineError::new(ErrorCode::ResourceLimit, "Text group nesting budget exhausted")); }
                }
                TokenKind::CloseBrace => {
                    nesting -= 1;
                    if nesting == 0 {
                        let end = self.position();
                        self.at += 1;
                        return Ok((body_start, end));
                    }
                }
                _ => {}
            }
            self.at += 1;
        }
        self.diagnostic(DiagnosticCode::UnclosedGroup, Severity::Error, start, self.position(), "Text group is missing its closing brace")?;
        Ok((body_start, self.position()))
    }

    fn decode_text(&mut self, start: usize, end: usize) -> EngineResult<String> {
        let body = self.source.text()[start..end].to_owned();
        let mut text = String::new();
        let mut at = 0;
        while at < body.len() {
            let begin = at;
            let ch = body[at..].chars().next().unwrap();
            at += ch.len_utf8();
            match ch {
                '{' | '}' => {}
                '%' => {
                    while at < body.len() && body.as_bytes()[at] != b'\n' { at += 1; }
                    if at < body.len() { at += 1; }
                }
                '\\' => {
                    let control_start = at;
                    while at < body.len() && body.as_bytes()[at].is_ascii_alphabetic() { at += 1; }
                    if at > control_start {
                        let command = &body[control_start..at];
                        let known = match command {
                            "textbackslash" => Some('\\'), "textasciicircum" => Some('^'), "textasciitilde" => Some('~'), _ => None,
                        };
                        if let Some(ch) = known {
                            text.push(ch);
                            if body[at..].starts_with("{}") { at += 2; }
                        } else {
                            self.diagnostic(DiagnosticCode::UnsupportedTextCommand, Severity::Unsupported, start + begin, start + at, "Text command is not supported")?;
                            text.push_str(&body[begin..at]);
                        }
                    } else if at < body.len() {
                        let escaped = body[at..].chars().next().unwrap();
                        at += escaped.len_utf8();
                        if matches!(escaped, '{' | '}' | '$' | '&' | '#' | '_' | '%' | ' ') {
                            text.push(escaped);
                        } else {
                            self.diagnostic(DiagnosticCode::UnsupportedTextCommand, Severity::Unsupported, start + begin, start + at, "Text control symbol is not supported")?;
                            text.push_str(&body[begin..at]);
                        }
                    } else {
                        self.diagnostic(DiagnosticCode::UnfinishedCommand, Severity::Error, start + begin, start + at, "Text command is incomplete")?;
                        text.push('\\');
                    }
                }
                '$' | '&' | '#' | '_' | '^' | '~' => {
                    self.diagnostic(DiagnosticCode::UnsupportedToken, Severity::Unsupported, start + begin, start + at, "Text token requires an explicit escape or unsupported feature")?;
                    text.push(ch);
                }
                _ => text.push(ch),
            }
        }
        Ok(text)
    }

    fn capture_opaque_arguments(&mut self) -> EngineResult<()> {
        if self.text() == "*" { self.at += 1; }
        loop {
            let saved = self.at;
            self.trivia();
            if self.kind() == Some(TokenKind::OpenBrace) {
                self.text_body()?;
            } else if self.text() == "[" {
                let start = self.position();
                self.at += 1;
                let mut brackets = 1;
                let mut braces = 0;
                while self.kind().is_some() && brackets > 0 {
                    match self.kind() {
                        Some(TokenKind::OpenBrace) => braces += 1,
                        Some(TokenKind::CloseBrace) if braces > 0 => braces -= 1,
                        _ if braces == 0 && self.text() == "[" => brackets += 1,
                        _ if braces == 0 && self.text() == "]" => brackets -= 1,
                        _ => {}
                    }
                    if braces + brackets > MAX_DEPTH {
                        return Err(EngineError::new(ErrorCode::ResourceLimit, "Opaque argument nesting budget exhausted"));
                    }
                    self.at += 1;
                }
                if brackets != 0 {
                    self.diagnostic(DiagnosticCode::UnclosedGroup, Severity::Error, start, self.position(), "Opaque optional argument is incomplete")?;
                }
            } else {
                self.at = saved;
                break;
            }
        }
        Ok(())
    }
}
