//! Font-driven vertical glyph construction, shared by radicals and later fences.
//! OpenType MATH variants/assemblies provide data, not a rendering engine.
//! Pieces retain their real outlines and uniform em scale; no anisotropic stretch.
use std::sync::Arc;
use ttf_parser::{GlyphId, math::GlyphPart};
use crate::error::{EngineError, EngineResult, ErrorCode};
use crate::fonts::{FontAsset, GlyphShape};

const MAX_VARIANTS: usize = 256;
const MAX_PARTS: usize = 1024;
const EPS: f64 = 1e-9;

#[derive(Debug, Clone)]
pub struct StretchPiece {
    pub shape: Arc<GlyphShape>,
    /// Baseline relative to the assembly's ink top, in em, y down.
    pub y: f64,
}
#[derive(Debug, Clone)]
pub struct StretchedGlyph {
    pub pieces: Vec<StretchPiece>,
    pub width: f64,
    pub height: f64,
    pub italic_correction: f64,
    pub assembled: bool,
    pub overlaps: Vec<f64>,
    pub minimum_overlap: f64,
}
fn invalid(message: &str) -> EngineError { EngineError::new(ErrorCode::InvalidInput, message) }
fn limit(message: &str) -> EngineError { EngineError::new(ErrorCode::ResourceLimit, message) }

/// Select the smallest usable designed variant, then assemble real glyph parts.
/// Missing data fails explicitly; it never substitutes a renderer or scales y.
pub fn vertical(font: &FontAsset, glyph_id: u16, target: f64) -> EngineResult<StretchedGlyph> {
    if !target.is_finite() || target <= 0.0 { return Err(invalid("Invalid vertical stretch target")); }
    if target > 2048.0 { return Err(limit("Vertical stretch target exceeds its budget")); }
    let face = font.face()?;
    let em = f64::from(face.units_per_em());
    let variants = face.tables().math.and_then(|table| table.variants);
    let construction = variants.and_then(|v| v.vertical_constructions.get(GlyphId(glyph_id)));
    let original = font.glyph(glyph_id)?;
    let height = |shape: &GlyphShape| shape.ink.map_or(0.0, |b| b[3] - b[1]);
    let mut candidates = vec![original];
    if let Some(construction) = &construction {
        if usize::from(construction.variants.len()) > MAX_VARIANTS { return Err(limit("Too many MATH glyph variants")); }
        for variant in construction.variants {
            // Validate the declared size as well as the actual glyph geometry.
            if variant.advance_measurement == 0 { return Err(invalid("MATH variant has zero extent")); }
            candidates.push(font.glyph(variant.variant_glyph.0)?);
        }
    }
    if let Some(shape) = candidates.into_iter().filter(|shape| height(shape) + EPS >= target)
        .min_by(|a, b| height(a).total_cmp(&height(b)).then(a.glyph_id.cmp(&b.glyph_id)))
    {
        let ink = shape.ink.ok_or_else(|| invalid("Stretch variant has no ink"))?;
        return Ok(StretchedGlyph { width: shape.advance, height: ink[3] - ink[1],
            italic_correction: shape.italic_correction, pieces: vec![StretchPiece { y: -ink[1], shape }],
            assembled: false, overlaps: Vec::new(), minimum_overlap: 0.0 });
    }
    let assembly = construction.and_then(|c| c.assembly)
        .ok_or_else(|| invalid("Font has no sufficiently large glyph or vertical assembly"))?;
    let min_overlap = f64::from(variants.unwrap().min_connector_overlap) / em;
    let parts: Vec<GlyphPart> = assembly.parts.into_iter().collect();
    if parts.is_empty() || parts.len() > MAX_PARTS { return Err(limit("MATH assembly part budget exceeded")); }
    let mut fixed_count = 0usize;
    let mut ext_count = 0usize;
    let mut fixed_size = 0.0;
    let mut ext_size = 0.0;
    for part in &parts {
        if part.full_advance == 0 || part.start_connector_length > part.full_advance
            || part.end_connector_length > part.full_advance {
            return Err(invalid("Invalid MATH assembly connectors or part advance"));
        }
        if part.part_flags.extender() { ext_count += 1; ext_size += f64::from(part.full_advance) / em; }
        else { fixed_count += 1; fixed_size += f64::from(part.full_advance) / em; }
    }
    let growth = ext_size - min_overlap * ext_count as f64;
    if ext_count == 0 || growth <= 0.0 { return Err(invalid("MATH assembly cannot grow")); }
    let repetitions = ((target - fixed_size + min_overlap * (fixed_count as f64 - 1.0)) / growth).ceil().max(0.0);
    if repetitions > MAX_PARTS as f64 { return Err(limit("MATH assembly repetition budget exceeded")); }
    let repetitions = repetitions as usize;
    let count = fixed_count.checked_add(ext_count.checked_mul(repetitions).ok_or_else(|| limit("Assembly size overflow"))?)
        .ok_or_else(|| limit("Assembly size overflow"))?;
    if count == 0 || count > MAX_PARTS { return Err(limit("MATH assembly glyph budget exceeded")); }
    let expanded: Vec<&GlyphPart> = parts.iter().flat_map(|part| {
        std::iter::repeat_n(part, if part.part_flags.extender() { repetitions } else { 1 })
    }).collect();
    let max_overlap = expanded.windows(2).map(|pair| {
        f64::from(pair[0].end_connector_length.min(pair[1].start_connector_length)) / em
    }).fold(f64::INFINITY, f64::min);
    if count > 1 && max_overlap + EPS < min_overlap { return Err(invalid("MATH assembly cannot satisfy minimum connector overlap")); }
    let full_size: f64 = expanded.iter().map(|part| f64::from(part.full_advance) / em).sum();
    let overlap = if count > 1 { ((full_size - target) / (count - 1) as f64).clamp(min_overlap, max_overlap) } else { 0.0 };
    let mut pieces = Vec::with_capacity(count);
    let mut baseline = 0.0;
    let mut top = f64::INFINITY;
    let mut bottom = f64::NEG_INFINITY;
    let mut width = 0.0f64;
    // MATH lists vertical parts from bottom to top. Their origins, rather than
    // individually normalized bounding boxes, define connector alignment.
    for (i, part) in expanded.iter().enumerate() {
        let shape = font.glyph(part.glyph_id.0)?;
        let ink = shape.ink.ok_or_else(|| invalid("MATH assembly part has no outline"))?;
        top = top.min(baseline + ink[1]); bottom = bottom.max(baseline + ink[3]);
        width = width.max(shape.advance);
        pieces.push(StretchPiece { shape, y: baseline });
        if i + 1 < count { baseline -= f64::from(part.full_advance) / em - overlap; }
    }
    let height = bottom - top;
    if !height.is_finite() || height + EPS < target || width <= 0.0 {
        return Err(invalid("MATH assembly ink does not reach its requested extent"));
    }
    for piece in &mut pieces { piece.y -= top; }
    Ok(StretchedGlyph { pieces, width, height,
        italic_correction: f64::from(assembly.italics_correction.value) / em,
        assembled: true, overlaps: vec![overlap; count - 1], minimum_overlap: min_overlap })
}
