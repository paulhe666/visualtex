// Internal syntax-analysis schema, independent of Office metadata and Session DTOs.
// IDs returned by analyzeSource are local to that analysis, never edit handles.
export interface SourceSpan {
  sourceId: number;
  byteStart: number;
  byteEnd: number;
  utf16Start: number;
  utf16End: number;
}
export type AtomClass = 'ordinary' | 'number' | 'binary' | 'relation' | 'open' | 'close' | 'punctuation' | 'operator' | 'inner';
export type ScriptKind = 'superscript' | 'subscript';
export interface RowEntry { leading: string; node: MathNode }
export interface ScriptSlot { script: ScriptKind; beforeMarker: string; beforeArgument: string; argument: MathNode }
export type MathNode = { id: number; origin: SourceSpan | null } & (
  | { kind: 'row'; grouping: 'bare' | 'braced'; entries: RowEntry[]; trailing: string }
  | { kind: 'symbol'; value: string; class: AtomClass; command: string | null }
  | { kind: 'text'; command: string; beforeBody: string; text: string }
  | { kind: 'fraction'; command: string; beforeNumerator: string; numerator: MathNode; beforeDenominator: string; denominator: MathNode }
  | { kind: 'radical'; command: string; beforeDegree: string; degree: MathNode | null; beforeRadicand: string; radicand: MathNode }
  | { kind: 'scripts'; base: MathNode; slots: ScriptSlot[] }
  | { kind: 'emptySlot'; label: string }
  | { kind: 'unparsedSource'; raw: string }
);
export interface SyntaxDiagnostic {
  code: 'missingArgument' | 'unclosedGroup' | 'unexpectedClosingBrace' | 'missingBase' | 'duplicateScript'
    | 'unknownCommand' | 'unsupportedTextCommand' | 'unfinishedCommand' | 'unsupportedToken' | 'unbracedStructure' | 'unclosedOptionalArgument';
  severity: 'error' | 'unsupported';
  span: SourceSpan;
  message: string;
}
export interface SyntaxToken {
  kind: 'controlWord' | 'controlSymbol' | 'character' | 'openBrace' | 'closeBrace'
    | 'superscript' | 'subscript' | 'space' | 'comment';
  span: SourceSpan;
}
export interface SyntaxFacts {
  nodes: number; rows: number; fractions: number; radicals: number; scripts: number;
  textRuns: number; emptySlots: number; unparsedSources: number;
}
export interface SourceAnalysis {
  tree: MathNode;
  tokens: SyntaxToken[];
  diagnostics: SyntaxDiagnostic[];
  facts: SyntaxFacts;
  complete: boolean;
  supported: boolean;
  exportable: boolean;
}
