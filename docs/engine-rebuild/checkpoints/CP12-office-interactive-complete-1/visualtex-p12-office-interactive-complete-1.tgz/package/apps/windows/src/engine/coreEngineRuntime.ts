import { invoke, isTauri } from "@tauri-apps/api/core";
import init, { EngineRuntime } from "../../../../engine/web/pkg/visualtex_engine_wasm.js";
import wasmUrl from "../../../../engine/web/pkg/visualtex_engine_wasm_bg.wasm?url";
import mathFontUrl from "../../src-windows/artifacts/office-fonts/latinmodern-math.otf?url";
import { EngineEditorSessionOwner } from "../../../../engine/web/host/editor-session.ts";
import type { FontIdentity, LayoutOptions } from "../../../../engine/web/host/layout.ts";
import type { WorkspaceMode } from "../workspace/workspaceTypes";
import {
  formulaChineseFontFamily,
  formulaLetterFontFamilies,
  type FormulaChineseFont,
  type FormulaLetterFont,
} from "../editor/formulaFontPreferences";
import { systemFontFamilyList } from "../math/systemMathGlyphLibrary";

const EXPECTED_MATH_FONT_SHA256 =
  "6075562b771f8b82f0c179e363389684f2dd09de30038269e2628e504bd7be0f";

export interface CoreEngineRuntimeContext {
  runtime: EngineRuntime;
  mathFont: FontIdentity;
  baseLayout: LayoutOptions;
}

export interface LockedCoreFormulaSession {
  owner: EngineEditorSessionOwner;
  layout: LayoutOptions;
}

let runtimePromise: Promise<CoreEngineRuntimeContext> | null = null;
let pageHideInstalled = false;
const systemFontPromises = new Map<string, Promise<FontIdentity | null>>();

interface NativeSystemFontAsset {
  requestedFamily: string;
  resolvedFamily: string;
  faceIndex: number;
  sha256: string;
  byteLength: number;
  bytesBase64: string;
  hasMathTable: boolean;
}

function bytesToHex(bytes: ArrayBuffer) {
  return Array.from(new Uint8Array(bytes), (value) =>
    value.toString(16).padStart(2, "0"),
  ).join("");
}

async function readVerifiedAsset(url: string, expectedSha256: string) {
  const response = await fetch(url, { cache: "force-cache" });
  if (!response.ok) {
    throw new Error(`VisualTeX core resource failed to load (${response.status}).`);
  }
  const bytes = await response.arrayBuffer();
  const actual = bytesToHex(await crypto.subtle.digest("SHA-256", bytes));
  if (actual !== expectedSha256) {
    throw new Error("VisualTeX core font resource hash mismatch.");
  }
  return new Uint8Array(bytes);
}

function registerFont(
  runtime: EngineRuntime,
  bytes: Uint8Array,
  faceIndex: number,
  expectedSha256: string,
) {
  const response = JSON.parse(runtime.registerFont(bytes, faceIndex)) as {
    status: "ok" | "error";
    result?: { kind: string; font: FontIdentity };
    error?: { code: string; message: string };
  };
  if (response.status !== "ok" || response.result?.kind !== "fontRegistered") {
    throw new Error(
      response.error
        ? `${response.error.code}: ${response.error.message}`
        : "VisualTeX core rejected its verified font resource.",
    );
  }
  if (
    response.result.font.sha256 !== expectedSha256 ||
    response.result.font.faceIndex !== faceIndex
  ) {
    throw new Error("VisualTeX core registered an unexpected font identity.");
  }
  return response.result.font;
}

async function createRuntime(): Promise<CoreEngineRuntimeContext> {
  await init({ module_or_path: wasmUrl });
  const runtime = new EngineRuntime();
  try {
    const bytes = await readVerifiedAsset(mathFontUrl, EXPECTED_MATH_FONT_SHA256);
    const mathFont = registerFont(runtime, bytes, 0, EXPECTED_MATH_FONT_SHA256);
    const baseLayout: LayoutOptions = {
      mathFont: mathFont.id,
      // Text is resolved from the user's actual verified Windows font preference
      // when running inside Tauri. A plain browser candidate keeps this null.
      textFont: null,
      mathFallbacks: [],
      customSymbolTextFonts: [],
      style: "display",
      fontSizePx: 28,
      paddingEm: 0.125,
    };
    if (!pageHideInstalled && typeof window !== "undefined") {
      pageHideInstalled = true;
      window.addEventListener(
        "pagehide",
        () => {
          try {
            runtime.free();
          } catch {
            // The page is already being destroyed.
          }
          runtimePromise = null;
          systemFontPromises.clear();
        },
        { once: true },
      );
    }
    return { runtime, mathFont, baseLayout };
  } catch (error) {
    runtime.free();
    throw error;
  }
}

export function coreEditorExperimentEnabled(mode: WorkspaceMode) {
  return (
    mode === "desktop" &&
    import.meta.env.VITE_VISUALTEX_CORE_EDITOR === "1"
  );
}

function decodeSystemFontAsset(value: unknown): NativeSystemFontAsset {
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    throw new Error("VisualTeX returned an invalid system font asset.");
  }
  const asset = value as Partial<NativeSystemFontAsset>;
  if (
    typeof asset.requestedFamily !== "string" || !asset.requestedFamily || asset.requestedFamily.length > 128 ||
    typeof asset.resolvedFamily !== "string" || !asset.resolvedFamily || asset.resolvedFamily.length > 128 ||
    !Number.isSafeInteger(asset.faceIndex) || Number(asset.faceIndex) < 0 || Number(asset.faceIndex) > 65535 ||
    typeof asset.sha256 !== "string" || !/^[0-9a-f]{64}$/u.test(asset.sha256) ||
    !Number.isSafeInteger(asset.byteLength) || Number(asset.byteLength) <= 0 || Number(asset.byteLength) > 128 * 1024 * 1024 ||
    typeof asset.bytesBase64 !== "string" || asset.bytesBase64.length > 180 * 1024 * 1024 ||
    typeof asset.hasMathTable !== "boolean"
  ) {
    throw new Error("VisualTeX returned malformed system font metadata.");
  }
  return asset as NativeSystemFontAsset;
}

function decodeBase64Bytes(value: string) {
  const binary = atob(value);
  const bytes = new Uint8Array(binary.length);
  for (let index = 0; index < binary.length; index += 1) bytes[index] = binary.charCodeAt(index);
  return bytes;
}

async function resolveSystemFont(
  context: CoreEngineRuntimeContext,
  families: readonly string[],
  requireMathTable = false,
): Promise<FontIdentity | null> {
  const normalized = Array.from(new Set(families.map((family) => family.trim()).filter(Boolean))).slice(0, 16);
  if (!normalized.length || !isTauri()) return null;
  const key = `${requireMathTable ? "math" : "text"}:${normalized
    .map((family) => family.toLocaleLowerCase())
    .join("\u001f")}`;
  const existing = systemFontPromises.get(key);
  if (existing) return existing;
  const pending = (async () => {
    const candidates = requireMathTable ? normalized.map((family) => [family]) : [normalized];
    let lastError: unknown = null;
    for (const candidate of candidates) {
      try {
        const asset = decodeSystemFontAsset(
          await invoke<unknown>("read_system_font_asset", { fontFamilies: candidate }),
        );
        if (requireMathTable && !asset.hasMathTable) continue;
        const bytes = decodeBase64Bytes(asset.bytesBase64);
        if (bytes.byteLength !== asset.byteLength) {
          throw new Error("VisualTeX system font byte length mismatch.");
        }
        const sha256 = bytesToHex(await crypto.subtle.digest("SHA-256", bytes));
        if (sha256 !== asset.sha256) {
          throw new Error("VisualTeX system font hash mismatch.");
        }
        return registerFont(context.runtime, bytes, asset.faceIndex, asset.sha256);
      } catch (error) {
        lastError = error;
      }
    }
    if (lastError) throw lastError;
    return null;
  })().catch((error) => {
    systemFontPromises.delete(key);
    console.warn("VisualTeX core could not resolve a verified system font:", error);
    return null;
  });
  systemFontPromises.set(key, pending);
  return pending;
}

function mathFontFamiliesForPreference(letterFont: FormulaLetterFont) {
  switch (letterFont) {
    case "cambria":
      return ["Cambria Math"];
    case "stix":
      return ["STIX Two Math", "XITS Math", "Cambria Math"];
    case "times":
      return ["XITS Math", "STIX Two Math", "Cambria Math"];
    case "palatino":
      return ["TeX Gyre Pagella Math", "Asana Math", "Cambria Math"];
    case "helvetica":
      return ["Fira Math", "Cambria Math"];
    case "katex":
      return [];
  }
}

export async function resolveCoreLayoutForPreferences(
  context: CoreEngineRuntimeContext,
  letterFont: FormulaLetterFont,
  chineseFont: FormulaChineseFont,
  style: "display" | "text",
): Promise<LayoutOptions | null> {
  const mathFont = letterFont === "katex"
    ? context.mathFont
    : (await resolveSystemFont(
        context,
        mathFontFamiliesForPreference(letterFont),
        true,
      )) ?? context.mathFont;
  const textFont = await resolveSystemFont(
    context,
    systemFontFamilyList(formulaChineseFontFamily(chineseFont)),
    false,
  );
  return {
    ...context.baseLayout,
    mathFont: mathFont.id,
    textFont: textFont?.id ?? null,
    mathFallbacks: mathFont.id === context.mathFont.id ? [] : [context.mathFont.id],
    style,
  };
}

export function getCoreEngineRuntime() {
  runtimePromise ??= createRuntime().catch((error) => {
    runtimePromise = null;
    throw error;
  });
  return runtimePromise;
}

/**
 * The engine choice is made once for the complete formula owner. A failed
 * create/layout attempt is destroyed and the caller must keep that formula on
 * the legacy editor for the lifetime of the mounted session. There is no
 * subtree or mid-edit fallback.
 */
export async function tryCreateLockedCoreFormulaSession(
  documentId: string,
  source: string,
  style: "display" | "text",
  symbols: readonly unknown[] = [],
  layoutOverride?: LayoutOptions | null,
): Promise<LockedCoreFormulaSession | null> {
  const context = await getCoreEngineRuntime();
  const owner = new EngineEditorSessionOwner(
    context.runtime,
    documentId,
    source,
    symbols,
  );
  const layout: LayoutOptions = layoutOverride ?? {
    ...context.baseLayout,
    style,
  };
  try {
    if (!source.trim()) return { owner, layout };
    owner.layout(layout, false);
    return { owner, layout };
  } catch {
    owner.destroy();
    return null;
  }
}
