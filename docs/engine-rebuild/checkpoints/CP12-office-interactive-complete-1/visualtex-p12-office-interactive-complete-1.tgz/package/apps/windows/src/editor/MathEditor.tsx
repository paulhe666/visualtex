import {
  useEffect,
  useLayoutEffect,
  useImperativeHandle,
  useMemo,
  useRef,
  useState,
  forwardRef,
  type CSSProperties,
  type ReactNode,
} from "react";
import {
  MathfieldElement,
  type Style,
} from "mathlive";
import { flushSync } from "react-dom";
import { ClipboardCopy } from "lucide-react";
import type {
  CommandSource,
  CommandUsage,
  LatexCommand,
} from "../types/command";
import type {
  FormulaAlignment,
  FormulaLine,
  InputBehaviorSettingKey,
  LatexCodeFormat,
  InputBehaviorSettings,
} from "../types/formula";
import type { CoreEditorExportPort } from "../engine/coreEditorExportPort";
import type {
  AddLineEntry,
  EditKind,
  CoreMathSelectionSnapshot,
  FormulaEditSource,
  MathSelectionSnapshot,
  RemoveLineEntry,
  ReplaceDocumentEntry,
  ReplaceFormulaEntry,
} from "../history/historyTypes";
import {
  clampSelection,
  historyManager,
} from "../history/HistoryManager";
import { getEditorDocumentSnapshot } from "../history/documentHistory";
import { searchCommands } from "../autocomplete/CommandSearchEngine";
import {
  findRuntimeCommandByCommand,
  getRuntimeCommandRegistry,
} from "../autocomplete/runtimeCommandRegistry";
import { CommandSuggestionPopup } from "../autocomplete/CommandSuggestionPopup";
import {
  compatibilityRawPlaceholderTemplates,
  compatibilityWrapperCanonicalTargets,
  compatibilityWrapperPreviews,
} from "../autocomplete/compatibilityCommands";
import {
  createFormulaLine,
  useEditorStore,
} from "../stores/editorStore";
import { useFormulaHotkeyStore } from "../stores/formulaHotkeyStore";
import {
  matchFormulaHotkey,
  resolveFormulaHotkeyCommand,
} from "../shortcuts/formulaHotkeys";
import {
  greekLetterHotkeyCommandFromEvent,
  isGreekLetterHotkeyPrefix,
} from "../shortcuts/greekLetterHotkeys";
import { resolveNewFormulaLineMode } from "./formulaLineMode";
import {
  normalizeChineseLatex,
  normalizeContextualUprightSymbols,
  normalizeMathLiveCanonicalUprightCommands,
  resolveVisualTexInlineShortcuts,
  type VisualTexInlineShortcutDefinitions,
} from "./normalizeChineseLatex";
import {
  convertVisualTexLatexToMarkup,
  installMathLiveContourIntegralShadowStyle,
} from "./mathLiveIntegralCompatibility";
import { composeCustomSymbolMacrosForMathfield } from "../math/customSymbolRegistry";
import { isSingleCompleteLatexEnvironment } from "../math/latexEnvironment";
import {
  installCustomSymbolGlobalStyle,
  installCustomSymbolShadowStyle,
  refreshCustomSymbolMathfield,
} from "../math/customSymbolRendering";
import { useCustomSymbolRevision } from "../math/customSymbolReact";
import { ImeCompositionGuard } from "./imeCompositionGuard";
import { installMathLiveOptionMutationGuard } from "./mathLiveOptionCompatibility";
import { VISUALTEX_MATHLIVE_COMPATIBILITY_MACROS } from "../math/mathLiveCompatibilityMacros";
import { VISUALTEX_PACKAGE_MACRO_NAMES } from "../math/packageMacroCompatibility";
import { hasBoundedOperatorPlaceholderOrder } from "./boundedOperatorTemplate";
import {
  nativeSuggestionPreviewHasVisibleInk,
  resolveNativeSuggestionPreview,
} from "./nativeSuggestionPreviews";
import {
  toggleFormulaSelectionLatex,
  type FormulaSelectionToggleKind,
} from "./selectionStyleToggle";
import { isSafeFormulaStyleColor } from "../workspace/formulaColor";
import { copyFormulaDocumentPngToClipboard } from "../export/pngClipboard";
import {
  formulaChineseFontFamily,
  formulaLetterFontFamilies,
  type FormulaChineseFont,
  type FormulaLetterFont,
} from "./formulaFontPreferences";
import {
  hasVisualTexAlignmentMarker,
  usesExplicitAlignmentPoints,
  VISUALTEX_ALIGNMENT_MARKER_CLASS,
  VISUALTEX_ALIGNMENT_MARKER_LATEX,
} from "./alignmentMarkers";

export interface MathEditorInsertionTarget {
  lineId: string;
  ranges: Array<[number, number]>;
  direction: "forward" | "backward" | "none";
  /** Transitional P10 discriminator. Legacy targets omit it; core targets keep
   * an opaque one-shot request object that is never serialized as MathLive offsets. */
  engine?: "legacy" | "core";
  coreRequest?: object;
}

export interface MathEditorSelectionTarget {
  selections: MathEditorInsertionTarget[];
  engine?: "legacy" | "core";
  coreLineId?: string;
}

export type MathEditorSelectionStyle =
  | { kind: "bold" }
  | { kind: "italic" }
  | { kind: "color"; value: string }
  | { kind: "backgroundColor"; value: string };

export interface MathEditorFocusOptions {
  target?: "active" | "first" | "last";
  moveToEnd?: boolean;
}

const EDITOR_LAYOUT_REFRESH_EVENT = "visualtex-editor-layout-refresh";
const VISUALTEX_MULTILINE_LATEX_CLIPBOARD_TYPE =
  "application/x-visualtex-multiline-latex";

export interface MathEditorHistoryState {
  engine: "core";
  canUndo: boolean;
  canRedo: boolean;
}

export interface MathEditorHandle {
  insertCommand: (command: LatexCommand, source?: "toolbar" | "history" | "shortcut") => void;
  insertLatex: (latex: string, source?: FormulaEditSource) => void;
  insertLatexAt: (
    target: MathEditorInsertionTarget,
    latex: string,
    source?: FormulaEditSource,
  ) => boolean;
  appendLatex: (latex: string, source?: FormulaEditSource) => void;
  focus: (options?: MathEditorFocusOptions) => void;
  addLine: () => void;
  commitPendingTransaction: () => void;
  getSelectionMap: () => Record<string, MathSelectionSnapshot>;
  getCoreSelectionMap?: () => Record<string, CoreMathSelectionSnapshot>;
  restoreSelection: (
    lineId: string,
    latex: string,
    selection: MathSelectionSnapshot | null,
  ) => Promise<boolean>;
  restoreCoreSelection?: (
    lineId: string,
    latex: string,
    selection: CoreMathSelectionSnapshot | null,
  ) => Promise<boolean>;
  captureSelectionTarget: () => MathEditorSelectionTarget | null;
  captureInsertionTarget: () => MathEditorInsertionTarget | null;
  applySelectionStyle: (
    style: MathEditorSelectionStyle,
    target?: MathEditorSelectionTarget | null,
  ) => boolean;
  refreshLayout: () => void;
  /** P10/P12 core editor bridge. Legacy MathLive does not implement this path. */
  replaceLineSource?: (lineId: string, latex: string) => boolean;
  getCoreExportPort?: () => CoreEditorExportPort | null;
  history?: (redo: boolean) => boolean;
}

interface Props {
  lines: FormulaLine[];
  activeLineId: string | null;
  formulaAlignment: FormulaAlignment;
  latexCodeFormat: LatexCodeFormat;
  zoom: number;
  reuseLineSlots?: boolean;
  readOnly?: boolean;
  previewOnly?: boolean;
  onPreviewActivate?: () => void;
  draftError?: string;
  onPasteImage?: (file: File, target: MathEditorInsertionTarget) => void;
  onCopyPng?: () => Promise<void>;
  onHistoryBusyChange?: (busy: boolean) => void;
  overlay?: ReactNode;
}

interface FormulaFieldEdit {
  lineId: string;
  beforeLatex: string;
  afterLatex: string;
  beforeSelection: MathSelectionSnapshot;
  afterSelection: MathSelectionSnapshot;
  editKind: EditKind;
  source: FormulaEditSource;
}

interface FormulaFieldProps {
  lineId: string;
  index: number;
  latex: string;
  zoom: number;
  formulaRowVerticalInset: number;
  language: "cn" | "en";
  formulaLetterFont: FormulaLetterFont;
  formulaChineseFont: FormulaChineseFont;
  autoPairDelimiters: boolean;
  inputBehavior: InputBehaviorSettings;
  readOnly: boolean;
  freshExternalSync: boolean;
  register: (
    lineId: string,
    field: MathfieldElement | null,
    expectedField?: MathfieldElement,
  ) => void;
  onEdit: (edit: FormulaFieldEdit, field: MathfieldElement) => void;
  onInputActivity: (field: MathfieldElement) => void;
  onSelectionChange: (
    lineId: string,
    selection: MathSelectionSnapshot,
  ) => void;
  onFocus: (index: number, field: MathfieldElement) => void;
  onCommitPending: () => void;
  onKeyDown: (index: number, event: KeyboardEvent, field: MathfieldElement) => void;
  onPasteImage?: (file: File, target: MathEditorInsertionTarget) => void;
  onCopyPng?: () => Promise<void>;
  onContextMenu?: (clientX: number, clientY: number) => void;
  onPasteLatexLines?: (
    lineId: string,
    field: MathfieldElement,
    lines: string[],
  ) => void;
}

interface MultiLineSelectionPoint {
  lineId: string;
  lineIndex: number;
  offset: number;
}

interface MultiLineSelectionState {
  anchor: MultiLineSelectionPoint;
  focus: MultiLineSelectionPoint;
}

interface PointerSelectionSession {
  pointerId: number;
  startX: number;
  startY: number;
  anchor: MultiLineSelectionPoint;
  allowSameLine: boolean;
  active: boolean;
}

const trailingCommand = /\\([\p{L}]*)$/u;

function hasRawLatexInput(field: MathfieldElement) {
  return Boolean(field.shadowRoot?.querySelector(".ML__raw-latex"));
}

function rawLatexInput(field: MathfieldElement) {
  return Array.from(
    field.shadowRoot?.querySelectorAll<HTMLElement>(".ML__raw-latex") ?? [],
  )
    .filter((node) => !node.classList.contains("ML__suggestion"))
    .map((node) => node.textContent ?? "")
    .join("");
}

type MathLiveInternalField = {
  _mathfield?: {
    model?: {
      root?: unknown;
      position?: number;
      parentEnvironment?: {
        environmentName?: string;
      } | null;
    };
  };
};

function resetMathLiveModelRootForExternalSync(field: MathfieldElement) {
  const targetModel = (field as unknown as MathLiveInternalField)._mathfield?.model;
  if (!targetModel || typeof document === "undefined" || !document.body) {
    return false;
  }

  const previouslyFocused = document.activeElement as HTMLElement | null;
  const stagingHost = document.createElement("div");
  stagingHost.setAttribute("aria-hidden", "true");
  stagingHost.style.cssText =
    "position:fixed;left:-100000px;top:0;width:1px;height:1px;overflow:hidden;visibility:hidden;pointer-events:none";
  const freshField = new MathfieldElement();
  freshField.readOnly = true;
  freshField.tabIndex = -1;

  try {
    document.body.append(stagingHost);
    stagingHost.append(freshField);
    freshField.setValue("", {
      mode: "math",
      format: "latex",
      insertionMode: "replaceAll",
      selectionMode: "after",
      silenceNotifications: true,
    });
    const freshModel = (freshField as unknown as MathLiveInternalField)._mathfield
      ?.model;
    if (!freshModel || freshModel.root === undefined) return false;
    targetModel.root = freshModel.root;
    targetModel.position = 0;
    return true;
  } finally {
    stagingHost.remove();
    if (
      previouslyFocused?.isConnected &&
      document.activeElement !== previouslyFocused
    ) {
      previouslyFocused.focus({ preventScroll: true });
    }
  }
}

const structuralExternalSyncPattern = /\\(?:begin\s*\{|left\b|right\b)/;

function needsCleanMathLiveModelForExternalSync(
  currentLatex: string,
  nextLatex: string,
) {
  return (
    structuralExternalSyncPattern.test(currentLatex) ||
    structuralExternalSyncPattern.test(nextLatex)
  );
}

function activeMathLiveEnvironmentName(field: MathfieldElement) {
  return (
    (field as unknown as MathLiveInternalField)._mathfield?.model?.parentEnvironment
      ?.environmentName ?? null
  );
}

function structuralBoundaryOffsetFromPoint(
  field: MathfieldElement,
  clientX: number,
) {
  const elementInfo = Array.from(
    { length: field.lastOffset + 1 },
    (_, offset) => ({ offset, info: field.getElementInfo(offset) }),
  );
  const nextTopLevelBounds = new Array<DOMRect | undefined>(
    elementInfo.length,
  );
  let upcomingTopLevelBounds: DOMRect | undefined;
  for (let index = elementInfo.length - 1; index >= 0; index -= 1) {
    nextTopLevelBounds[index] = upcomingTopLevelBounds;
    const info = elementInfo[index]?.info;
    if (info?.depth === 0 && info.bounds) {
      upcomingTopLevelBounds = info.bounds;
    }
  }

  let previousBounds: DOMRect | undefined;
  for (const candidate of elementInfo) {
    // MathLive's point hit testing uses two-dimensional distance. In the
    // horizontal gap after a scripted expression this can select a superscript
    // or subscript instead of the real top-level boundary represented by this
    // bounds-less model offset. Restrict the correction to the actual gap so
    // clicks on either neighboring structure keep their native behavior.
    if (candidate.info?.depth === 0 && !candidate.info.bounds) {
      const next = nextTopLevelBounds[candidate.offset];
      if (
        previousBounds &&
        next &&
        previousBounds.right <= next.left &&
        clientX >= previousBounds.right &&
        clientX <= next.left
      ) {
        return candidate.offset;
      }
    }

    if (candidate.info?.bounds) previousBounds = candidate.info.bounds;
  }

  return null;
}

function rawCommandQuery(field: MathfieldElement) {
  if (!hasRawLatexInput(field)) return "";
  const match = rawLatexInput(field).match(trailingCommand);
  return match && match[1].length > 0 ? "\\" + match[1] : "";
}

function trailingCommandQuery(
  field: MathfieldElement,
  normalizedValue = field.value,
) {
  if (hasRawLatexInput(field)) return rawCommandQuery(field);
  for (const source of [normalizedValue, field.value]) {
    const match = source.match(trailingCommand);
    if (match) return "\\" + match[1];
  }
  return "";
}

interface WrapperCaretAnchor {
  left: number;
  centerY: number;
  height: number;
}

interface EditorScrollSnapshot {
  scroller: HTMLElement;
  anchorLineId: string | null;
  anchorOffset: number;
  scrollTop: number;
}

type VerticalPlaceholderKind =
  | "fraction"
  | "operator-limit"
  | "script"
  | "stack";

type VerticalPlaceholderAnchor = {
  kind: VerticalPlaceholderKind;
  region: "upper" | "lower";
  centerX: number;
  centerY: number;
  relativeX: number;
  relativeY: number;
};

interface RawCommandAnchor {
  latex: string;
  selection: MathSelectionSnapshot;
  position: number;
  visualCaret: WrapperCaretAnchor | null;
  selectedPlaceholder: boolean;
  selectedPlaceholderIndex: number | null;
  selectedPlaceholderTextIndex: number | null;
  verticalPlaceholder: VerticalPlaceholderAnchor | null;
  autoExitSetting: InputBehaviorSettingKey | null;
  autoExitScriptKey: string | null;
}

const rawCommandAnchors = new WeakMap<MathfieldElement, RawCommandAnchor>();

function latexPlaceholderRanges(field: MathfieldElement) {
  const ranges: Array<[number, number]> = [];
  for (let offset = 1; offset <= field.lastOffset; offset += 1) {
    if (
      field.getValue(offset - 1, offset, "latex").trim() ===
      "\\placeholder{}"
    ) {
      ranges.push([offset - 1, offset]);
    }
  }
  return ranges;
}

const placeholderMarkerCharacters =
  "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

function markedPlaceholderLatex(latex: string) {
  let index = 0;
  const markers: string[] = [];
  const markedLatex = latex.replace(/\\placeholder\{\}/g, () => {
    const marker = placeholderMarkerCharacters[index] ?? "Q";
    markers.push(marker);
    index += 1;
    return marker;
  });
  return { markedLatex, markers };
}

function textualPlaceholderIndexForRange(
  latex: string,
  range: [number, number],
) {
  const { markedLatex, markers } = markedPlaceholderLatex(latex);
  if (!markers.length) return null;
  const verifier = new MathfieldElement();
  verifier.setValue(markedLatex, {
    mode: "math",
    format: "latex",
    insertionMode: "replaceAll",
    selectionMode: "after",
    silenceNotifications: true,
  });
  const marker = verifier
    .getValue(
      Math.min(range[0], range[1]),
      Math.max(range[0], range[1]),
      "latex",
    )
    .trim();
  const index = markers.indexOf(marker);
  return index >= 0 ? index : null;
}

const visualTexPackageMacroNameSet = new Set<string>(
  VISUALTEX_PACKAGE_MACRO_NAMES,
);

function packageMacroForTextualPlaceholder(
  latex: string,
  targetIndex: number,
) {
  let placeholderIndex = -1;
  let placeholderStart = -1;
  const placeholderPattern = /\\placeholder\{\}/g;
  for (const match of latex.matchAll(placeholderPattern)) {
    placeholderIndex += 1;
    if (placeholderIndex !== targetIndex) continue;
    placeholderStart = match.index ?? -1;
    break;
  }
  if (placeholderStart < 0) return null;

  const prefix = latex.slice(0, placeholderStart);
  const candidates: Array<{ name: string; braceStart: number }> = [];
  const commandPattern = /\\([A-Za-z]+)\s*\{/g;
  for (const match of prefix.matchAll(commandPattern)) {
    const name = match[1];
    if (!visualTexPackageMacroNameSet.has(name)) continue;
    const full = match[0];
    const braceOffset = full.lastIndexOf("{");
    const braceStart = (match.index ?? 0) + braceOffset;
    candidates.push({ name, braceStart });
  }

  for (let index = candidates.length - 1; index >= 0; index -= 1) {
    const candidate = candidates[index];
    let depth = 0;
    for (let cursor = candidate.braceStart; cursor < placeholderStart; cursor += 1) {
      if (latex[cursor] === "{" && latex[cursor - 1] !== "\\") depth += 1;
      else if (latex[cursor] === "}" && latex[cursor - 1] !== "\\") depth -= 1;
    }
    if (depth > 0) return candidate.name;
  }
  return null;
}

function clearToolbarPackageMacroHint(field: MathfieldElement) {
  delete field.dataset.toolbarPackageMacroName;
  delete field.dataset.toolbarPackageMacroPlaceholderIndex;
  delete field.dataset.toolbarPackageMacroModelStart;
}

function selectedPackageMacroPlaceholder(field: MathfieldElement) {
  const activeRange = field.selection.ranges.at(-1) ?? null;
  if (!activeRange || activeRange[0] === activeRange[1]) return null;
  const range: [number, number] = [
    Math.min(activeRange[0], activeRange[1]),
    Math.max(activeRange[0], activeRange[1]),
  ];
  if (field.getValue(range[0], range[1], "latex").trim() !== "\\placeholder{}") {
    return null;
  }
  const latex = normalizeChineseLatex(field.value);
  const modelPlaceholderIndex = latexPlaceholderRanges(field).findIndex(
    ([start, end]) => start === range[0] && end === range[1],
  );
  const placeholderIndex =
    textualPlaceholderIndexForRange(latex, range) ??
    (modelPlaceholderIndex >= 0 ? modelPlaceholderIndex : null);
  if (placeholderIndex === null) return null;
  const macroName = packageMacroForTextualPlaceholder(latex, placeholderIndex);
  return macroName ? { latex, placeholderIndex, range, macroName } : null;
}

function replaceTextualPlaceholder(
  latex: string,
  targetIndex: number,
  replacement: string,
) {
  let index = 0;
  let replaced = false;
  const value = latex.replace(/\\placeholder\{\}/g, (placeholder) => {
    if (index !== targetIndex) {
      index += 1;
      return placeholder;
    }
    index += 1;
    replaced = true;
    return replacement;
  });
  return replaced ? value : null;
}

function splitTextualPlaceholder(latex: string, targetIndex: number) {
  let index = 0;
  for (const match of latex.matchAll(/\\placeholder\{\}/g)) {
    if (index !== targetIndex) {
      index += 1;
      continue;
    }
    const start = match.index ?? -1;
    if (start < 0) return null;
    return {
      prefix: latex.slice(0, start),
      suffix: latex.slice(start + match[0].length),
    };
  }
  return null;
}

function modelRangeForTextualPlaceholder(
  field: MathfieldElement,
  latex: string,
  targetIndex: number,
) {
  const { markedLatex, markers } = markedPlaceholderLatex(latex);
  const targetMarker = markers[targetIndex];
  if (!targetMarker) return null;
  const verifier = new MathfieldElement();
  verifier.setValue(markedLatex, {
    mode: "math",
    format: "latex",
    insertionMode: "replaceAll",
    selectionMode: "after",
    silenceNotifications: true,
  });
  return (
    latexPlaceholderRanges(field).find(([start, end]) =>
      verifier.getValue(start, end, "latex").trim() === targetMarker,
    ) ?? null
  );
}

function captureWrapperCaretAnchor(
  field: MathfieldElement,
): WrapperCaretAnchor | null {
  const host = field.closest<HTMLElement>(".mathfield-host");
  if (!host) return null;
  const hostBounds = host.getBoundingClientRect();
  const candidateOffsets = Array.from(
    new Set(
      [field.position, field.position - 1, field.position + 1].filter(
        (offset) => offset >= 0 && offset <= field.lastOffset,
      ),
    ),
  );
  const modelAnchors = candidateOffsets
    .flatMap((offset) => {
      const bounds = field.getElementInfo(offset)?.bounds;
      if (
        !bounds ||
        !Number.isFinite(bounds.right) ||
        !Number.isFinite(bounds.top) ||
        bounds.height <= 0
      ) {
        return [];
      }
      return [{
        left: bounds.right - hostBounds.left,
        centerY: bounds.top - hostBounds.top + bounds.height / 2,
        height: bounds.height,
      }];
    });
  const modelAnchor = modelAnchors[0] ?? null;
  const markerAnchors = Array.from(
    field.shadowRoot?.querySelectorAll<HTMLElement>(
      ".visualtex-structural-placeholder-caret, .ML__caret, .ML__text-caret, .ML__latex-caret",
    ) ?? [],
  )
    .flatMap((marker) => {
      const bounds = marker.getBoundingClientRect();
      const style = getComputedStyle(marker);
      const overlapsHost =
        bounds.right >= hostBounds.left &&
        bounds.left <= hostBounds.right &&
        bounds.bottom >= hostBounds.top &&
        bounds.top <= hostBounds.bottom;
      if (
        bounds.height <= 0 ||
        style.display === "none" ||
        style.visibility === "hidden" ||
        !overlapsHost
      ) {
        return [];
      }
      return [{
        left: bounds.left - hostBounds.left,
        centerY: bounds.top - hostBounds.top + bounds.height / 2,
        height: bounds.height,
        width: bounds.width,
        priority: marker.classList.contains(
          "visualtex-structural-placeholder-caret",
        )
          ? 0
          : marker.classList.contains("ML__caret")
            ? 1
            : 2,
      }];
    })
    .sort(
      (first, second) =>
        first.priority - second.priority ||
        first.width - second.width ||
        first.height - second.height,
    );
  const markerAnchor = markerAnchors[0] ?? null;
  if (markerAnchor) {
    return {
      left: markerAnchor.left,
      centerY: markerAnchor.centerY,
      height: markerAnchor.height,
    };
  }
  return modelAnchor;
}

function visiblePlaceholderNodes(
  field: MathfieldElement,
  scope: ParentNode = field.shadowRoot ?? field,
) {
  return Array.from(
    new Set(
      Array.from(
        scope.querySelectorAll<HTMLElement>(
          `.ML__placeholder, .${visualTexPlaceholderClass}`,
        ),
      ),
    ),
  ).filter((placeholder) => {
    const bounds = placeholder.getBoundingClientRect();
    const style = getComputedStyle(placeholder);
    return (
      bounds.width > 0 &&
      bounds.height > 0 &&
      style.display !== "none" &&
      style.visibility !== "hidden"
    );
  });
}

function closestPlaceholderNodeToMarker(
  field: MathfieldElement,
  marker: HTMLElement,
) {
  if (
    marker.classList.contains("ML__placeholder") ||
    marker.classList.contains(visualTexPlaceholderClass)
  ) {
    return marker;
  }
  const markerBounds = (marker.parentElement ?? marker).getBoundingClientRect();
  const markerX = markerBounds.left + markerBounds.width / 2;
  const markerY = markerBounds.top + markerBounds.height / 2;
  return visiblePlaceholderNodes(field)
    .map((placeholder) => {
      const bounds = placeholder.getBoundingClientRect();
      const centerX = bounds.left + bounds.width / 2;
      const centerY = bounds.top + bounds.height / 2;
      return {
        placeholder,
        distance: Math.hypot(centerX - markerX, centerY - markerY),
      };
    })
    .sort((first, second) => first.distance - second.distance)[0]
    ?.placeholder ?? null;
}

function describeVerticalPlaceholderNode(
  field: MathfieldElement,
  placeholder: HTMLElement,
): VerticalPlaceholderAnchor | null {
  if (placeholder.closest(".ML__sqrt, .ML__accent-body")) return null;

  const placeholderCount = (container: HTMLElement) =>
    visiblePlaceholderNodes(field, container).length;
  const fraction = placeholder.closest<HTMLElement>(".ML__mfrac");
  const operator = placeholder.closest<HTMLElement>(".ML__op-group");
  const script = placeholder.closest<HTMLElement>(".ML__msubsup");
  let stack: HTMLElement | null = null;
  for (
    let current = placeholder.parentElement;
    current;
    current = current.parentElement
  ) {
    if (
      (current.classList.contains("ML__vlist") ||
        current.classList.contains("ML__vlist-r") ||
        current.classList.contains("ML__vlist-t")) &&
      placeholderCount(current) >= 2
    ) {
      stack = current;
      break;
    }
  }

  const directContainer = fraction ?? operator ?? script;
  let container =
    directContainer && placeholderCount(directContainer) >= 2
      ? directContainer
      : stack;
  if (!container) {
    const base = placeholder.closest<HTMLElement>(".ML__base");
    const centers = base
      ? visiblePlaceholderNodes(field, base).map((node) => {
          const bounds = node.getBoundingClientRect();
          return bounds.top + bounds.height / 2;
        })
      : [];
    const verticalSpread = centers.length
      ? Math.max(...centers) - Math.min(...centers)
      : 0;
    if (base && centers.length >= 2 && verticalSpread >= 6) {
      container = base;
    }
  }
  if (!container) return null;

  const placeholderBounds = placeholder.getBoundingClientRect();
  const containerBounds = container.getBoundingClientRect();
  if (
    placeholderBounds.height <= 0 ||
    containerBounds.width <= 0 ||
    containerBounds.height <= 0
  ) {
    return null;
  }

  const centerX = placeholderBounds.left + placeholderBounds.width / 2;
  const centerY = placeholderBounds.top + placeholderBounds.height / 2;
  const relativeX = (centerX - containerBounds.left) / containerBounds.width;
  const relativeY = (centerY - containerBounds.top) / containerBounds.height;
  const kind: VerticalPlaceholderKind = fraction
    ? "fraction"
    : operator
      ? "operator-limit"
      : script
        ? "script"
        : "stack";
  return {
    kind,
    region: relativeY < 0.5 ? "upper" : "lower",
    centerX,
    centerY,
    relativeX,
    relativeY,
  };
}

function describeSelectedVerticalPlaceholder(
  field: MathfieldElement,
): VerticalPlaceholderAnchor | null {
  const marker = activeMathCaretMarker(field);
  if (!marker) return null;
  const placeholder = closestPlaceholderNodeToMarker(field, marker);
  return placeholder
    ? describeVerticalPlaceholderNode(field, placeholder)
    : null;
}

function placeholderRangeForVisualNode(
  field: MathfieldElement,
  placeholder: HTMLElement,
  ranges: Array<[number, number]>,
) {
  const bounds = placeholder.getBoundingClientRect();
  const pointOffset = field.getOffsetFromPoint(
    bounds.left + bounds.width / 2,
    bounds.top + bounds.height / 2,
    { bias: 0 },
  );
  return ranges
    .map((range) => ({
      range,
      distance: Math.min(
        Math.abs(range[0] - pointOffset),
        Math.abs(range[1] - pointOffset),
      ),
    }))
    .sort((first, second) => first.distance - second.distance)[0]
    ?.range ?? null;
}

function findMatchingVerticalPlaceholderRange(
  field: MathfieldElement,
  target: VerticalPlaceholderAnchor,
) {
  const ranges = latexPlaceholderRanges(field);
  const candidates = visiblePlaceholderNodes(field).flatMap((placeholder) => {
    const description = describeVerticalPlaceholderNode(field, placeholder);
    if (
      !description ||
      description.kind !== target.kind ||
      description.region !== target.region
    ) {
      return [];
    }
    const range = placeholderRangeForVisualNode(field, placeholder, ranges);
    if (!range) return [];
    return [{
      range,
      score:
        Math.abs(description.relativeY - target.relativeY) * 1200 +
        Math.abs(description.relativeX - target.relativeX) * 300 +
        Math.abs(description.centerY - target.centerY) * 4 +
        Math.abs(description.centerX - target.centerX),
    }];
  });
  return candidates.sort((first, second) => first.score - second.score)[0]
    ?.range ?? null;
}

function rememberRawCommandAnchor(field: MathfieldElement) {
  if (rawCommandAnchors.has(field)) return;
  clearVisualTexPlaceholderRestoreState(field);
  const selection = captureSelection(field);
  const activeRange = selection.ranges.at(-1);
  const selectedLatex = activeRange
    ? field
        .getValue(
          Math.min(activeRange[0], activeRange[1]),
          Math.max(activeRange[0], activeRange[1]),
          "latex",
        )
        .trim()
    : "";
  const selectedPlaceholder = selectedLatex === "\\placeholder{}";
  const normalizedActiveRange = activeRange
    ? [
        Math.min(activeRange[0], activeRange[1]),
        Math.max(activeRange[0], activeRange[1]),
      ] as [number, number]
    : null;
  const selectedPlaceholderIndex =
    selectedPlaceholder && normalizedActiveRange
      ? latexPlaceholderRanges(field).findIndex(
          ([start, end]) =>
            start === normalizedActiveRange[0] &&
            end === normalizedActiveRange[1],
        )
      : -1;
  const selectedPlaceholderTextIndex =
    selectedPlaceholder && normalizedActiveRange
      ? (textualPlaceholderIndexForRange(
          normalizeChineseLatex(field.value),
          normalizedActiveRange,
        ) ??
        (selectedPlaceholderIndex >= 0 ? selectedPlaceholderIndex : null))
      : null;
  const autoExitSetting = getCaretAutoExitSetting(field);
  const scriptContext = getScriptCaretContext(field);
  rawCommandAnchors.set(field, {
    latex: normalizeChineseLatex(field.value),
    selection,
    position: field.position,
    visualCaret: captureWrapperCaretAnchor(field),
    selectedPlaceholder,
    selectedPlaceholderIndex:
      selectedPlaceholderIndex >= 0 ? selectedPlaceholderIndex : null,
    selectedPlaceholderTextIndex,
    verticalPlaceholder: null,
    autoExitSetting,
    autoExitScriptKey:
      autoExitSetting === "autoExitSuperscript" ||
      autoExitSetting === "autoExitSubscript"
        ? scriptContext?.autoExitKey ?? null
        : null,
  });
}

function canonicalRawCommandAnchorSkeleton(latex: string) {
  const verifier = new MathfieldElement();
  verifier.setValue(latex.replace(/\\placeholder\{\}/g, ""), {
    mode: "math",
    format: "latex",
    insertionMode: "replaceAll",
    selectionMode: "after",
    silenceNotifications: true,
  });
  return normalizeChineseLatex(verifier.value)
    .replace(/\s+/g, "")
    .replace(/\{([A-Za-z0-9])\}/g, "$1");
}

function restoreCancelledRawCommandAnchor(
  field: MathfieldElement,
  anchor: RawCommandAnchor,
) {
  field.executeCommand(["complete", "reject"]);
  field.mode = "math";
  field.setValue(anchor.latex, {
    mode: "math",
    format: "latex",
    insertionMode: "replaceAll",
    selectionMode: "after",
    silenceNotifications: true,
  });
  const selection = clampSelection(anchor.selection, field.lastOffset);
  field.selection = selection;
  if (selection.ranges.every(([start, end]) => start === end)) {
    field.position = Math.max(0, Math.min(field.lastOffset, anchor.position));
  }
  return selection;
}

function restoreSelectedPlaceholderAnchor(
  field: MathfieldElement,
  anchor: RawCommandAnchor,
) {
  const placeholderIndex = anchor.selectedPlaceholderIndex;
  if (placeholderIndex === null) return null;

  clearVisualTexPlaceholderRestoreState(field);
  field.executeCommand(["complete", "reject"]);
  field.mode = "math";
  // `replaceAll` and an ordinary full-range selection can leave the empty
  // container that held the rejected raw group in MathLive's atom tree. Exit
  // every nested parent first, then remove every atom from the root model.
  for (let depth = 0; depth < 12; depth += 1) {
    if (!field.executeCommand("moveAfterParent")) break;
  }
  field.executeCommand("deleteAll");
  field.setValue(anchor.latex, {
    mode: "math",
    format: "latex",
    insertionMode: "replaceAll",
    selectionMode: "after",
    silenceNotifications: true,
  });
  const targetRange = latexPlaceholderRanges(field)[placeholderIndex] ?? null;
  if (!targetRange) return null;

  const selection: MathSelectionSnapshot = {
    ranges: [targetRange],
    direction: "none",
  };
  field.selection = selection;
  return selection;
}

function restoreRawCommandInsertionAnchor(
  field: MathfieldElement,
  anchor: RawCommandAnchor,
) {
  if (anchor.selectedPlaceholder) {
    const restored = restoreSelectedPlaceholderAnchor(field, anchor);
    if (restored) return restored;
    const selection = clampSelection(anchor.selection, field.lastOffset);
    field.selection = selection;
    return selection;
  }
  return restoreRawCommandAnchor(field, anchor);
}

function restoreRawCommandAnchor(
  field: MathfieldElement,
  anchor: RawCommandAnchor,
) {
  const rejectedRawGroup = field.executeCommand(["complete", "reject"]);
  if (!rejectedRawGroup) field.mode = "math";

  const currentLatex = normalizeChineseLatex(field.value);
  const anchorContainsPlaceholder = anchor.latex.includes("\\placeholder{}");
  const retainedPlaceholderContainer =
    anchorContainsPlaceholder &&
    canonicalRawCommandAnchorSkeleton(currentLatex) ===
      canonicalRawCommandAnchorSkeleton(anchor.latex);

  // MathLive keeps the original empty container when it rejects nested raw
  // input. Keep that model, but explicitly restore the original caret: the
  // selection produced by reject can drift outside an accent/script/fraction
  // and makes the accepted command appear in a surprising location.
  if (retainedPlaceholderContainer) {
    field.mode = "math";
    const preferredRange = anchor.selection.ranges.at(-1);
    const preferredStart = preferredRange
      ? Math.min(preferredRange[0], preferredRange[1])
      : anchor.position;

    // Preserve the original, proven single-slot behaviour for accents, roots
    // and other ordinary placeholders. Multi-branch vertical structures are
    // intercepted separately before this function is called.
    if (anchor.selectedPlaceholder) {
      const closestPlaceholder = latexPlaceholderRanges(field).sort(
        (first, second) =>
          Math.abs(first[0] - preferredStart) -
          Math.abs(second[0] - preferredStart),
      )[0];
      if (closestPlaceholder) {
        const selection: MathSelectionSnapshot = {
          ranges: [closestPlaceholder],
          direction: "none",
        };
        field.selection = selection;
        return selection;
      }

      const position = Math.max(
        0,
        Math.min(field.lastOffset, preferredStart),
      );
      const selection: MathSelectionSnapshot = {
        ranges: [[position, position]],
        direction: "none",
      };
      field.selection = selection;
      field.position = position;
      return selection;
    }

    const selection = clampSelection(anchor.selection, field.lastOffset);
    field.selection = selection;
    if (selection.ranges.every(([start, end]) => start === end)) {
      field.position = Math.max(
        0,
        Math.min(field.lastOffset, anchor.position),
      );
    }
    return selection;
  }

  if (currentLatex !== anchor.latex) {
    field.setValue(anchor.latex, {
      mode: "math",
      format: "latex",
      insertionMode: "replaceAll",
      selectionMode: "after",
      silenceNotifications: true,
    });
  }
  const selection = clampSelection(anchor.selection, field.lastOffset);
  field.selection = selection;
  const selectionIsCollapsed = selection.ranges.every(
    ([start, end]) => start === end,
  );
  if (selectionIsCollapsed) {
    field.position = Math.max(0, Math.min(field.lastOffset, anchor.position));
  }
  return selection;
}

const structuredSuggestionCommands = new Set([
  ...compatibilityWrapperPreviews.keys(),
  ...compatibilityRawPlaceholderTemplates.keys(),
  "\\sum",
  "\\prod",
  "\\coprod",
  "\\int",
  "\\iint",
  "\\iiint",
  "\\oint",
  "\\oiint",
  "\\oiiint",
  "\\lim",
  "\\bigcup",
  "\\bigcap",
]);
const nativePlaceholderSelectionCommands = new Set([
  "\\frac",
  "\\dfrac",
  "\\tfrac",
  "\\sqrt",
]);
const accentCommandTemplates = new Map<string, string>([
  ["\\acute", "\\acute{\\placeholder{}}"],
  ["\\grave", "\\grave{\\placeholder{}}"],
  ["\\dot", "\\dot{\\placeholder{}}"],
  ["\\ddot", "\\ddot{\\placeholder{}}"],
  ["\\dddot", "\\dddot{\\placeholder{}}"],
  ["\\ddddot", "\\ddddot{\\placeholder{}}"],
  ["\\tilde", "\\tilde{\\placeholder{}}"],
  ["\\bar", "\\bar{\\placeholder{}}"],
  ["\\breve", "\\breve{\\placeholder{}}"],
  ["\\check", "\\check{\\placeholder{}}"],
  ["\\hat", "\\hat{\\placeholder{}}"],
  ["\\vec", "\\vec{\\placeholder{}}"],
  ["\\widehat", "\\widehat{\\placeholder{}}"],
  ["\\widetilde", "\\widetilde{\\placeholder{}}"],
  ["\\overline", "\\overline{\\placeholder{}}"],
  ["\\overrightarrow", "\\overrightarrow{\\placeholder{}}"],
  ["\\overleftarrow", "\\overleftarrow{\\placeholder{}}"],
  ["\\overleftrightarrow", "\\overleftrightarrow{\\placeholder{}}"],
  ["\\mathring", "\\mathring{\\placeholder{}}"],
]);
const CASES_ENVIRONMENT_COMMAND = "\\begin{cases}";
const CASES_ENVIRONMENT_TEMPLATE =
  "\\begin{cases}\\placeholder{} & \\placeholder{}\\end{cases}";

const rawPlaceholderCommandTemplates = new Map<string, string>([
  ...accentCommandTemplates,
  ...compatibilityRawPlaceholderTemplates,
  [CASES_ENVIRONMENT_COMMAND, CASES_ENVIRONMENT_TEMPLATE],
  ["\\sqrt", "\\sqrt{\\placeholder{}}"],
  ["\\frac", "\\frac{\\placeholder{}}{\\placeholder{}}"],
  ["\\dfrac", "\\dfrac{\\placeholder{}}{\\placeholder{}}"],
  ["\\tfrac", "\\tfrac{\\placeholder{}}{\\placeholder{}}"],
  ["\\binom", "\\binom{\\placeholder{}}{\\placeholder{}}"],
  ["\\overset", "\\overset{\\placeholder{}}{\\placeholder{}}"],
  ["\\underset", "\\underset{\\placeholder{}}{\\placeholder{}}"],
  [
    "\\overunderset",
    "\\overset{\\placeholder{}}{\\underset{\\placeholder{}}{\\placeholder{}}}",
  ],
  ["\\stackrel", "\\stackrel{\\placeholder{}}{\\placeholder{}}"],
  ["\\stackbin", "\\stackbin{\\placeholder{}}{\\placeholder{}}"],
  ["\\overarc", "\\overarc{\\placeholder{}}"],
  ["\\overbrace", "\\overbrace{\\placeholder{}}"],
  ["\\overgroup", "\\overgroup{\\placeholder{}}"],
  ["\\overparen", "\\overparen{\\placeholder{}}"],
  ["\\overleftharpoon", "\\overleftharpoon{\\placeholder{}}"],
  ["\\overlinesegment", "\\overlinesegment{\\placeholder{}}"],
  ["\\overrightharpoon", "\\overrightharpoon{\\placeholder{}}"],
  ["\\underarc", "\\underarc{\\placeholder{}}"],
  ["\\underline", "\\underline{\\placeholder{}}"],
  ["\\underbrace", "\\underbrace{\\placeholder{}}"],
  ["\\undergroup", "\\undergroup{\\placeholder{}}"],
  ["\\underparen", "\\underparen{\\placeholder{}}"],
  ["\\underleftarrow", "\\underleftarrow{\\placeholder{}}"],
  ["\\underrightarrow", "\\underrightarrow{\\placeholder{}}"],
  ["\\underlinesegment", "\\underlinesegment{\\placeholder{}}"],
  ["\\underleftrightarrow", "\\underleftrightarrow{\\placeholder{}}"],
]);
const reverseModelPlaceholderOrderCommands = new Set([
  "\\overset",
  "\\underset",
  "\\overunderset",
  "\\stackrel",
  "\\stackbin",
]);
const wrapperCommandPreviews = new Map<string, string>([
  ...compatibilityWrapperPreviews,
  ["\\mathbb", "\\mathbb{ABC}"],
  ["\\mathbf", "\\mathbf{ABC}"],
  ["\\mathit", "\\mathit{ABC}"],
  ["\\mathop", "\\mathop{f(x)}"],
  ["\\mathrm", "\\mathrm{ABC}"],
  ["\\mathsf", "\\mathsf{ABC}"],
  ["\\mathtt", "\\mathtt{ABC}"],
  ["\\mathcal", "\\mathcal{ABC}"],
  ["\\mathscr", "\\mathscr{gG}"],
  ["\\mathfrak", "\\mathfrak{ABC}"],
  ["\\boldsymbol", "\\boldsymbol{\\alpha A}"],
  ["\\bm", "\\bm{\\alpha A}"],
  ["\\mathbfit", "\\mathbfit{ABC}"],
  ["\\mathnormal", "\\mathnormal{ABC}"],
]);
function visibleCommandSuggestions(
  rawQuery: string,
  usage: Record<string, CommandUsage>,
  personalize: boolean,
  limit: number,
  settings: InputBehaviorSettings,
) {
  // MathLive already commits \partial as a complete atomic command. Treating
  // that committed value as a fresh VisualTeX search query used to surface the
  // unrelated \pdv shorthand immediately afterwards.
  if (rawQuery.trim() === "\\partial") return [];

  return searchCommands(
    rawQuery,
    usage,
    personalize,
    getRuntimeCommandRegistry().length,
  )
    .filter((command) =>
      structuredSuggestionCommands.has(command.command)
        ? settings.showStructuredCommandSuggestions
        : settings.showOtherCommandSuggestions,
    )
    .slice(0, limit);
}

function exactRawPlaceholderTemplate(rawQuery: string) {
  return rawPlaceholderCommandTemplates.get(rawQuery.trim()) ?? null;
}

function selectOperatorLimitPlaceholderByGeometry(
  field: MathfieldElement,
  region: "upper" | "lower",
) {
  const ranges = latexPlaceholderRanges(field);
  const candidates = visiblePlaceholderNodes(field).flatMap((placeholder) => {
    const description = describeVerticalPlaceholderNode(field, placeholder);
    if (
      !description ||
      description.region !== region ||
      (description.kind !== "operator-limit" && description.kind !== "script")
    ) {
      return [];
    }
    const range = placeholderRangeForVisualNode(field, placeholder, ranges);
    if (!range) return [];
    return [{ range, centerX: description.centerX }];
  });
  const target = candidates.sort(
    (left, right) => left.centerX - right.centerX,
  )[0];
  if (!target) return false;
  field.selection = {
    ranges: [target.range],
    direction: "none",
  };
  return true;
}

function activeOperatorLimitRegion(
  field: MathfieldElement,
): "upper" | "lower" | null {
  const marker = activeMathCaretMarker(field);
  const operator = marker?.closest<HTMLElement>(".ML__op-group");
  if (marker && operator) {
    const markerBounds = (marker.parentElement ?? marker).getBoundingClientRect();
    const operatorBounds = operator.getBoundingClientRect();
    if (markerBounds.height > 0 && operatorBounds.height > 0) {
      return markerBounds.top + markerBounds.height / 2 <
        operatorBounds.top + operatorBounds.height / 2
        ? "upper"
        : "lower";
    }
  }

  // Some extended integral glyphs are rendered by MathLive as a generic
  // vertical stack rather than an `.ML__op-group`. Reuse VisualTeX's geometry-
  // based placeholder classifier so those operators still participate in the
  // same lower -> upper -> body navigation contract.
  const vertical = describeSelectedVerticalPlaceholder(field);
  return vertical && vertical.kind !== "fraction" ? vertical.region : null;
}

function selectFirstLatexPlaceholder(
  field: MathfieldElement,
  command: string,
  insertionTemplate = command,
) {
  if (hasBoundedOperatorPlaceholderOrder(insertionTemplate)) {
    // MathLive does not expose one stable model order for every large operator:
    // standard \int/\sum start on the visual upper branch, while some extended
    // integral commands already start on the lower branch. Base the correction
    // on the rendered semantic region instead of assuming either model order.
    if (activeOperatorLimitRegion(field) === "lower") {
      field.dataset.visualtexBoundedOperatorStage = "lower";
      return;
    }

    const initialSelection = captureSelection(field);
    const initialPosition = field.position;
    const maxAttempts = Math.max(4, field.lastOffset + 2);
    for (let attempt = 0; attempt < maxAttempts; attempt += 1) {
      if (!field.executeCommand("moveToNextPlaceholder")) break;
      if (activeOperatorLimitRegion(field) === "lower") {
        field.dataset.visualtexBoundedOperatorStage = "lower";
        return;
      }
    }

    field.selection = initialSelection;
    field.position = initialPosition;
    for (let attempt = 0; attempt < maxAttempts; attempt += 1) {
      if (!field.executeCommand("moveToPreviousPlaceholder")) break;
      if (activeOperatorLimitRegion(field) === "lower") {
        field.dataset.visualtexBoundedOperatorStage = "lower";
        return;
      }
    }

    field.selection = initialSelection;
    field.position = initialPosition;
    if (
      selectOperatorLimitPlaceholderByGeometry(field, "lower") &&
      activeOperatorLimitRegion(field) === "lower"
    ) {
      field.dataset.visualtexBoundedOperatorStage = "lower";
      return;
    }
    field.selection = initialSelection;
    field.position = initialPosition;
    delete field.dataset.visualtexBoundedOperatorStage;
  }
  if (!reverseModelPlaceholderOrderCommands.has(command)) return;
  for (let offset = field.lastOffset; offset > 0; offset -= 1) {
    if (field.getElementInfo(offset)?.latex?.trim() !== "\\placeholder{}") {
      continue;
    }
    field.selection = {
      ranges: [[offset - 1, offset]],
      direction: "none",
    };
    return;
  }
}

function moveBoundedOperatorRight(
  field: MathfieldElement,
) {
  const stage = field.dataset.visualtexBoundedOperatorStage;
  if (stage !== "lower" && stage !== "upper") return false;

  const region = activeOperatorLimitRegion(field);
  if (stage === "lower") {
    if (region !== "lower") {
      if (region === "upper") {
        field.dataset.visualtexBoundedOperatorStage = "upper";
      } else {
        delete field.dataset.visualtexBoundedOperatorStage;
      }
      return false;
    }

    // Composite lower limits such as `k=1` contain more than one placeholder.
    // Keep moving right inside the lower branch while another lower placeholder
    // exists; only after the last lower placeholder do we cross to the upper
    // branch. This keeps the semantic order lower -> upper even though MathLive's
    // native placeholder cycle starts from the visual upper branch.
    const beforeSelection = captureSelection(field);
    const beforePosition = field.position;
    if (field.executeCommand("moveToNextPlaceholder")) {
      const nextRegion = activeOperatorLimitRegion(field);
      if (nextRegion === "lower") return true;
      if (nextRegion === "upper") {
        field.dataset.visualtexBoundedOperatorStage = "upper";
        return true;
      }
      field.selection = beforeSelection;
      field.position = beforePosition;
    }

    // Walk backward through any already-filled lower placeholders until the
    // visual upper branch is reached. A fixed attempt count based on the field
    // size avoids coupling this logic to a specific operator template.
    const maxAttempts = Math.max(4, field.lastOffset + 2);
    for (let attempt = 0; attempt < maxAttempts; attempt += 1) {
      if (!field.executeCommand("moveToPreviousPlaceholder")) break;
      const previousRegion = activeOperatorLimitRegion(field);
      if (previousRegion === "upper") {
        field.dataset.visualtexBoundedOperatorStage = "upper";
        return true;
      }
    }

    if (
      selectOperatorLimitPlaceholderByGeometry(field, "upper") &&
      activeOperatorLimitRegion(field) === "upper"
    ) {
      field.dataset.visualtexBoundedOperatorStage = "upper";
      return true;
    }

    delete field.dataset.visualtexBoundedOperatorStage;
    return false;
  }

  if (region !== "upper") {
    delete field.dataset.visualtexBoundedOperatorStage;
    return false;
  }

  // Once the upper limit is active, Right Arrow must leave the limit pair and
  // continue to the next formula placeholder (integrand/term/etc.). If the
  // lower placeholder is still empty, MathLive may visit it again first, so
  // keep advancing until the caret is outside the operator limits.
  const maxAttempts = Math.max(4, field.lastOffset + 2);
  for (let attempt = 0; attempt < maxAttempts; attempt += 1) {
    if (!field.executeCommand("moveToNextPlaceholder")) break;
    const nextRegion = activeOperatorLimitRegion(field);
    if (nextRegion === "upper") return true;
    if (nextRegion === null) {
      delete field.dataset.visualtexBoundedOperatorStage;
      return true;
    }
  }

  // A custom bounded operator can legitimately have no following placeholder.
  // In that case leave the script/operator hierarchy itself instead of falling
  // back to MathLive's native upper -> lower horizontal cycle.
  for (let attempt = 0; attempt < 4; attempt += 1) {
    if (!field.executeCommand("moveAfterParent")) break;
    if (activeOperatorLimitRegion(field) === null) {
      delete field.dataset.visualtexBoundedOperatorStage;
      return true;
    }
  }

  delete field.dataset.visualtexBoundedOperatorStage;
  return false;
}

function isAccentContainerLatex(latex: string) {
  const normalized = latex.trim();
  return Array.from(accentCommandTemplates.keys()).some((command) =>
    normalized.startsWith(command + "{"),
  );
}

function selectAdjacentAccentPlaceholder(
  field: MathfieldElement,
  direction: "left" | "right",
) {
  if (!field.selectionIsCollapsed || field.mode === "latex") return false;

  const position = field.position;
  for (let end = 1; end <= field.lastOffset; end += 1) {
    if (
      field.getValue(end - 1, end, "latex").trim() !== "\\placeholder{}"
    ) {
      continue;
    }
    const containerLatex =
      field.getElementInfo(Math.min(field.lastOffset, end + 1))?.latex ?? "";
    if (!isAccentContainerLatex(containerLatex)) continue;

    const start = end - 1;
    const adjacentBoundary =
      direction === "left" ? end + 1 : start - 1;
    if (position !== adjacentBoundary) continue;

    field.selection = {
      ranges: [[start, end]],
      direction: "none",
    };
    return true;
  }
  return false;
}

function exactWrapperCommand(rawQuery: string) {
  const normalizedQuery = rawQuery.trim();
  if (!wrapperCommandPreviews.has(normalizedQuery)) return null;
  return findRuntimeCommandByCommand(normalizedQuery);
}

function findAcceptedWrapperRange(
  field: MathfieldElement,
  command: string,
  preferredPosition: number,
) {
  const candidates: Array<[number, number]> = [];
  for (let end = 1; end <= field.lastOffset; end += 1) {
    const latex = field.getValue(end - 1, end, "latex").trim();
    if (latex.startsWith(`${command}{`)) {
      candidates.push([end - 1, end]);
    }
  }
  return (
    candidates.sort(
      (first, second) =>
        Math.abs(first[0] - preferredPosition) -
        Math.abs(second[0] - preferredPosition),
    )[0] ?? null
  );
}

function decorateNativeSuggestionPreviews() {
  const panel = document.getElementById("mathlive-suggestion-popover");
  if (!panel) {
    scheduleStableNativeInputPopoverSync();
    return;
  }

  panel.querySelectorAll<HTMLElement>("li[data-command]").forEach((item) => {
    const command = item.dataset.command ?? "";
    const preview = item.querySelector<HTMLElement>(".ML__popover__command");
    if (!preview) return;
    const decoratedCommand = preview.dataset.visualtexPreviewCommand;
    if (
      preview.dataset.visualtexPreview &&
      decoratedCommand === command
    ) {
      return;
    }
    if (preview.dataset.visualtexPreview) {
      preview.innerHTML = convertVisualTexLatexToMarkup(command, {
        defaultMode: "math",
      });
      delete preview.dataset.visualtexPreview;
      delete preview.dataset.visualtexPreviewKind;
      delete preview.dataset.visualtexPreviewCommand;
      delete item.dataset.visualtexPreviewKind;
      item.classList.remove("has-visualtex-command-preview");
    }
    const resolved = resolveNativeSuggestionPreview(command, preview);
    if (!resolved) return;
    let previewLatex = resolved.latex;
    let previewKind = resolved.kind;

    preview.innerHTML = convertVisualTexLatexToMarkup(previewLatex, {
      defaultMode: "math",
    });
    if (!nativeSuggestionPreviewHasVisibleInk(preview)) {
      preview.innerHTML = convertVisualTexLatexToMarkup("\\boxed{?}", {
        defaultMode: "math",
      });
      previewLatex = "\\boxed{?}";
      previewKind = "fallback";
    }
    preview.querySelectorAll<HTMLElement>(".ML__cmr").forEach((node) => {
      if (node.textContent?.trim() !== "▢") return;
      node.classList.add("visualtex-native-preview-placeholder");
    });
    preview.dataset.visualtexPreview = previewLatex;
    preview.dataset.visualtexPreviewKind = previewKind;
    preview.dataset.visualtexPreviewCommand = command;
    preview.setAttribute("aria-label", command);
    item.dataset.visualtexPreviewKind = previewKind;
    item.classList.add("has-visualtex-command-preview");
  });
  scheduleStableNativeInputPopoverSync();
}

const STABLE_NATIVE_INPUT_POPOVER_ID =
  "visualtex-native-input-suggestion-popover";
const hiddenNativeMathSuggestionCommands = new Set(["\\part", "\\dag"]);
let stableNativeInputPopoverFrame = 0;
let stableNativeInputPopoverHideTimer = 0;
let nativeInputPopoverBodyObserver: MutationObserver | null = null;
let nativeInputPopoverSourceObserver: MutationObserver | null = null;
let observedNativeInputPopoverSource: HTMLElement | null = null;
let nativeSuggestionUsageSnapshot: Record<string, CommandUsage> = {};
let nativeSuggestionPersonalizeSnapshot = true;
let nativeInputPopoverManualCommand = "";
let nativeInputPopoverActiveField: MathfieldElement | null = null;

function casesEnvironmentSuggestionQuery(field: MathfieldElement) {
  const raw = rawLatexInput(field).replace(/\s+/g, "");
  // `\\begin{cases}` is an environment rather than a MathLive command, so
  // MathLive never contributes it to the native `\\b...` candidate pool by
  // itself. VisualTeX injects it as a normal candidate from the first `b`, then
  // lets the same usage-frequency ranking decide where it appears alongside
  // every other native b-command.
  if (raw.length < "\\b".length) return "";
  if (!CASES_ENVIRONMENT_COMMAND.startsWith(raw)) return "";
  return raw;
}

function createCasesEnvironmentSuggestionItem() {
  const preview = convertVisualTexLatexToMarkup(
    "\\begin{cases}x & x>0\\\\0 & x=0\\end{cases}",
    { defaultMode: "math" },
  );
  const item = document.createElement("li");
  item.setAttribute("role", "button");
  item.dataset.command = CASES_ENVIRONMENT_COMMAND;
  item.dataset.visualtexEnvironmentSuggestion = "cases";
  item.className = "has-visualtex-command-preview";
  item.innerHTML = `<span class="ML__popover__latex">\\begin{cases}</span><span class="ML__popover__command">${preview}</span><span class="ML__popover__keybinding">Space</span>`;
  return item;
}

function syncCasesEnvironmentSuggestionItem(
  panel: HTMLElement,
  field: MathfieldElement,
) {
  const query = casesEnvironmentSuggestionQuery(field);
  const synthetic = panel.querySelector<HTMLElement>(
    'li[data-visualtex-environment-suggestion="cases"]',
  );
  const nativeAlreadyProvidesCases = Array.from(
    panel.querySelectorAll<HTMLElement>("li[data-command]"),
  ).some(
    (item) =>
      item !== synthetic && item.dataset.command === CASES_ENVIRONMENT_COMMAND,
  );
  if (!query || nativeAlreadyProvidesCases) {
    synthetic?.remove();
    return;
  }
  if (synthetic) return;
  const list = panel.querySelector("ul");
  if (!list) return;
  list.append(createCasesEnvironmentSuggestionItem());
}

function renderCasesEnvironmentSuggestion(
  stable: HTMLElement,
  field: MathfieldElement,
) {
  const query = casesEnvironmentSuggestionQuery(field);
  if (!query) return false;

  const preview = convertVisualTexLatexToMarkup(
    "\\begin{cases}x & x>0\\\\0 & x=0\\end{cases}",
    { defaultMode: "math" },
  );
  stable.dataset.visualtexEnvironmentSuggestion = "cases";
  stable.innerHTML = `<ul><li role="button" data-command="\\begin{cases}" class="ML__popover__current has-visualtex-command-preview"><span class="ML__popover__latex">\\begin{cases}</span><span class="ML__popover__command">${preview}</span><span class="ML__popover__keybinding">Space</span></li></ul>`;

  const caret =
    field.shadowRoot?.querySelector<HTMLElement>(
      ".ML__latex-caret, .ML__caret, .ML__text-caret",
    ) ?? null;
  const anchor = caret?.getBoundingClientRect() ?? field.getBoundingClientRect();
  const width = Math.min(380, Math.max(250, window.innerWidth - 24));
  const left = Math.max(
    12,
    Math.min(window.innerWidth - width - 12, anchor.left - 40),
  );
  const roomBelow = window.innerHeight - anchor.bottom;
  stable.classList.toggle("bottom-tip", roomBelow < 190);
  stable.classList.toggle("top-tip", roomBelow >= 190);
  stable.style.left = `${left}px`;
  stable.style.top =
    roomBelow < 190
      ? `${Math.max(12, anchor.top - 92)}px`
      : `${Math.min(window.innerHeight - 72, anchor.bottom + 12)}px`;
  stable.classList.add("is-visible");
  stable.setAttribute("aria-hidden", "false");
  return true;
}

function nativeSuggestionUsageId(command: string) {
  const normalized = command.trim();
  return (
    findRuntimeCommandByCommand(normalized)?.id ?? `mathlive-native:${normalized}`
  );
}

function nativeSuggestionFrequency(command: string) {
  const usage = nativeSuggestionUsageSnapshot[nativeSuggestionUsageId(command)];
  return {
    // Records created before source-aware frequency tracking did not contain
    // contextCounts. Preserve that lifetime history during upgrade, while new
    // records rank the native popup strictly by native candidate acceptance.
    count: usage?.contextCounts
      ? usage.contextCounts.candidate ?? 0
      : usage?.useCount ?? 0,
    lastUsedAt: usage?.lastUsedAt ?? 0,
  };
}

function rankNativeSuggestionItems(panel: HTMLElement) {
  const allItems = Array.from(
    panel.querySelectorAll<HTMLElement>("li[data-command]"),
  );
  if (!allItems.length) return;
  const parent = allItems[0]?.parentElement;
  if (!parent || allItems.some((item) => item.parentElement !== parent)) return;

  const seenCommands = new Set<string>();
  const items = allItems.filter((item) => {
    const command = item.dataset.command?.trim() ?? "";
    if (hiddenNativeMathSuggestionCommands.has(command)) {
      item.remove();
      return false;
    }
    if (!command || !seenCommands.has(command)) {
      if (command) seenCommands.add(command);
      return true;
    }
    item.remove();
    return false;
  });

  const ranked = nativeSuggestionPersonalizeSnapshot
    ? items
        .map((item, index) => ({ item, index }))
        .sort((left, right) => {
          const rightUsage = nativeSuggestionFrequency(
            right.item.dataset.command ?? "",
          );
          const leftUsage = nativeSuggestionFrequency(
            left.item.dataset.command ?? "",
          );
          if (rightUsage.count !== leftUsage.count) {
            return rightUsage.count - leftUsage.count;
          }
          if (rightUsage.lastUsedAt !== leftUsage.lastUsedAt) {
            return rightUsage.lastUsedAt - leftUsage.lastUsedAt;
          }
          return left.index - right.index;
        })
        .map(({ item }) => item)
    : items;

  if (ranked.some((item, index) => item !== items[index])) {
    const fragment = document.createDocumentFragment();
    ranked.forEach((item) => fragment.append(item));
    parent.append(fragment);
  }

  const availableCommands = new Set(
    ranked.map((item) => item.dataset.command ?? ""),
  );
  if (
    nativeInputPopoverManualCommand &&
    !availableCommands.has(nativeInputPopoverManualCommand)
  ) {
    nativeInputPopoverManualCommand = "";
  }
  const selectedCommand =
    nativeInputPopoverManualCommand || ranked[0]?.dataset.command || "";
  for (const item of ranked) {
    item.classList.toggle(
      "ML__popover__current",
      item.dataset.command === selectedCommand,
    );
  }
}

function recordNativeSuggestionUsage(command: string, prefix = command) {
  if (!command) return;
  useEditorStore
    .getState()
    .recordCommand(nativeSuggestionUsageId(command), prefix, "candidate");
  nativeSuggestionUsageSnapshot = useEditorStore.getState().usage;
  scheduleStableNativeInputPopoverSync();
}

function getNativeInputPopoverSource() {
  return document.getElementById("mathlive-suggestion-popover");
}

function ensureStableNativeInputPopover() {
  let panel = document.getElementById(STABLE_NATIVE_INPUT_POPOVER_ID);
  if (panel) return panel;

  panel = document.createElement("div");
  panel.id = STABLE_NATIVE_INPUT_POPOVER_ID;
  panel.setAttribute("aria-hidden", "true");
  panel.addEventListener("pointerdown", (event) => event.preventDefault());
  panel.addEventListener("click", (event) => {
    const target = event.target;
    if (!(target instanceof Element)) return;
    const item = target.closest<HTMLElement>("li[data-command]");
    const command = item?.dataset.command ?? "";
    if (!command) return;
    recordNativeSuggestionUsage(command);
    const sourceItem = Array.from(
      getNativeInputPopoverSource()?.querySelectorAll<HTMLElement>(
        "li[data-command]",
      ) ?? [],
    ).find((candidate) => candidate.dataset.command === command);
    if (
      sourceItem &&
      sourceItem.dataset.visualtexEnvironmentSuggestion !== "cases"
    ) {
      sourceItem.dispatchEvent(
        new MouseEvent("click", {
          bubbles: true,
          cancelable: true,
          view: window,
        }),
      );
      return;
    }
    if (
      command === CASES_ENVIRONMENT_COMMAND &&
      nativeInputPopoverActiveField?.isConnected
    ) {
      nativeInputPopoverActiveField.dataset.pendingNativeSuggestion = command;
      nativeInputPopoverActiveField.dispatchEvent(
        new KeyboardEvent("keydown", {
          key: " ",
          code: "Space",
          bubbles: true,
          cancelable: true,
        }),
      );
    }
  });
  document.body.append(panel);
  return panel;
}

function bindNativeInputPopoverSource() {
  const source = getNativeInputPopoverSource();
  if (source === observedNativeInputPopoverSource) return;
  nativeInputPopoverSourceObserver?.disconnect();
  observedNativeInputPopoverSource = source;
  if (!source) return;
  nativeInputPopoverSourceObserver = new MutationObserver(() =>
    scheduleStableNativeInputPopoverSync(),
  );
  nativeInputPopoverSourceObserver.observe(source, {
    attributes: true,
    attributeFilter: ["class", "style", "aria-hidden"],
    childList: true,
    characterData: true,
    subtree: true,
  });
}

function ensureNativeInputPopoverObservers() {
  if (nativeInputPopoverBodyObserver || !document.body) return;
  nativeInputPopoverBodyObserver = new MutationObserver(() => {
    bindNativeInputPopoverSource();
    scheduleStableNativeInputPopoverSync();
  });
  nativeInputPopoverBodyObserver.observe(document.body, { childList: true });
  bindNativeInputPopoverSource();
}

function syncStableNativeInputPopoverSelection(command: string) {
  for (const panel of [
    getNativeInputPopoverSource(),
    document.getElementById(STABLE_NATIVE_INPUT_POPOVER_ID),
  ]) {
    const items = Array.from(
      panel?.querySelectorAll<HTMLElement>("li[data-command]") ?? [],
    );
    for (const item of items) {
      item.classList.toggle(
        "ML__popover__current",
        item.dataset.command === command,
      );
    }
    items
      .find((item) => item.dataset.command === command)
      ?.scrollIntoView({ block: "nearest", inline: "nearest" });
  }
}

function syncStableNativeInputPopover() {
  bindNativeInputPopoverSource();
  const source = getNativeInputPopoverSource();
  if (source && nativeInputPopoverActiveField?.isConnected) {
    syncCasesEnvironmentSuggestionItem(source, nativeInputPopoverActiveField);
  }
  const sourceVisible = Boolean(
    source?.classList.contains("is-visible") &&
      source.querySelector("li[data-command]"),
  );
  const stable = ensureStableNativeInputPopover();

  if (!source || !sourceVisible) {
    if (
      nativeInputPopoverActiveField?.isConnected &&
      renderCasesEnvironmentSuggestion(stable, nativeInputPopoverActiveField)
    ) {
      window.clearTimeout(stableNativeInputPopoverHideTimer);
      return;
    }
    delete stable.dataset.visualtexEnvironmentSuggestion;
    window.clearTimeout(stableNativeInputPopoverHideTimer);
    stableNativeInputPopoverHideTimer = window.setTimeout(() => {
      const latest = getNativeInputPopoverSource();
      if (
        latest?.classList.contains("is-visible") &&
        latest.querySelector("li[data-command]")
      ) {
        scheduleStableNativeInputPopoverSync();
        return;
      }
      stable.classList.remove("is-visible");
      stable.setAttribute("aria-hidden", "true");
    }, 64);
    return;
  }

  window.clearTimeout(stableNativeInputPopoverHideTimer);
  delete stable.dataset.visualtexEnvironmentSuggestion;
  source.dataset.visualtexInputPopoverSource = "true";
  rankNativeSuggestionItems(source);
  const nextHtml = source.innerHTML;
  if (stable.innerHTML !== nextHtml) stable.innerHTML = nextHtml;
  rankNativeSuggestionItems(stable);
  stable.classList.toggle("top-tip", source.classList.contains("top-tip"));
  stable.classList.toggle(
    "bottom-tip",
    source.classList.contains("bottom-tip"),
  );
  stable.style.left = source.style.left;
  stable.style.top = source.style.top;
  stable.classList.add("is-visible");
  stable.setAttribute("aria-hidden", "false");
}

function scheduleStableNativeInputPopoverSync() {
  ensureNativeInputPopoverObservers();
  window.cancelAnimationFrame(stableNativeInputPopoverFrame);
  stableNativeInputPopoverFrame = window.requestAnimationFrame(
    syncStableNativeInputPopover,
  );
}

const BASE_FORMULA_FONT_SIZE = 54;
const MIN_FORMULA_FONT_SIZE = BASE_FORMULA_FONT_SIZE * 0.2;

const formulaFontSize = (zoom: number) =>
  Math.max(MIN_FORMULA_FONT_SIZE, BASE_FORMULA_FONT_SIZE * zoom);

function formulaRowHeightMetrics(
  latex: string,
  zoom: number,
  formulaRowVerticalInset: number,
) {
  const fontSize = formulaFontSize(zoom);
  const hasTallStructure = tallFormulaPattern.test(latex);
  const safeVerticalInset = Math.max(
    0,
    Math.min(24, Math.round(formulaRowVerticalInset)),
  );
  const verticalPadding = safeVerticalInset * 2;
  const baseContentHeight = hasTallStructure
    ? Math.max(20, fontSize * 1.34)
    : Math.max(22, fontSize * 1.12);
  const baseHeight = Math.max(
    hasTallStructure ? 36 : 30,
    baseContentHeight + verticalPadding,
  );
  return {
    fontSize,
    hasTallStructure,
    baseHeight,
    verticalPadding,
  };
}

function predictedFormulaRowHeight(
  latex: string,
  zoom: number,
  formulaRowVerticalInset: number,
  measurementHost?: HTMLElement | null,
) {
  const metrics = formulaRowHeightMetrics(
    latex,
    zoom,
    formulaRowVerticalInset,
  );
  let renderedHeight = latex.trim() ? 0 : metrics.fontSize * 1.2;

  if (measurementHost && latex.trim()) {
    const probe = document.createElement("span");
    probe.setAttribute("aria-hidden", "true");
    probe.style.position = "absolute";
    probe.style.left = "-100000px";
    probe.style.top = "0";
    probe.style.display = "inline-block";
    probe.style.width = "max-content";
    probe.style.maxWidth = "none";
    probe.style.whiteSpace = "nowrap";
    probe.style.visibility = "hidden";
    probe.style.pointerEvents = "none";
    probe.style.fontSize = metrics.fontSize + "px";
    probe.style.lineHeight = "normal";
    probe.innerHTML = convertVisualTexLatexToMarkup(latex, {
      defaultMode: "math",
    });
    measurementHost.append(probe);
    renderedHeight = probe.getBoundingClientRect().height;
    probe.remove();
  }

  return Math.ceil(
    Math.max(
      metrics.baseHeight,
      renderedHeight + metrics.verticalPadding,
    ),
  );
}

function captureSelection(field: MathfieldElement): MathSelectionSnapshot {
  return {
    ranges: field.selection.ranges.map(
      ([start, end]) => [start, end] as [number, number],
    ),
    direction: field.selection.direction ?? "none",
  };
}

function selectionHasContent(selection: MathSelectionSnapshot) {
  return selection.ranges.some(([start, end]) => start !== end);
}

function captureFieldSnapshot(field: MathfieldElement) {
  return {
    latex: normalizeChineseLatex(field.value),
    selection: captureSelection(field),
  };
}

type StructuredCompositionAnchor = {
  snapshot: ReturnType<typeof captureFieldSnapshot>;
  modelPlaceholderIndex: number;
  textualPlaceholderIndex: number;
};

function captureStructuredCompositionAnchor(
  field: MathfieldElement,
  snapshot: ReturnType<typeof captureFieldSnapshot>,
): StructuredCompositionAnchor | null {
  const activeRange = snapshot.selection.ranges.at(-1);
  if (!activeRange) return null;
  const normalizedRange: [number, number] = [
    Math.min(activeRange[0], activeRange[1]),
    Math.max(activeRange[0], activeRange[1]),
  ];
  if (
    normalizedRange[0] === normalizedRange[1] ||
    field.getValue(normalizedRange[0], normalizedRange[1], "latex").trim() !==
      "\\placeholder{}"
  ) {
    return null;
  }

  const modelPlaceholderIndex = latexPlaceholderRanges(field).findIndex(
    ([start, end]) =>
      start === normalizedRange[0] && end === normalizedRange[1],
  );
  if (modelPlaceholderIndex < 0) return null;
  const textualPlaceholderIndex =
    textualPlaceholderIndexForRange(snapshot.latex, normalizedRange) ??
    modelPlaceholderIndex;
  return {
    snapshot,
    modelPlaceholderIndex,
    textualPlaceholderIndex,
  };
}

function restoreStructuredCompositionPlaceholder(
  field: MathfieldElement,
  anchor: StructuredCompositionAnchor,
  committedText: string,
) {
  const replacement = normalizeChineseLatex(committedText);
  if (!replacement) return false;

  field.mode = "math";
  field.setValue(anchor.snapshot.latex, {
    mode: "math",
    format: "latex",
    insertionMode: "replaceAll",
    selectionMode: "after",
    silenceNotifications: true,
  });
  const targetRange =
    modelRangeForTextualPlaceholder(
      field,
      anchor.snapshot.latex,
      anchor.textualPlaceholderIndex,
    ) ?? latexPlaceholderRanges(field)[anchor.modelPlaceholderIndex] ?? null;
  if (!targetRange) {
    const restoredLatex = replaceTextualPlaceholder(
      anchor.snapshot.latex,
      anchor.textualPlaceholderIndex,
      replacement,
    );
    if (!restoredLatex) return false;
    field.setValue(restoredLatex, {
      mode: "math",
      format: "latex",
      insertionMode: "replaceAll",
      selectionMode: "after",
      silenceNotifications: true,
    });
    return true;
  }

  field.selection = {
    ranges: [targetRange],
    direction: "none",
  };
  const inserted = field.insert(replacement, {
    mode: "math",
    format: "latex",
    insertionMode: "replaceSelection",
    selectionMode: "after",
    focus: true,
    scrollIntoView: false,
  });
  if (inserted) return true;

  const restoredLatex = replaceTextualPlaceholder(
    anchor.snapshot.latex,
    anchor.textualPlaceholderIndex,
    replacement,
  );
  if (!restoredLatex) return false;
  field.setValue(restoredLatex, {
    mode: "math",
    format: "latex",
    insertionMode: "replaceAll",
    selectionMode: "after",
    silenceNotifications: true,
  });
  return true;
}

const visualTexPlaceholderStyleId = "visualtex-structural-placeholder-style";
const visualTexFormulaFontStyleId = "visualtex-formula-font-style";
const visualTexAlignmentMarkerStyleId = "visualtex-alignment-marker-style";
const visualTexFormulaUprightFontProperty =
  "--visualtex-formula-upright-font-family";
const visualTexFormulaItalicFontProperty =
  "--visualtex-formula-italic-font-family";
const visualTexFormulaChineseFontProperty =
  "--visualtex-formula-chinese-font-family";
const visualTexChineseGlyphClass = "visualtex-chinese-glyph";
const visualTexChineseGlyphPattern =
  /^[\p{Script=Han}㑇㑈㑉㑊㑋㑌㑍㑎㑏㑐㑑㑒㑓㑔㑕㑖㑗㑘㑙]+$/u;
const visualTexPlaceholderClass = "visualtex-structural-placeholder";
const visualTexAccentPlaceholderClass =
  "visualtex-accent-structural-placeholder";
const visualTexAccentPlaceholderLayoutClass =
  "visualtex-accent-placeholder-layout";
const visualTexCombiningAccentClass = "visualtex-combining-accent";
const visualTexCombiningAccentHostClass =
  "visualtex-combining-accent-host";
const visualTexCombiningAccentOverlayClass =
  "visualtex-combining-accent-overlay";
const visualTexCombiningAccentLeftProperty =
  "--visualtex-combining-accent-left";
const visualTexCombiningAccentTopProperty =
  "--visualtex-combining-accent-top";
const visualTexCombiningAccentHeightProperty =
  "--visualtex-combining-accent-height";
const visualTexCombiningAccentFontSizeProperty =
  "--visualtex-combining-accent-font-size";
const visualTexCombiningAccentColorProperty =
  "--visualtex-combining-accent-color";
const visualTexAccentPlaceholderShiftProperty =
  "--visualtex-accent-placeholder-shift";
const visualTexPlaceholderCaretClass =
  "visualtex-structural-placeholder-caret";
const visualTexPlaceholderSelectionClass =
  "has-visualtex-structural-placeholder-selection";
const visualTexRawLatexClass = "has-visualtex-raw-latex-command";
const visualTexPointerSelectingClass = "visualtex-pointer-selecting";
const visualTexSourcePreviewClass = "visualtex-source-preview-only";
const visualTexCaretRepaintClass = "visualtex-caret-repaint";
const visualTexPostOperatorCaretClass = "visualtex-post-operator-caret";
const visualTexPostOperatorCaretShiftProperty =
  "--visualtex-post-operator-caret-shift";
const visualTexCaretRepaintFrames = new WeakMap<MathfieldElement, number>();

function isMathLiveInterAtomGlue(node: Element | null): node is HTMLElement {
  if (!(node instanceof HTMLElement)) return false;
  if (node.dataset.atomId || node.className || node.textContent) return false;
  return (
    node.style.display === "inline-block" &&
    /^\d*\.?\d+(?:em|ex|px)$/.test(node.style.width)
  );
}

function syncPostOperatorCaretSpacing(field: MathfieldElement) {
  const caret = field.shadowRoot?.querySelector<HTMLElement>(".ML__caret");
  if (!caret) return;

  const previousAtom = caret.previousElementSibling;
  const leadingGlue = previousAtom?.previousElementSibling ?? null;
  const trailingGlue = caret.nextElementSibling;
  const shouldShift =
    previousAtom instanceof HTMLElement &&
    Boolean(previousAtom.dataset.atomId) &&
    isMathLiveInterAtomGlue(leadingGlue) &&
    isMathLiveInterAtomGlue(trailingGlue);

  if (!shouldShift) {
    if (caret.classList.contains(visualTexPostOperatorCaretClass)) {
      caret.classList.remove(visualTexPostOperatorCaretClass);
    }
    caret.style.removeProperty(visualTexPostOperatorCaretShiftProperty);
    return;
  }

  const shift = trailingGlue.getBoundingClientRect().width;
  if (!(shift > 0)) return;
  const nextShift = `${shift}px`;
  if (
    caret.style.getPropertyValue(visualTexPostOperatorCaretShiftProperty) !==
    nextShift
  ) {
    caret.style.setProperty(
      visualTexPostOperatorCaretShiftProperty,
      nextShift,
    );
  }
  if (!caret.classList.contains(visualTexPostOperatorCaretClass)) {
    caret.classList.add(visualTexPostOperatorCaretClass);
  }
}

function repaintMathLiveCaret(field: MathfieldElement) {
  const previousFrame = visualTexCaretRepaintFrames.get(field);
  if (previousFrame) window.cancelAnimationFrame(previousFrame);

  field.classList.remove(visualTexCaretRepaintClass);
  // Separate the previous WebKit compositing state from the class mutation.
  // This matters when the focused keyboard sink that dispatched Backspace has
  // just been removed from the document.
  field.shadowRoot
    ?.querySelector<HTMLElement>(
      ".ML__caret, .ML__text-caret, .ML__latex-caret",
    )
    ?.getBoundingClientRect();
  field.classList.add(visualTexCaretRepaintClass);

  const frame = window.requestAnimationFrame(() => {
    visualTexCaretRepaintFrames.delete(field);
    if (!field.isConnected) return;
    field.classList.remove(visualTexCaretRepaintClass);
  });
  visualTexCaretRepaintFrames.set(field, frame);
}
const visualTexPointerSelectingFields = new WeakSet<MathfieldElement>();
type VisualTexPlaceholderBranchState = {
  isAccent: boolean;
  restoreLatex: string | null;
  selection: ReturnType<typeof captureSelection> | null;
  restoreArmed: boolean;
};

const visualTexPlaceholderBranchAnchors = new WeakMap<
  MathfieldElement,
  Map<string, VisualTexPlaceholderBranchState>
>();
type VisualTexActiveAccentPlaceholder = {
  state: VisualTexPlaceholderBranchState;
  command: string;
  lastValueContainingCommand: string;
  restoreArmed: boolean;
};
const visualTexActiveAccentPlaceholders = new WeakMap<
  MathfieldElement,
  VisualTexActiveAccentPlaceholder
>();
const visualTexForcedPlaceholderRestores = new WeakMap<
  MathfieldElement,
  VisualTexPlaceholderBranchState
>();
const visualTexRestoringPlaceholderFields = new WeakSet<MathfieldElement>();
const visualTexPlaceholderRestoreFrames = new WeakMap<
  MathfieldElement,
  number
>();
const visualTexDeleteRestoreDeadlines = new WeakMap<
  MathfieldElement,
  number
>();

function clearVisualTexPlaceholderRestoreState(field: MathfieldElement) {
  const pendingFrame = visualTexPlaceholderRestoreFrames.get(field);
  if (pendingFrame) window.cancelAnimationFrame(pendingFrame);
  visualTexPlaceholderRestoreFrames.delete(field);
  visualTexDeleteRestoreDeadlines.delete(field);
  visualTexForcedPlaceholderRestores.delete(field);
  visualTexActiveAccentPlaceholders.delete(field);
  const anchors = visualTexPlaceholderBranchAnchors.get(field);
  if (anchors) {
    for (const state of anchors.values()) state.restoreArmed = false;
  }
}

function visualTexPlaceholderBranchAnchor(node: HTMLElement) {
  let branchChild = node;
  for (let depth = 0; depth < 6; depth += 1) {
    const row = branchChild.parentElement;
    if (!row) return null;

    const placeholderIndex = Array.from(row.children).indexOf(branchChild);
    for (let index = placeholderIndex - 1; index >= 0; index -= 1) {
      const sibling = row.children.item(index);
      if (!(sibling instanceof HTMLElement)) continue;
      const atomId = sibling.dataset.atomId;
      if (atomId) return atomId;
    }
    if (row.classList.contains("ML__vlist")) break;
    branchChild = row;
  }
  return null;
}

function rememberVisualTexPlaceholderBranch(
  field: MathfieldElement,
  node: HTMLElement,
  isAccent: boolean,
) {
  if (isAccent) {
    const placeholderRanges: [number, number][] = [];
    for (let end = 1; end <= field.lastOffset; end += 1) {
      if (field.getValue(end - 1, end, "latex").trim() === "\\placeholder{}") {
        placeholderRanges.push([end - 1, end]);
      }
    }
    placeholderRanges.sort(
      (first, second) =>
        Math.abs(first[1] - field.position) -
        Math.abs(second[1] - field.position),
    );
    const placeholderRange = placeholderRanges[0];
    const restoreLatex = Array.from(accentCommandTemplates.values()).find(
      (template) => field.value.includes(template),
    );
    if (restoreLatex && placeholderRange) {
      const state = {
        isAccent: true,
        restoreLatex,
        restoreArmed: false,
        selection: {
          ranges: [placeholderRange],
          direction: "none",
        },
      } satisfies VisualTexPlaceholderBranchState;
      const command = restoreLatex.match(/^\\[A-Za-z]+/)?.[0];
      if (command) {
        visualTexForcedPlaceholderRestores.delete(field);
        visualTexActiveAccentPlaceholders.set(field, {
          state,
          command,
          lastValueContainingCommand: field.value,
          restoreArmed: false,
        });
      }
    }
  }

  const anchorId = visualTexPlaceholderBranchAnchor(node);
  if (!anchorId) return;

  let anchors = visualTexPlaceholderBranchAnchors.get(field);
  if (!anchors) {
    anchors = new Map<string, VisualTexPlaceholderBranchState>();
    visualTexPlaceholderBranchAnchors.set(field, anchors);
  }
  const isSelected =
    node.classList.contains("ML__placeholder-selected") ||
    node.classList.contains("ML__selected") ||
    Boolean(node.closest(".ML__selected"));
  const selectedRange = field.selection.ranges[0];
  const hasSelectedPlaceholderRange = Boolean(
    isSelected &&
      field.selection.ranges.length === 1 &&
      selectedRange &&
      selectedRange[1] - selectedRange[0] === 1 &&
      field.getValue(selectedRange[0], selectedRange[1], "latex").trim() ===
        "\\placeholder{}",
  );
  const rememberedState = anchors.get(anchorId);
  const rememberedSelection = rememberedState?.selection ?? null;
  let restoreLatex = rememberedState?.restoreLatex ?? null;
  if (isAccent && hasSelectedPlaceholderRange && selectedRange) {
    restoreLatex =
      Array.from(accentCommandTemplates.values()).find((template) =>
        field.value.includes(template),
      ) ?? restoreLatex;
    const offsets = Array.from({ length: field.lastOffset + 1 }, (_, offset) =>
      offset,
    ).sort(
      (first, second) =>
        Math.abs(first - selectedRange[1]) -
        Math.abs(second - selectedRange[1]),
    );
    for (const offset of restoreLatex ? [] : offsets) {
      const containerLatex = field.getElementInfo(offset)?.latex?.trim() ?? "";
      if (
        isAccentContainerLatex(containerLatex) &&
        containerLatex.includes("\\placeholder{}")
      ) {
        restoreLatex = containerLatex;
        break;
      }
    }
  }
  const nextState = {
    isAccent,
    restoreLatex,
    restoreArmed: rememberedState?.restoreArmed ?? false,
    selection:
      rememberedSelection ??
      (hasSelectedPlaceholderRange ? captureSelection(field) : null),
  };
  anchors.set(anchorId, nextState);
  if (isAccent && nextState.restoreLatex && nextState.selection) {
    const command = nextState.restoreLatex.match(/^\\[A-Za-z]+/)?.[0];
    if (command) {
      visualTexForcedPlaceholderRestores.delete(field);
      visualTexActiveAccentPlaceholders.set(field, {
        state: nextState,
        command,
        lastValueContainingCommand: field.value,
        restoreArmed: false,
      });
    }
  }
}

function restoreDeletedVisualTexPlaceholder(field: MathfieldElement) {
  const deleteDeadline = visualTexDeleteRestoreDeadlines.get(field) ?? 0;
  if (performance.now() > deleteDeadline) {
    visualTexDeleteRestoreDeadlines.delete(field);
    return false;
  }
  const shadowRoot = field.shadowRoot;
  const anchors = visualTexPlaceholderBranchAnchors.get(field);
  const forcedRestore = visualTexForcedPlaceholderRestores.get(field);
  if (
    !shadowRoot ||
    (!anchors?.size && !forcedRestore) ||
    field.mode === "latex" ||
    !field.selectionIsCollapsed ||
    visualTexPointerSelectingFields.has(field) ||
    visualTexRestoringPlaceholderFields.has(field)
  ) {
    return false;
  }

  if (forcedRestore?.restoreLatex && forcedRestore.selection) {
    visualTexForcedPlaceholderRestores.delete(field);
    visualTexActiveAccentPlaceholders.delete(field);
    visualTexRestoringPlaceholderFields.add(field);
    try {
      const inserted = field.insert(forcedRestore.restoreLatex, {
        mode: "math",
        format: "latex",
        insertionMode: "replaceSelection",
        selectionMode: "after",
        focus: true,
        scrollIntoView: false,
      });
      if (!inserted) return false;
      field.selection = clampSelection(
        forcedRestore.selection,
        field.lastOffset,
      );
      markVisualTexStructuralPlaceholders(field);
      visualTexDeleteRestoreDeadlines.delete(field);
      return true;
    } finally {
      visualTexRestoringPlaceholderFields.delete(field);
    }
  }

  if (!anchors) return false;

  for (const [anchorId, branchState] of anchors) {
    if (!branchState.restoreArmed) continue;
    const anchor = shadowRoot.querySelector<HTMLElement>(
      `[data-atom-id="${CSS.escape(anchorId)}"]`,
    );
    const row = anchor?.parentElement;
    if (!anchor || !row) {
      anchors.delete(anchorId);
      continue;
    }

    const caret = Array.from(row.children).find(
      (child): child is HTMLElement =>
        child instanceof HTMLElement &&
        (child.classList.contains("ML__caret") ||
          child.classList.contains("ML__text-caret")),
    );
    if (!caret) continue;

    const hasContent = Array.from(row.children).some((child) => {
      if (!(child instanceof HTMLElement) || child === anchor || child === caret) {
        return false;
      }
      return !child.classList.contains(visualTexPlaceholderCaretClass);
    });
    if (hasContent) continue;

    const isAccentBranch =
      branchState.isAccent ||
      Boolean(
        row
          .closest<HTMLElement>(".ML__vlist")
          ?.querySelector(".ML__accent-body"),
      );
    visualTexRestoringPlaceholderFields.add(field);
    try {
      const insertionPosition = field.position;
      const inserted = field.insert(
        branchState.restoreLatex ?? "\\placeholder{}",
        {
        mode: "math",
        format: "latex",
        insertionMode: "replaceSelection",
        selectionMode: "after",
        focus: true,
        scrollIntoView: false,
        },
      );
      if (!inserted) return false;
      anchors.delete(anchorId);
      const placeholderStart = Math.min(
        field.lastOffset,
        insertionPosition + (isAccentBranch ? 1 : 0),
      );
      const placeholderEnd = Math.min(field.lastOffset, placeholderStart + 1);
      field.selection =
        !isAccentBranch && branchState.selection
          ? clampSelection(branchState.selection, field.lastOffset)
          : {
              ranges: [[placeholderStart, placeholderEnd]],
              direction: "none",
            };
      markVisualTexStructuralPlaceholders(field);
      visualTexDeleteRestoreDeadlines.delete(field);
      return true;
    } finally {
      visualTexRestoringPlaceholderFields.delete(field);
    }
  }
  return false;
}

function scheduleDeletedVisualTexPlaceholderRestore(field: MathfieldElement) {
  const hasArmedBranch = Array.from(
    visualTexPlaceholderBranchAnchors.get(field)?.values() ?? [],
  ).some((state) => state.restoreArmed);
  if (
    !hasArmedBranch &&
    !visualTexForcedPlaceholderRestores.has(field)
  ) {
    return;
  }
  if (visualTexPlaceholderRestoreFrames.has(field)) return;
  const frame = window.requestAnimationFrame(() => {
    visualTexPlaceholderRestoreFrames.delete(field);
    if (!field.isConnected) return;
    restoreDeletedVisualTexPlaceholder(field);
  });
  visualTexPlaceholderRestoreFrames.set(field, frame);
}

function captureSelectedAccentPlaceholderState(field: MathfieldElement) {
  const selectedRange = field.selection.ranges[0];
  if (
    field.selection.ranges.length !== 1 ||
    !selectedRange ||
    selectedRange[1] - selectedRange[0] !== 1 ||
    field.getValue(selectedRange[0], selectedRange[1], "latex").trim() !==
      "\\placeholder{}"
  ) {
    return null;
  }
  const restoreLatex = Array.from(accentCommandTemplates.values()).find(
    (template) => field.value.includes(template),
  );
  if (!restoreLatex) return null;
  return {
    isAccent: true,
    restoreLatex,
    restoreArmed: false,
    selection: captureSelection(field),
  } satisfies VisualTexPlaceholderBranchState;
}

function activateVisualTexAccentPlaceholder(
  field: MathfieldElement,
  state: VisualTexPlaceholderBranchState,
) {
  const command = state.restoreLatex?.match(/^\\[A-Za-z]+/)?.[0];
  if (!command) return;
  visualTexActiveAccentPlaceholders.set(field, {
    state,
    command,
    lastValueContainingCommand: field.value,
    restoreArmed: false,
  });
  visualTexForcedPlaceholderRestores.delete(field);
}

function observeVisualTexActiveAccentPlaceholder(field: MathfieldElement) {
  const active = visualTexActiveAccentPlaceholders.get(field);
  if (!active || visualTexForcedPlaceholderRestores.has(field)) return;
  const commandPrefix = `${active.command}{`;
  if (field.value.includes(commandPrefix)) {
    active.lastValueContainingCommand = field.value;
    return;
  }
  if (!active.restoreArmed) {
    visualTexActiveAccentPlaceholders.delete(field);
    return;
  }
  if (
    active.lastValueContainingCommand.includes(commandPrefix)
  ) {
    visualTexForcedPlaceholderRestores.set(field, active.state);
  }
}

function visualTexHasSingleDeletionAtom(field: MathfieldElement) {
  if (!field.selectionIsCollapsed || field.selection.ranges.length !== 1) {
    return false;
  }
  const selectedRange = field.selection.ranges[0];
  if (
    selectedRange &&
    selectedRange[1] - selectedRange[0] === 1 &&
    field.getValue(selectedRange[0], selectedRange[1], "latex").trim() ===
      "\\placeholder{}"
  ) {
    return false;
  }
  for (let distance = 1; distance <= 2; distance += 1) {
    const end = field.position - distance + 1;
    const start = end - 1;
    if (start < 0 || end > field.lastOffset) continue;
    const latex = field.getValue(start, end, "latex").trim();
    if (latex && latex !== "\\placeholder{}") return true;
  }
  return false;
}

function armVisualTexPlaceholderRestore(field: MathfieldElement) {
  const shouldArm = visualTexHasSingleDeletionAtom(field);
  if (shouldArm) {
    visualTexDeleteRestoreDeadlines.set(field, performance.now() + 500);
  } else {
    visualTexDeleteRestoreDeadlines.delete(field);
  }
  const anchors = visualTexPlaceholderBranchAnchors.get(field);
  if (anchors) {
    for (const state of anchors.values()) state.restoreArmed = shouldArm;
  }
  const active = visualTexActiveAccentPlaceholders.get(field);
  if (active) {
    const commandPrefix = `${active.command}{`;
    active.restoreArmed =
      shouldArm &&
      active.lastValueContainingCommand.includes(commandPrefix) &&
      !active.lastValueContainingCommand.includes("\\placeholder{}");
  }
}

function settleVisualTexAccentPlaceholderDelete(field: MathfieldElement) {
  const active = visualTexActiveAccentPlaceholders.get(field);
  if (active && field.value.includes(`${active.command}{`)) {
    active.restoreArmed = false;
  }
}

function settleVisualTexPlaceholderDelete(field: MathfieldElement) {
  const anchors = visualTexPlaceholderBranchAnchors.get(field);
  if (!anchors) return;
  for (const state of anchors.values()) state.restoreArmed = false;
}

function accentLayoutForPlaceholder(node: HTMLElement) {
  let layout = node.closest<HTMLElement>(".ML__vlist");
  while (layout) {
    if (
      layout.querySelector(
        ":scope > .ML__center .ML__accent-body, :scope > .ML__center .ML__stretchy",
      )
    ) {
      return layout;
    }
    layout = layout.parentElement?.closest<HTMLElement>(".ML__vlist") ?? null;
  }
  return null;
}

function setStylePropertyIfChanged(
  node: HTMLElement,
  property: string,
  value: string,
) {
  if (node.style.getPropertyValue(property) === value) return;
  node.style.setProperty(property, value);
}

function combiningAccentKind(node: HTMLElement) {
  const text = node.textContent ?? "";
  if (text.includes("\u20d7")) return "vector";
  if (text.includes("\u20db")) return "triple-dot";
  if (text.includes("\u20dc")) return "quadruple-dot";
  return null;
}

function syncVisualTexCombiningAccent(node: HTMLElement) {
  const kind = combiningAccentKind(node);
  const layout = node.closest<HTMLElement>(".ML__vlist");
  const host = node.closest<HTMLElement>(".ML__center");
  const base = Array.from(layout?.children ?? []).find(
    (candidate): candidate is HTMLElement =>
      candidate instanceof HTMLElement &&
      !candidate.classList.contains("ML__center"),
  );
  if (!kind || !layout || !host || !base) return;

  if (!node.classList.contains(visualTexCombiningAccentClass)) {
    node.classList.add(visualTexCombiningAccentClass);
  }
  if (!host.classList.contains(visualTexCombiningAccentHostClass)) {
    host.classList.add(visualTexCombiningAccentHostClass);
  }

  let overlay = host.querySelector<HTMLElement>(
    `:scope > .${visualTexCombiningAccentOverlayClass}`,
  );
  if (!overlay) {
    overlay = document.createElement("span");
    overlay.className = visualTexCombiningAccentOverlayClass;
    overlay.setAttribute("aria-hidden", "true");
    host.append(overlay);
  }
  if (overlay.dataset.kind !== kind) {
    overlay.dataset.kind = kind;
    overlay.replaceChildren();
    if (kind !== "vector") {
      const dotCount = kind === "triple-dot" ? 3 : 4;
      for (let index = 0; index < dotCount; index += 1) {
        const dot = document.createElement("span");
        dot.className = "visualtex-combining-accent-dot";
        overlay.append(dot);
      }
    }
  }

  const nodeStyle = getComputedStyle(node);
  const nodeBounds = node.getBoundingClientRect();
  const hostBounds = host.getBoundingClientRect();
  const baseBounds = base.getBoundingClientRect();
  const overlayLeft =
    baseBounds.left + baseBounds.width / 2 - hostBounds.left;
  const overlayTop = nodeBounds.top - hostBounds.top;
  setStylePropertyIfChanged(
    overlay,
    visualTexCombiningAccentLeftProperty,
    `${overlayLeft}px`,
  );
  setStylePropertyIfChanged(
    overlay,
    visualTexCombiningAccentTopProperty,
    `${overlayTop}px`,
  );
  setStylePropertyIfChanged(
    overlay,
    visualTexCombiningAccentHeightProperty,
    `${nodeBounds.height}px`,
  );
  setStylePropertyIfChanged(
    overlay,
    visualTexCombiningAccentFontSizeProperty,
    nodeStyle.fontSize,
  );
  const computedColor = [
    getComputedStyle(base).color,
    getComputedStyle(layout).color,
    getComputedStyle(host).color,
  ].find((color) => color !== "rgba(0, 0, 0, 0)");
  if (computedColor) {
    setStylePropertyIfChanged(
      overlay,
      visualTexCombiningAccentColorProperty,
      computedColor,
    );
  }
}

function alignVisualTexAccentPlaceholder(
  node: HTMLElement,
  layout: HTMLElement,
) {
  const accentCenter = layout.querySelector<HTMLElement>(
    ":scope > .ML__center",
  );
  const accentBody = accentCenter?.querySelector<HTMLElement>(
    ".ML__accent-body, .ML__stretchy",
  );
  if (!accentCenter || !accentBody) return;

  accentCenter.style.removeProperty(visualTexAccentPlaceholderShiftProperty);
  if (accentBody.classList.contains("ML__accent-combining-char")) return;

  const placeholderBounds = node.getBoundingClientRect();
  const accentBounds = accentBody.getBoundingClientRect();
  const accentAnchor = accentBounds.left + accentBounds.width / 2;
  const shift =
    placeholderBounds.left + placeholderBounds.width / 2 - accentAnchor;
  accentCenter.style.setProperty(
    visualTexAccentPlaceholderShiftProperty,
    `${shift}px`,
  );
}

function markVisualTexStructuralPlaceholders(field: MathfieldElement) {
  const shadowRoot = field.shadowRoot;
  if (!shadowRoot) return;

  shadowRoot
    .querySelectorAll<HTMLElement>(".ML__accent-combining-char")
    .forEach(syncVisualTexCombiningAccent);
  shadowRoot
    .querySelectorAll<HTMLElement>(`.${visualTexCombiningAccentHostClass}`)
    .forEach((host) => {
      if (host.querySelector(".ML__accent-combining-char")) return;
      host
        .querySelector(`:scope > .${visualTexCombiningAccentOverlayClass}`)
        ?.remove();
      host.classList.remove(visualTexCombiningAccentHostClass);
    });

  const pointerSelecting = visualTexPointerSelectingFields.has(field);
  const placeholderSymbol = field.placeholderSymbol || "▢";
  const selectionRanges = field.selection.ranges;
  const [selectionStart, selectionEnd] = selectionRanges[0] ?? [-1, -1];
  const isFocusedPlaceholderSelection =
    !pointerSelecting &&
    selectionRanges.length === 1 &&
    Math.abs(selectionEnd - selectionStart) <= 1 &&
    !shadowRoot.querySelector(".ML__raw-latex");
  let selectedPlaceholder = false;

  shadowRoot
    .querySelectorAll<HTMLElement>(".ML__cmr, .ML__placeholder")
    .forEach((node) => {
      const visibleText = Array.from(node.childNodes)
        .filter(
          (child) =>
            !(child instanceof HTMLElement) ||
            !child.classList.contains(visualTexPlaceholderCaretClass),
        )
        .map((child) => child.textContent ?? "")
        .join("")
        .trim();
      const isPlaceholder =
        node.classList.contains(visualTexPlaceholderClass) ||
        node.classList.contains("ML__placeholder") ||
        visibleText === placeholderSymbol;
      const accentLayout = accentLayoutForPlaceholder(node);
      const isAccentPlaceholder = isPlaceholder && Boolean(accentLayout);
      if (isPlaceholder && !pointerSelecting) {
        rememberVisualTexPlaceholderBranch(field, node, isAccentPlaceholder);
      }
      node.classList.toggle(visualTexPlaceholderClass, isPlaceholder);
      node.classList.toggle(
        visualTexAccentPlaceholderClass,
        isAccentPlaceholder,
      );
      accentLayout?.classList.toggle(
        visualTexAccentPlaceholderLayoutClass,
        isAccentPlaceholder,
      );
      if (isAccentPlaceholder && accentLayout) {
        alignVisualTexAccentPlaceholder(node, accentLayout);
      }

      if (pointerSelecting) return;

      const isSelected = Boolean(
        isFocusedPlaceholderSelection &&
          isPlaceholder &&
          (node.classList.contains("ML__placeholder-selected") ||
            node.classList.contains("ML__selected") ||
            node.closest(".ML__selected")),
      );
      let caret = node.querySelector<HTMLElement>(
        `:scope > .${visualTexPlaceholderCaretClass}`,
      );
      if (isSelected) {
        selectedPlaceholder = true;
        if (!caret) {
          caret = document.createElement("span");
          caret.className = visualTexPlaceholderCaretClass;
          caret.setAttribute("aria-hidden", "true");
          node.append(caret);
        }
      } else {
        caret?.remove();
      }
    });

  if (pointerSelecting) return;

  const container = shadowRoot.querySelector<HTMLElement>(".ML__container");
  container?.classList.toggle(
    visualTexPlaceholderSelectionClass,
    selectedPlaceholder,
  );
  container?.classList.toggle(
    visualTexRawLatexClass,
    Boolean(shadowRoot.querySelector(".ML__raw-latex")),
  );
}

function markVisualTexChineseGlyphs(field: MathfieldElement) {
  const shadowRoot = field.shadowRoot;
  if (!shadowRoot) return;
  shadowRoot
    .querySelectorAll<HTMLElement>(
      ".ML__cmr, .ML__mathbf, .ML__mathit, .ML__mathbfit, .ML__text",
    )
    .forEach((node) => {
      const text = (node.textContent ?? "").trim();
      node.classList.toggle(
        visualTexChineseGlyphClass,
        Boolean(text) && visualTexChineseGlyphPattern.test(text),
      );
    });
}

function installVisualTexFormulaFontStyle(field: MathfieldElement) {
  const shadowRoot = field.shadowRoot;
  if (!shadowRoot) return;
  if (shadowRoot.getElementById(visualTexFormulaFontStyleId)) return;

  const style = document.createElement("style");
  style.id = visualTexFormulaFontStyleId;
  style.textContent = `
    .ML__cmr:not(.ML__it) {
      font-family: var(${visualTexFormulaUprightFontProperty}, KaTeX_Main, serif) !important;
      font-style: normal !important;
    }

    .ML__cmr:not(.ML__bold):not(.ML__it) {
      font-weight: 400 !important;
    }

    .ML__cmr.ML__bold:not(.ML__it),
    .ML__mathbf:not(.lcGreek) {
      font-family: var(${visualTexFormulaUprightFontProperty}, KaTeX_Main, serif) !important;
      font-style: normal !important;
      font-weight: 700 !important;
    }

    .ML__cmr.ML__it,
    .ML__mathit {
      font-family: var(${visualTexFormulaItalicFontProperty}, KaTeX_Math, KaTeX_Main, serif) !important;
      font-style: italic !important;
    }

    .ML__cmr.ML__it:not(.ML__bold),
    .ML__mathit {
      font-weight: 400 !important;
    }

    .ML__cmr.ML__bold.ML__it,
    .lcGreek.ML__mathbf,
    .ML__mathbfit {
      font-family: var(${visualTexFormulaItalicFontProperty}, KaTeX_Math, KaTeX_Main, serif) !important;
      font-style: italic !important;
      font-weight: 700 !important;
    }

    .ML__text,
    .${visualTexChineseGlyphClass} {
      font-family: var(${visualTexFormulaChineseFontProperty}, var(--_text-font-family)) !important;
    }
  `;
  shadowRoot.append(style);
}

function applyVisualTexFormulaFonts(
  field: MathfieldElement,
  letterFont: FormulaLetterFont,
  chineseFont: FormulaChineseFont,
) {
  installVisualTexFormulaFontStyle(field);
  markVisualTexChineseGlyphs(field);
  const letterFamilies = formulaLetterFontFamilies(letterFont);
  field.style.setProperty(
    visualTexFormulaUprightFontProperty,
    letterFamilies.upright,
  );
  field.style.setProperty(
    visualTexFormulaItalicFontProperty,
    letterFamilies.italic,
  );
  field.style.setProperty(
    visualTexFormulaChineseFontProperty,
    formulaChineseFontFamily(chineseFont),
  );
}

function installVisualTexStructuralPlaceholderStyle(field: MathfieldElement) {
  const shadowRoot = field.shadowRoot;
  if (!shadowRoot) return;
  if (!shadowRoot.getElementById(visualTexPlaceholderStyleId)) {
    const style = document.createElement("style");
    style.id = visualTexPlaceholderStyleId;
    style.textContent = `
      .ML__placeholder,
      .${visualTexPlaceholderClass} {
        position: relative !important;
        display: inline-block !important;
        box-sizing: border-box !important;
        width: 0.40em !important;
        min-width: 0.32em !important;
        height: 0.74em !important;
        margin: 0 0.065em !important;
        padding: 0 !important;
        overflow: hidden !important;
        border: 0 !important;
        border-radius: 0.075em !important;
        background: var(--formula-placeholder) !important;
        color: transparent !important;
        opacity: 1 !important;
        text-indent: -999px !important;
        vertical-align: -0.075em !important;
        box-shadow: none !important;
      }

      .ML__mfrac .ML__placeholder,
      .ML__mfrac .${visualTexPlaceholderClass} {
        width: 0.38em !important;
        min-width: 0.31em !important;
        height: 0.70em !important;
        border-radius: 0.07em !important;
      }

      .ML__msubsup .ML__placeholder,
      .ML__msubsup .${visualTexPlaceholderClass},
      .ML__op-group .ML__placeholder,
      .ML__op-group .${visualTexPlaceholderClass} {
        width: 0.35em !important;
        min-width: 0.28em !important;
        height: 0.66em !important;
        border-radius: 0.065em !important;
      }

      .ML__sqrt .ML__placeholder,
      .ML__sqrt .${visualTexPlaceholderClass} {
        width: 0.40em !important;
        min-width: 0.32em !important;
        height: 0.71em !important;
      }

      .ML__mtable .ML__placeholder,
      .ML__mtable .${visualTexPlaceholderClass} {
        width: 0.42em !important;
        min-width: 0.34em !important;
        height: 0.73em !important;
      }

      .${visualTexAccentPlaceholderClass} {
        width: auto !important;
        min-width: 0 !important;
        margin: 0 !important;
        overflow: hidden !important;
        background: transparent !important;
        text-indent: 0 !important;
      }

      .${visualTexAccentPlaceholderClass}::before {
        content: "" !important;
        position: absolute !important;
        inset: 0 auto 0 50% !important;
        display: block !important;
        width: 0.40em !important;
        border-radius: 0.075em !important;
        background: var(--formula-placeholder) !important;
        transform: translateX(-50%) !important;
        pointer-events: none !important;
      }

      .${visualTexAccentPlaceholderLayoutClass}
        > .ML__center {
        transform: translateX(
          var(${visualTexAccentPlaceholderShiftProperty}, 0px)
        ) !important;
      }

      .${visualTexAccentPlaceholderLayoutClass}
        > .ML__center .ML__accent-combining-char {
        left: 0 !important;
      }

      .${visualTexCombiningAccentClass} {
        left: 0 !important;
        color: transparent !important;
        overflow: visible !important;
      }

      .${visualTexCombiningAccentHostClass} {
        overflow: visible !important;
      }

      .${visualTexCombiningAccentOverlayClass} {
        position: absolute !important;
        z-index: 2 !important;
        left: var(${visualTexCombiningAccentLeftProperty}, 0px) !important;
        top: var(${visualTexCombiningAccentTopProperty}, 0px) !important;
        display: inline-flex !important;
        align-items: center !important;
        justify-content: center !important;
        gap: 0.07em !important;
        width: max-content !important;
        height: var(
          ${visualTexCombiningAccentHeightProperty},
          1em
        ) !important;
        margin: 0 !important;
        padding: 0 !important;
        overflow: visible !important;
        color: var(
          ${visualTexCombiningAccentColorProperty},
          var(--_caret-color)
        ) !important;
        font-family: KaTeX_Main !important;
        font-size: var(
          ${visualTexCombiningAccentFontSizeProperty},
          1em
        ) !important;
        font-style: normal !important;
        font-weight: 400 !important;
        line-height: 1 !important;
        text-indent: 0 !important;
        transform: translateX(-50%) !important;
        pointer-events: none !important;
      }

      .${visualTexCombiningAccentOverlayClass}[data-kind="vector"] {
        width: 0.42em !important;
      }

      .${visualTexCombiningAccentOverlayClass}[data-kind="vector"]::before {
        content: "" !important;
        position: absolute !important;
        top: 50% !important;
        right: 0.03em !important;
        left: 0 !important;
        border-top: max(1px, 0.035em) solid currentColor !important;
        transform: translateY(-50%) !important;
      }

      .${visualTexCombiningAccentOverlayClass}[data-kind="vector"]::after {
        content: "" !important;
        position: absolute !important;
        top: 50% !important;
        right: 0 !important;
        width: 0.09em !important;
        height: 0.09em !important;
        border-top: max(1px, 0.035em) solid currentColor !important;
        border-right: max(1px, 0.035em) solid currentColor !important;
        transform: translateY(-50%) rotate(45deg) !important;
        transform-origin: center !important;
      }

      .visualtex-combining-accent-dot {
        display: block !important;
        flex: 0 0 auto !important;
        width: 0.09em !important;
        height: 0.09em !important;
        border: 0 !important;
        border-radius: 50% !important;
        background: currentColor !important;
      }

      .ML__contains-highlight,
      .ML__highlight {
        border-color: transparent !important;
        outline: 0 !important;
        background: transparent !important;
        background-color: transparent !important;
        box-shadow: none !important;
      }

      .ML__container.${visualTexPlaceholderSelectionClass} .ML__selected {
        border-color: transparent !important;
        outline: 0 !important;
        background: transparent !important;
        background-color: transparent !important;
        box-shadow: none !important;
      }

      .ML__container.${visualTexPlaceholderSelectionClass} .ML__placeholder-selected,
      .ML__container.${visualTexPlaceholderSelectionClass} .ML__selected .ML__placeholder,
      .ML__container.${visualTexPlaceholderSelectionClass} .${visualTexPlaceholderClass}.ML__selected,
      .ML__container.${visualTexPlaceholderSelectionClass} .ML__selected .${visualTexPlaceholderClass} {
        overflow: visible !important;
        /* Visible overflow changes an inline-block's baseline to its last text
           baseline. Offset that font-metric difference so selection stays put. */
        vertical-align: -0.2425em !important;
        border: 0 !important;
        background: var(--formula-placeholder-selected) !important;
        color: transparent !important;
        opacity: 1 !important;
        box-shadow: none !important;
      }

      .ML__container.${visualTexPlaceholderSelectionClass}
        .${visualTexAccentPlaceholderClass},
      .ML__container.${visualTexPlaceholderSelectionClass}
        .ML__selected .${visualTexAccentPlaceholderClass} {
        background: transparent !important;
      }

      .ML__container.${visualTexPlaceholderSelectionClass}
        .${visualTexAccentPlaceholderClass}::before,
      .ML__container.${visualTexPlaceholderSelectionClass}
        .ML__selected .${visualTexAccentPlaceholderClass}::before {
        background: var(--formula-placeholder-selected) !important;
      }

      .ML__container.${visualTexPlaceholderSelectionClass} .ML__caret,
      .ML__container.${visualTexPlaceholderSelectionClass} .ML__text-caret,
      .ML__container.${visualTexPlaceholderSelectionClass} .ML__latex-caret {
        opacity: 0 !important;
        animation: none !important;
      }

      :host(.${visualTexCaretRepaintClass})
        .ML__focused .ML__caret::after,
      :host(.${visualTexCaretRepaintClass})
        .ML__focused .ML__text-caret::after,
      :host(.${visualTexCaretRepaintClass})
        .ML__focused .ML__latex-caret::after {
        visibility: visible !important;
        opacity: 1 !important;
        animation: none !important;
        transform: translateZ(0);
      }

      .ML__caret.${visualTexPostOperatorCaretClass} {
        transform: translateX(
          var(${visualTexPostOperatorCaretShiftProperty}, 0px)
        ) !important;
      }

      .${visualTexPlaceholderCaretClass} {
        position: absolute !important;
        z-index: 2 !important;
        left: calc(-1 * max(1px, 0.045em)) !important;
        top: 0.04em !important;
        display: block !important;
        width: 0 !important;
        height: 0.66em !important;
        margin: 0 !important;
        padding: 0 !important;
        border: 0 !important;
        border-left: max(1px, 0.045em) solid var(--_caret-color) !important;
        border-radius: 1px !important;
        background: transparent !important;
        opacity: 1;
        text-indent: 0 !important;
        animation: visualtex-placeholder-caret-blink 1.05s step-end infinite !important;
        pointer-events: none !important;
      }

      .${visualTexAccentPlaceholderClass}
        > .${visualTexPlaceholderCaretClass} {
        left: calc(
          50% - 0.20em - max(1px, 0.045em)
        ) !important;
      }

      @keyframes visualtex-placeholder-caret-blink {
        0%, 48% { opacity: 1; }
        49%, 100% { opacity: 0; }
      }

      .ML__container.${visualTexPlaceholderSelectionClass} .ML__selection {
        display: none !important;
      }

      :host(.${visualTexPointerSelectingClass})
        .ML__container.${visualTexPlaceholderSelectionClass}
        .ML__selection {
        display: block !important;
        background: var(--_selection-background-color) !important;
      }

      :host(.${visualTexPointerSelectingClass})
        .${visualTexPlaceholderCaretClass} {
        opacity: 0 !important;
        animation: none !important;
      }

      .ML__container.${visualTexRawLatexClass} .ML__latex,
      .ML__container.${visualTexRawLatexClass} .ML__raw-latex,
      .ML__container.${visualTexRawLatexClass} .ML__selected,
      .ML__container.${visualTexRawLatexClass} .ML__contains-highlight,
      .ML__container.${visualTexRawLatexClass} .ML__selection {
        background: transparent !important;
        background-color: transparent !important;
        box-shadow: none !important;
        outline: 0 !important;
      }

      .ML__container.${visualTexRawLatexClass} .ML__selection {
        display: none !important;
      }

      :host(.has-visualtex-multi-line-selection)
        .ML__container .ML__selection {
        display: block !important;
        background: var(--_selection-background-color) !important;
      }

      :host(.${visualTexSourcePreviewClass}) .ML__selection {
        display: none !important;
      }

      :host(.${visualTexSourcePreviewClass}) .ML__selected,
      :host(.${visualTexSourcePreviewClass}) .ML__contains-highlight,
      :host(.${visualTexSourcePreviewClass}) .ML__highlight,
      :host(.${visualTexSourcePreviewClass}) .ML__placeholder-selected,
      :host(.${visualTexSourcePreviewClass}) .ML__selected .ML__placeholder,
      :host(.${visualTexSourcePreviewClass})
        .ML__selected .${visualTexPlaceholderClass} {
        border-color: transparent !important;
        outline: 0 !important;
        background: transparent !important;
        background-color: transparent !important;
        box-shadow: none !important;
      }

      :host(.${visualTexSourcePreviewClass}) .ML__caret,
      :host(.${visualTexSourcePreviewClass}) .ML__text-caret,
      :host(.${visualTexSourcePreviewClass}) .ML__latex-caret,
      :host(.${visualTexSourcePreviewClass})
        .${visualTexPlaceholderCaretClass} {
        display: none !important;
        opacity: 0 !important;
        animation: none !important;
      }
    `;
    shadowRoot.append(style);
  }
  markVisualTexStructuralPlaceholders(field);
}

const visualTexPointerPlaceholderStyleId =
  "visualtex-pointer-placeholder-style";
const visualTexPointerPlaceholderStyles = new WeakMap<
  MathfieldElement,
  string
>();

function installPointerPlaceholderSnapshotStyle(field: MathfieldElement) {
  const shadowRoot = field.shadowRoot;
  if (!shadowRoot) return;
  shadowRoot.getElementById(visualTexPointerPlaceholderStyleId)?.remove();

  const placeholderSymbol = field.placeholderSymbol || "▢";
  const rules = Array.from(
    shadowRoot.querySelectorAll<HTMLElement>(
      ".ML__cmr, .ML__placeholder",
    ),
  ).flatMap((node) => {
    const visibleText = node.textContent?.trim() ?? "";
    if (
      !node.classList.contains(visualTexPlaceholderClass) &&
      !node.classList.contains("ML__placeholder") &&
      visibleText !== placeholderSymbol
    ) {
      return [];
    }
    const isAccentPlaceholder =
      node.classList.contains(visualTexAccentPlaceholderClass) ||
      Boolean(accentLayoutForPlaceholder(node));
    const atomId = node.dataset.atomId;
    const accentHostAtomId = isAccentPlaceholder
      ? node.closest<HTMLElement>("[data-atom-id]")?.dataset.atomId
      : null;
    if (!atomId && !accentHostAtomId) return [];
    const style = getComputedStyle(node);
    const accentLayout = isAccentPlaceholder
      ? accentLayoutForPlaceholder(node)
      : null;
    const accentCenter = accentLayout?.querySelector<HTMLElement>(
      ":scope > .ML__center",
    );
    const accentShift =
      accentCenter?.style.getPropertyValue(
        visualTexAccentPlaceholderShiftProperty,
      ) || "0px";
    const accentHostSelector = accentHostAtomId
      ? `[data-atom-id="${CSS.escape(accentHostAtomId)}"] ` +
        `.ML__vlist:has(> .ML__center .ML__accent-body)`
      : "";
    const selector = atomId
      ? `[data-atom-id="${CSS.escape(atomId)}"]`
      : `${accentHostSelector} > span:not(.ML__center) .ML__cmr`;
    const background = isAccentPlaceholder
      ? "transparent"
      : "var(--formula-placeholder)";
    const textIndent = isAccentPlaceholder ? "0" : "-999px";
    const accentBoxRule = isAccentPlaceholder
      ? `
      :host(.${visualTexPointerSelectingClass}) ${selector}::before {
        content: "" !important;
        position: absolute !important;
        inset: 0 auto 0 50% !important;
        display: block !important;
        width: 0.40em !important;
        border-radius: 0.075em !important;
        background: var(--formula-placeholder) !important;
        transform: translateX(-50%) !important;
        pointer-events: none !important;
      }

      :host(.${visualTexPointerSelectingClass})
        ${accentHostSelector} > .ML__center {
        transform: translateX(${accentShift}) !important;
      }

      :host(.${visualTexPointerSelectingClass})
        ${accentHostSelector}
        > .ML__center .ML__accent-combining-char {
        left: 0 !important;
      }
      `
      : "";
    return [
      `
      :host(.${visualTexPointerSelectingClass}) ${selector} {
        position: relative !important;
        display: inline-block !important;
        box-sizing: border-box !important;
        width: ${style.width} !important;
        min-width: ${style.minWidth} !important;
        height: ${style.height} !important;
        margin: ${style.margin} !important;
        padding: 0 !important;
        overflow: ${style.overflow} !important;
        border: 0 !important;
        border-radius: ${style.borderRadius} !important;
        background: ${background} !important;
        color: transparent !important;
        opacity: 1 !important;
        text-indent: ${textIndent} !important;
        /* Preserve the selected placeholder's measured baseline while
          MathLive rebuilds its DOM during the pointer gesture. */
        vertical-align: ${style.verticalAlign} !important;
        box-shadow: none !important;
      }
      ${accentBoxRule}
      `,
    ];
  });
  if (!rules.length) return;

  const style = document.createElement("style");
  style.id = visualTexPointerPlaceholderStyleId;
  style.textContent = rules.join("\n");
  visualTexPointerPlaceholderStyles.set(field, style.textContent);
  shadowRoot.append(style);
}

function restorePointerPlaceholderSnapshotStyle(field: MathfieldElement) {
  const shadowRoot = field.shadowRoot;
  const cssText = visualTexPointerPlaceholderStyles.get(field);
  if (
    !shadowRoot ||
    !cssText ||
    shadowRoot.getElementById(visualTexPointerPlaceholderStyleId)
  ) {
    return;
  }
  const style = document.createElement("style");
  style.id = visualTexPointerPlaceholderStyleId;
  style.textContent = cssText;
  shadowRoot.append(style);
}

function removePointerPlaceholderSnapshotStyle(field: MathfieldElement) {
  visualTexPointerPlaceholderStyles.delete(field);
  field.shadowRoot
    ?.getElementById(visualTexPointerPlaceholderStyleId)
    ?.remove();
}

function normalizeCompletedDifferentialDisplay(field: MathfieldElement) {
  if (field.mode === "latex" || !field.selectionIsCollapsed) return false;

  const originalValue = field.value;
  const portableValue = normalizeMathLiveCanonicalUprightCommands(originalValue);
  // Contextual upright typography is a semantic normalization pass, not an
  // inline-shortcut preference. It must remain active even when the user turns
  // off "common math input auto-convert".
  const contextualValue = normalizeContextualUprightSymbols(portableValue);
  if (contextualValue === originalValue) return false;

  const distanceFromEnd = Math.max(0, field.lastOffset - field.position);
  field.setValue(contextualValue, {
    mode: "math",
    format: "latex",
    insertionMode: "replaceAll",
    selectionMode: "after",
    silenceNotifications: true,
  });
  const nextPosition = Math.max(0, field.lastOffset - distanceFromEnd);
  field.selection = {
    ranges: [[nextPosition, nextPosition]],
    direction: "none",
  };
  field.position = nextPosition;
  return true;
}

type PhysicalBackslashInputKind = "ideographic-comma" | "latin-backslash";

function normalizePhysicalBackslashInput(
  beforeValue: string,
  afterValue: string,
  kind: PhysicalBackslashInputKind,
) {
  let prefixLength = 0;
  while (
    prefixLength < beforeValue.length &&
    prefixLength < afterValue.length &&
    beforeValue[prefixLength] === afterValue[prefixLength]
  ) {
    prefixLength += 1;
  }

  let suffixLength = 0;
  while (
    suffixLength < beforeValue.length - prefixLength &&
    suffixLength < afterValue.length - prefixLength &&
    beforeValue[beforeValue.length - 1 - suffixLength] ===
      afterValue[afterValue.length - 1 - suffixLength]
  ) {
    suffixLength += 1;
  }

  const insertedEnd = afterValue.length - suffixLength;
  const inserted = afterValue.slice(prefixLength, insertedEnd);
  let normalizedInserted = inserted;
  if (
    kind === "ideographic-comma" &&
    inserted.includes("、") &&
    inserted.replaceAll("\\", "") === "、"
  ) {
    normalizedInserted = "、";
  } else if (
    kind === "latin-backslash" &&
    inserted.length > 1 &&
    /^\\+$/.test(inserted)
  ) {
    normalizedInserted = "\\";
  }

  if (normalizedInserted === inserted) return afterValue;
  return (
    afterValue.slice(0, prefixLength) +
    normalizedInserted +
    afterValue.slice(insertedEnd)
  );
}

function selectionIsCollapsed(selection: MathSelectionSnapshot) {
  return selection.ranges.every(([start, end]) => start === end);
}

function inferEditKind(
  inputType: string,
  beforeSelection: MathSelectionSnapshot,
): EditKind {
  if (inputType.includes("deleteContentBackward")) return "delete-backward";
  if (inputType.includes("deleteContentForward")) return "delete-forward";
  if (inputType.includes("Composition")) return "composition";
  if (inputType.includes("insert") && selectionIsCollapsed(beforeSelection)) {
    return "insert";
  }
  return "replace";
}

function inferEditSource(inputType: string): FormulaEditSource {
  return inputType.toLocaleLowerCase().includes("paste") ? "paste" : "keyboard";
}

const tallFormulaPattern =
  /\\(?:d?frac|tfrac|sqrt|sum|prod|int|iint|iiint|oint|oiint|oiiint|lim|begin|overset|underset|overline|underline)\b|[_^]/;
const bareStructuredOperatorPattern =
  /^\\(?:int|iint|iiint|oint|oiint|oiiint|sum|prod|lim|bigcup|bigcap)\s*$/;
const scriptContainerPattern = /^[_^]\{[\s\S]*\}$/;

function findTrailingCommandRange(
  field: MathfieldElement,
  activeQuery: string,
): [number, number] | null {
  const normalizedQuery = activeQuery.trim();
  if (!normalizedQuery) return null;

  const candidateEnds = Array.from(
    new Set([field.position, field.lastOffset].filter((offset) => offset >= 0)),
  );
  for (const end of candidateEnds) {
    for (let start = end; start >= 0; start -= 1) {
      const rangeLatex = field.getValue(start, end, "latex").trim();
      if (rangeLatex === normalizedQuery) return [start, end];
    }
  }

  return null;
}

function getVisibleNativeSuggestionItems(
  field?: MathfieldElement,
): HTMLElement[] {
  const source = getNativeInputPopoverSource();
  const stable = document.getElementById(STABLE_NATIVE_INPUT_POPOVER_ID);
  const sourceItems = Array.from(
    source?.querySelectorAll<HTMLElement>("li[data-command]") ?? [],
  );
  const stableItems = Array.from(
    stable?.querySelectorAll<HTMLElement>("li[data-command]") ?? [],
  );
  const sourceVisible = Boolean(
    source?.classList.contains("is-visible") && sourceItems.length,
  );
  const stableVisible = Boolean(
    stable?.classList.contains("is-visible") && stableItems.length,
  );

  if (!sourceVisible && !stableVisible) return [];
  if (sourceVisible) return sourceItems;
  if (!field || !rawLatexInput(field).trim()) return [];

  // The user-facing panel is a persistent clone of MathLive's source panel.
  // MathLive can briefly remove `is-visible` from the hidden source while it
  // rebuilds or remounts it, even though the stable panel is still displayed.
  // Keep keyboard navigation bound to the displayed candidate list during that
  // hand-off instead of allowing ArrowUp/ArrowDown to fall through to row
  // navigation.
  return sourceItems.length ? sourceItems : stableItems;
}

function moveNativeSuggestionSelection(
  field: MathfieldElement,
  direction: 1 | -1,
): string | null {
  const items = getVisibleNativeSuggestionItems(field);
  if (!items.length) return null;
  const currentIndex = items.findIndex((item) =>
    item.classList.contains("ML__popover__current"),
  );
  const nextIndex =
    currentIndex < 0
      ? direction > 0
        ? 0
        : items.length - 1
      : (currentIndex + direction + items.length) % items.length;
  const command = items[nextIndex]?.dataset.command ?? "";
  if (!command) return null;

  // MathLive rebuilds and remounts its entire suggestion popover when the
  // nextSuggestion/previousSuggestion commands run. VisualTeX commits the
  // remembered command itself, so moving only the current-row marker preserves
  // the same popover node and avoids a visible flash on every arrow key.
  nativeInputPopoverManualCommand = command;
  syncStableNativeInputPopoverSelection(command);
  return command;
}

function insertRawCommandIntoVerticalPlaceholder(
  field: MathfieldElement,
  anchor: RawCommandAnchor,
  insertionTemplate: string,
  selectedCommand: string,
) {
  const semanticAnchor = anchor.verticalPlaceholder;
  if (!semanticAnchor) return false;

  field.executeCommand(["complete", "reject"]);
  field.mode = "math";
  field.setValue(anchor.latex, {
    mode: "math",
    format: "latex",
    insertionMode: "replaceAll",
    selectionMode: "after",
    silenceNotifications: true,
  });

  const restoredSelection = clampSelection(
    anchor.selection,
    field.lastOffset,
  );
  const restoredRange = restoredSelection.ranges.at(-1) ?? null;
  let targetRange: [number, number] | null = null;
  if (
    restoredRange &&
    field
      .getValue(
        Math.min(restoredRange[0], restoredRange[1]),
        Math.max(restoredRange[0], restoredRange[1]),
        "latex",
      )
      .trim() === "\\placeholder{}"
  ) {
    field.selection = restoredSelection;
    const restoredSemantic = describeSelectedVerticalPlaceholder(field);
    if (
      !restoredSemantic ||
      (restoredSemantic.kind === semanticAnchor.kind &&
        restoredSemantic.region === semanticAnchor.region)
    ) {
      targetRange = [
        Math.min(restoredRange[0], restoredRange[1]),
        Math.max(restoredRange[0], restoredRange[1]),
      ];
    }
  }
  targetRange ??= findMatchingVerticalPlaceholderRange(
    field,
    semanticAnchor,
  );
  if (!targetRange) return false;

  field.selection = { ranges: [targetRange], direction: "none" };
  const inserted = field.insert(insertionTemplate, {
    mode: "math",
    format: "latex",
    insertionMode: "replaceSelection",
    selectionMode:
      insertionTemplate.includes("\\placeholder{}") ||
      nativePlaceholderSelectionCommands.has(selectedCommand)
        ? "placeholder"
        : "after",
    focus: true,
    scrollIntoView: false,
  });
  if (inserted) {
    selectFirstLatexPlaceholder(field, selectedCommand, insertionTemplate);
  }
  return inserted;
}

function commitNativeSuggestion(
  field: MathfieldElement,
  settings: InputBehaviorSettings,
  rememberedCommand = "",
): boolean {
  const selectedCommand =
    rememberedCommand ||
    getVisibleNativeSuggestionItems(field).find((item) =>
      item.classList.contains("ML__popover__current"),
    )?.dataset.command ||
    "";

  if (selectedCommand) {
    const rawInput = rawLatexInput(field).trim();
    const anchor = rawCommandAnchors.get(field);
    const queryRange = rawInput
      ? findTrailingCommandRange(field, rawInput)
      : null;
    if (!anchor && !queryRange && field.mode !== "latex") {
      dismissNativeSuggestionPopover(field);
      return false;
    }
    const insertionTemplate =
      exactRawPlaceholderTemplate(selectedCommand) ?? selectedCommand;
    if (
      anchor?.selectedPlaceholder &&
      rawInput === selectedCommand &&
      !insertionTemplate.includes("\\placeholder{}")
    ) {
      clearVisualTexPlaceholderRestoreState(field);
      const accepted = field.executeCommand(["complete", "accept-all"]);
      if (accepted) {
        recordNativeSuggestionUsage(
          selectedCommand,
          rawInput || selectedCommand,
        );
        applyCompletedRawCommandAutoExit(
          field,
          settings,
          anchor,
          selectedCommand,
        );
        rawCommandAnchors.delete(field);
        dismissNativeSuggestionPopover(field);
      }
      return accepted;
    }
    if (anchor) {
      restoreRawCommandInsertionAnchor(field, anchor);
    } else {
      field.mode = "math";
      if (queryRange) {
        field.selection = {
          ranges: [queryRange],
          direction: "forward",
        };
      }
    }
    const inserted = field.insert(insertionTemplate, {
      mode: "math",
      format: "latex",
      insertionMode: "replaceSelection",
      selectionMode:
        insertionTemplate.includes("\\placeholder{}") ||
        nativePlaceholderSelectionCommands.has(selectedCommand)
          ? "placeholder"
          : "after",
      focus: true,
      scrollIntoView: false,
    });
    if (inserted) {
      recordNativeSuggestionUsage(
        selectedCommand,
        rawInput || selectedCommand,
      );
      selectFirstLatexPlaceholder(field, selectedCommand, insertionTemplate);
      applyCompletedRawCommandAutoExit(
        field,
        settings,
        anchor,
        insertionTemplate,
      );
      rawCommandAnchors.delete(field);
      dismissNativeSuggestionPopover(field);
    }
    return inserted;
  }

  if (!getVisibleNativeSuggestionItems(field).length && field.mode !== "latex") {
    return false;
  }
  const anchor = rawCommandAnchors.get(field);
  const rawQuery = rawCommandQuery(field);
  const accepted = field.executeCommand(["complete", "accept-all"]);
  if (accepted) {
    applyCompletedRawCommandAutoExit(field, settings, anchor, rawQuery);
    rawCommandAnchors.delete(field);
  }
  return accepted;
}

function dismissNativeSuggestionPopover(field: MathfieldElement) {
  nativeInputPopoverManualCommand = "";
  const panel = document.getElementById("mathlive-suggestion-popover");
  const stablePanel = document.getElementById(STABLE_NATIVE_INPUT_POPOVER_ID);
  window.clearTimeout(stableNativeInputPopoverHideTimer);
  field.popoverPolicy = "off";
  panel?.classList.remove("is-visible");
  panel?.setAttribute("aria-hidden", "true");
  stablePanel?.classList.remove("is-visible");
  stablePanel?.setAttribute("aria-hidden", "true");
  window.setTimeout(() => {
    if (!field.isConnected) return;
    field.popoverPolicy = "auto";
  }, 120);
}

function keepCaretAfterBareStructuredOperator(
  field: MathfieldElement,
  previousPosition: number,
) {
  if (field.position >= previousPosition || field.position >= field.lastOffset) {
    return;
  }

  const operatorOffset = field.position + 1;
  const operatorLatex =
    field.getElementInfo(operatorOffset)?.latex?.trim() ||
    field.getValue(field.position, operatorOffset, "latex").trim();
  if (!bareStructuredOperatorPattern.test(operatorLatex)) return;

  field.selection = {
    ranges: [[operatorOffset, operatorOffset]],
    direction: "none",
  };
  field.position = operatorOffset;
}

type ScriptCaretRegion = "upper" | "lower";

type ScriptCaretContext = {
  region: ScriptCaretRegion;
  kind: "script" | "operator-limit";
  caret: HTMLElement | null;
  container: HTMLElement | null;
  autoExitKey: string | null;
};

const consumedScriptAutoExitKeys = new WeakMap<
  MathfieldElement,
  Set<string>
>();

function activeMathCaretMarker(field: MathfieldElement) {
  return Array.from(
    field.shadowRoot?.querySelectorAll<HTMLElement>(
      ".ML__placeholder-selected, .ML__selected, .ML__caret",
    ) ?? [],
  ).find((marker) => marker.getBoundingClientRect().height > 0) ?? null;
}

function scriptBranchAutoExitKey(
  caret: HTMLElement | null,
  container: HTMLElement | null,
  region: ScriptCaretRegion,
) {
  if (!caret || !container || !container.classList.contains("ML__msubsup")) {
    return null;
  }

  // MathLive keeps a stable branch sentinel atom inside each super/subscript.
  // Its id survives caret movement and content edits, unlike model offsets,
  // which shift whenever another character is inserted.
  const branch = caret.parentElement ?? caret;
  const branchAtomId = branch
    .querySelector<HTMLElement>("[data-atom-id]")
    ?.getAttribute("data-atom-id");
  if (branchAtomId) return `${region}:branch:${branchAtomId}`;

  const base = container.previousElementSibling as HTMLElement | null;
  const baseAtomId =
    base?.getAttribute("data-atom-id") ??
    base
      ?.querySelector<HTMLElement>("[data-atom-id]")
      ?.getAttribute("data-atom-id");
  return baseAtomId ? `${region}:base:${baseAtomId}` : null;
}

function getScriptCaretContext(
  field: MathfieldElement,
): ScriptCaretContext | null {
  const caret = activeMathCaretMarker(field);
  const container = caret?.closest<HTMLElement>(
    ".ML__msubsup, .ML__op-group",
  ) ?? null;

  const currentOffset = Math.max(
    field.position,
    ...field.selection.ranges.flatMap(([start, end]) => [start, end]),
  );
  const currentDepth = field.getElementInfo(currentOffset)?.depth;
  let modelRegion: ScriptCaretRegion | null = null;
  if (typeof currentDepth === "number" && currentDepth > 0) {
    for (
      let offset = currentOffset + 1;
      offset <= Math.min(field.lastOffset, currentOffset + 3);
      offset += 1
    ) {
      const info = field.getElementInfo(offset);
      if (typeof info?.depth !== "number" || info.depth >= currentDepth) continue;
      const containerLatex = (info.latex ?? "").trim();
      if (/^\^\s*\{/.test(containerLatex)) modelRegion = "upper";
      else if (/^_\s*\{/.test(containerLatex)) modelRegion = "lower";
      break;
    }
  }

  let region = modelRegion;
  if (!region && caret && container) {
    const caretBounds = (caret.parentElement ?? caret).getBoundingClientRect();
    const containerBounds = container.getBoundingClientRect();
    if (caretBounds.height && containerBounds.height) {
      region =
        caretBounds.top + caretBounds.height / 2 <
        containerBounds.top + containerBounds.height / 2
          ? "upper"
          : "lower";
    }
  }
  if (!region) return null;

  const operatorGroup = container?.closest<HTMLElement>(".ML__op-group") ?? null;
  const outerScript =
    container?.parentElement?.closest<HTMLElement>(".ML__msubsup") ?? null;
  const kind =
    container?.classList.contains("ML__op-group") ||
    (operatorGroup && !outerScript)
      ? "operator-limit"
      : "script";
  return {
    region,
    kind,
    caret,
    container,
    autoExitKey:
      kind === "script"
        ? scriptBranchAutoExitKey(caret, container, region)
        : null,
  };
}

function getScriptCaretRegion(field: MathfieldElement) {
  return getScriptCaretContext(field)?.region ?? null;
}

function scriptAutoExitWasConsumed(
  field: MathfieldElement,
  autoExitKey: string | null,
) {
  return Boolean(
    autoExitKey && consumedScriptAutoExitKeys.get(field)?.has(autoExitKey),
  );
}

function markScriptAutoExitConsumed(
  field: MathfieldElement,
  autoExitKey: string | null,
) {
  if (!autoExitKey) return;
  let keys = consumedScriptAutoExitKeys.get(field);
  if (!keys) {
    keys = new Set<string>();
    consumedScriptAutoExitKeys.set(field, keys);
  }
  keys.add(autoExitKey);
}

const accentContainerPattern =
  /^\\(?:acute|grave|dot|ddot|dddot|ddddot|tilde|bar|breve|check|hat|vec|widehat|widetilde|overline|overrightarrow|overleftarrow|overleftrightarrow)\s*\{/;

function caretIsInsideLatexContainer(
  field: MathfieldElement,
  containerPattern: RegExp,
) {
  const currentOffset = Math.max(
    field.position,
    ...field.selection.ranges.flatMap(([start, end]) => [start, end]),
  );
  const currentDepth = field.getElementInfo(currentOffset)?.depth;
  if (typeof currentDepth !== "number" || currentDepth <= 0) return false;

  for (
    let offset = currentOffset + 1;
    offset <= Math.min(field.lastOffset, currentOffset + 2);
    offset += 1
  ) {
    const info = field.getElementInfo(offset);
    if (
      typeof info?.depth === "number" &&
      info.depth < currentDepth &&
      containerPattern.test(info.latex ?? "")
    ) {
      return true;
    }
  }
  return false;
}

function caretIsInsideAccent(field: MathfieldElement) {
  return caretIsInsideLatexContainer(field, accentContainerPattern);
}

type CapturedAccentAutoExit = {
  command: string;
  expectedBoundary: number;
};

function moveCaretAfterCapturedAccent(
  field: MathfieldElement,
  captured: CapturedAccentAutoExit,
) {
  const normalizedCommand = captured.command.trim();
  if (!normalizedCommand) return false;
  const candidates: number[] = [];
  for (let offset = 0; offset <= field.lastOffset; offset += 1) {
    const latex = normalizeChineseLatex(
      field.getElementInfo(offset)?.latex ?? "",
    ).trim();
    if (
      latex.startsWith(`${normalizedCommand}{`) &&
      !latex.includes("\\placeholder{}")
    ) {
      candidates.push(offset);
    }
  }
  const target = candidates.sort(
    (left, right) =>
      Math.abs(left - captured.expectedBoundary) -
      Math.abs(right - captured.expectedBoundary),
  )[0];
  if (target === undefined || field.position === target) return false;
  field.selection = {
    ranges: [[target, target]],
    direction: "none",
  };
  field.position = target;
  return true;
}

function getCaretAutoExitSetting(
  field: MathfieldElement,
): InputBehaviorSettingKey | null {
  if (caretIsInsideAccent(field)) return "autoExitAccent";

  const scriptContext = getScriptCaretContext(field);
  // Only the directly edited ordinary script participates in one-character
  // auto-exit. An outer radical, fraction, integral or other structure must not
  // suppress a nested x^a/x_a script; large-operator limits themselves remain
  // excluded.
  if (!scriptContext || scriptContext.kind !== "script") return null;
  if (scriptContext.region === "upper") return "autoExitSuperscript";
  if (scriptContext.region === "lower") return "autoExitSubscript";
  return null;
}

function isSingleDirectInput(event: InputEvent, field: MathfieldElement) {
  if (event.isComposing || field.mode === "latex") return false;
  if (event.inputType !== "insertText") return false;
  const data = event.data ?? "";
  if (data === "\\" || Array.from(data).length !== 1) return false;
  return true;
}

function moveCaretThroughEnabledAutoExitContainers(
  field: MathfieldElement,
  settings: InputBehaviorSettings,
  capturedSetting?: InputBehaviorSettingKey | null,
  capturedScriptKey?: string | null,
) {
  const moveOne = (
    setting: InputBehaviorSettingKey,
    preferredScriptKey: string | null = null,
  ) => {
    if (!settings[setting]) return false;
    if (setting === "autoExitAccent" && !caretIsInsideAccent(field)) {
      return false;
    }

    let scriptKey: string | null = null;
    if (
      setting === "autoExitSuperscript" ||
      setting === "autoExitSubscript"
    ) {
      const context = getScriptCaretContext(field);
      if (context?.kind === "operator-limit") return false;
      scriptKey = preferredScriptKey ?? context?.autoExitKey ?? null;
      if (scriptAutoExitWasConsumed(field, scriptKey)) return false;
    }

    const previousPosition = field.position;
    const changed = field.executeCommand(
      setting === "autoExitAccent" ? "moveToNextChar" : "moveAfterParent",
    );
    const moved = Boolean(changed || field.position !== previousPosition);
    if (moved && scriptKey) markScriptAutoExitConsumed(field, scriptKey);
    return moved;
  };

  if (capturedSetting) {
    return moveOne(capturedSetting, capturedScriptKey ?? null);
  }

  let moved = false;
  for (let attempt = 0; attempt < 4; attempt += 1) {
    const setting = getCaretAutoExitSetting(field);
    if (!setting) break;
    if (!moveOne(setting)) break;
    moved = true;
  }
  return moved;
}

function applyCompletedRawCommandAutoExit(
  field: MathfieldElement,
  settings: InputBehaviorSettings,
  anchor: RawCommandAnchor | null | undefined,
  insertedLatex: string,
) {
  if (
    !anchor?.autoExitSetting ||
    insertedLatex.includes("\\placeholder{}")
  ) {
    return false;
  }
  return moveCaretThroughEnabledAutoExitContainers(
    field,
    settings,
    anchor.autoExitSetting,
    anchor.autoExitScriptKey,
  );
}

const customVerticalStructurePattern =
  /^\\(?:overset|underset|overunderset|stackrel|stackbin|x[A-Za-z]+)(?=\s|\[|\{|$)/;

type VerticalModelBounds = {
  left: number;
  top: number;
  width: number;
  height: number;
};

type CustomVerticalRole = "upper" | "base" | "lower";

type CustomVerticalModelBranch = {
  start: number;
  end: number;
  offsets: number[];
  role: CustomVerticalRole;
};

function verticalModelBounds(
  field: MathfieldElement,
  offset: number,
): VerticalModelBounds | null {
  const bounds = field.getElementInfo(offset)?.bounds;
  if (
    !bounds ||
    !Number.isFinite(bounds.left) ||
    !Number.isFinite(bounds.top) ||
    !Number.isFinite(bounds.width) ||
    !Number.isFinite(bounds.height) ||
    bounds.height <= 0
  ) {
    return null;
  }
  return {
    left: bounds.left,
    top: bounds.top,
    width: bounds.width,
    height: bounds.height,
  };
}

function customVerticalRoles(
  containerLatex: string,
  branchCount: number,
): CustomVerticalRole[] {
  if (/^\\(?:overset|stackrel|stackbin)(?=\s|\{|$)/.test(containerLatex)) {
    return ["base", "upper"].slice(0, branchCount) as CustomVerticalRole[];
  }
  if (/^\\underset(?=\s|\{|$)/.test(containerLatex)) {
    return ["base", "lower"].slice(0, branchCount) as CustomVerticalRole[];
  }
  if (/^\\overunderset(?=\s|\{|$)/.test(containerLatex)) {
    return ["base", "lower", "upper"].slice(
      0,
      branchCount,
    ) as CustomVerticalRole[];
  }
  if (/^\\x[A-Za-z]+(?=\s|\[|\{|$)/.test(containerLatex)) {
    return (branchCount >= 2 ? ["upper", "lower"] : ["upper"]).slice(
      0,
      branchCount,
    ) as CustomVerticalRole[];
  }
  return [];
}

function customVerticalModelBranches(
  field: MathfieldElement,
  containerEnd: number,
  containerDepth: number,
) {
  let start = containerEnd - 1;
  while (start >= 0) {
    const depth = field.getElementInfo(start)?.depth;
    if (typeof depth !== "number" || depth <= containerDepth) break;
    start -= 1;
  }
  start += 1;

  const childDepth = containerDepth + 1;
  const groups: Array<{ start: number; offsets: number[] }> = [];
  let current: { start: number; offsets: number[] } | null = null;
  for (let offset = start; offset < containerEnd; offset += 1) {
    const info = field.getElementInfo(offset);
    const latex = (info?.latex ?? "").trim();
    if (info?.depth === childDepth && !latex) {
      if (current) groups.push(current);
      current = { start: offset, offsets: [offset] };
      continue;
    }
    if (!current) current = { start, offsets: [] };
    current.offsets.push(offset);
  }
  if (current) groups.push(current);

  const meaningful = groups.filter((group) =>
    group.offsets.some((offset) =>
      Boolean((field.getElementInfo(offset)?.latex ?? "").trim()),
    ),
  );
  const containerLatex =
    field.getElementInfo(containerEnd)?.latex?.trim() ?? "";
  const roles = customVerticalRoles(containerLatex, meaningful.length);
  return meaningful.flatMap((group, index) => {
    const role = roles[index];
    if (!role) return [];
    const nextStart = meaningful[index + 1]?.start ?? containerEnd;
    return [
      {
        start: group.start,
        end: nextStart,
        offsets: group.offsets,
        role,
      } satisfies CustomVerticalModelBranch,
    ];
  });
}

function customVerticalBranchTargetOffset(
  field: MathfieldElement,
  branch: CustomVerticalModelBranch,
) {
  const candidates = branch.offsets.filter((offset) => {
    const latex = (field.getElementInfo(offset)?.latex ?? "").trim();
    return Boolean(latex) && !customVerticalStructurePattern.test(latex);
  });
  return candidates[0] ?? null;
}

function moveWithinCustomVerticalStructureByModel(
  field: MathfieldElement,
  direction: "up" | "down",
  sourceOffset: number,
) {
  const currentInfo = field.getElementInfo(sourceOffset);
  const currentDepth = currentInfo?.depth;
  if (typeof currentDepth !== "number" || currentDepth <= 0) return false;

  const containers: Array<{ end: number; depth: number }> = [];
  for (let offset = sourceOffset + 1; offset <= field.lastOffset; offset += 1) {
    const info = field.getElementInfo(offset);
    const depth = info?.depth;
    const latex = (info?.latex ?? "").trim();
    if (
      typeof depth === "number" &&
      depth < currentDepth &&
      customVerticalStructurePattern.test(latex)
    ) {
      containers.push({ end: offset, depth });
    }
  }
  containers.sort(
    (left, right) => right.depth - left.depth || left.end - right.end,
  );

  for (const container of containers) {
    const branches = customVerticalModelBranches(
      field,
      container.end,
      container.depth,
    );
    const currentBranch = branches.find(
      (branch) => sourceOffset >= branch.start && sourceOffset < branch.end,
    );
    if (!currentBranch) continue;

    const hasBaseBranch = branches.some((branch) => branch.role === "base");
    const targetRole: CustomVerticalRole | null =
      direction === "up"
        ? currentBranch.role === "lower"
          ? hasBaseBranch
            ? "base"
            : "upper"
          : currentBranch.role === "base"
            ? "upper"
            : null
        : currentBranch.role === "upper"
          ? hasBaseBranch
            ? "base"
            : "lower"
          : currentBranch.role === "base"
            ? "lower"
            : null;
    if (!targetRole) continue;
    const targetBranch = branches.find((branch) => branch.role === targetRole);
    if (!targetBranch) continue;
    const targetOffset = customVerticalBranchTargetOffset(field, targetBranch);
    if (targetOffset === null || targetOffset === sourceOffset) continue;

    const targetLatex =
      field.getElementInfo(targetOffset)?.latex?.trim() ?? "";
    if (targetLatex === "\\placeholder{}" && targetOffset > 0) {
      field.selection = {
        ranges: [[targetOffset - 1, targetOffset]],
        direction: "none",
      };
    } else {
      field.selection = {
        ranges: [[targetOffset, targetOffset]],
        direction: "none",
      };
      field.position = targetOffset;
    }
    // This fallback only runs from an active keydown inside the current
    // Mathfield. Re-focusing MathLive here can make scripted x-arrow structures
    // restore their previous branch before the key event unwinds on Chromium.
    // Keep the existing focus and only commit the final model selection.
    return true;
  }
  return false;
}

function moveWithinCustomVerticalStructure(
  field: MathfieldElement,
  direction: "up" | "down",
  sourceOffset?: number,
) {
  const caret = activeMathCaretMarker(field);
  // Ordinary scripts, large-operator limits and fractions already have mature
  // native navigation. The custom fallback only handles the atom types for
  // which MathLive reports moveUp/moveDown success without changing offsets.
  if (
    sourceOffset === undefined &&
    caret?.closest(".ML__msubsup, .ML__op-group, .ML__mfrac")
  ) {
    return false;
  }

  const currentOffset =
    sourceOffset === undefined
      ? Math.max(
          field.position,
          ...field.selection.ranges.flatMap(([start, end]) => [start, end]),
        )
      : Math.max(0, Math.min(field.lastOffset, sourceOffset));
  const currentInfo = field.getElementInfo(currentOffset);
  const currentDepth = currentInfo?.depth;
  if (typeof currentDepth !== "number" || currentDepth <= 0) return false;

  const modelBounds = verticalModelBounds(field, currentOffset);
  if (
    !modelBounds &&
    moveWithinCustomVerticalStructureByModel(field, direction, currentOffset)
  ) {
    return true;
  }
  const markerBounds = caret?.getBoundingClientRect();
  // The model offset is authoritative for the mathematical branch. Prefer its
  // geometry (including the Windows caret-probe fallback) and use the current
  // DOM caret only when the requested model offset has no measurable geometry.
  const currentX = modelBounds
    ? modelBounds.left + Math.max(0, modelBounds.width) / 2
    : markerBounds?.left ?? 0;
  const currentY = modelBounds
    ? modelBounds.top + modelBounds.height / 2
    : markerBounds?.height
      ? markerBounds.top + markerBounds.height / 2
      : 0;
  if (!Number.isFinite(currentX) || !Number.isFinite(currentY)) return false;

  const containers: Array<{
    end: number;
    depth: number;
  }> = [];
  for (let offset = currentOffset + 1; offset <= field.lastOffset; offset += 1) {
    const info = field.getElementInfo(offset);
    const depth = info?.depth;
    const latex = (info?.latex ?? "").trim();
    if (
      typeof depth === "number" &&
      depth < currentDepth &&
      customVerticalStructurePattern.test(latex)
    ) {
      containers.push({ end: offset, depth });
    }
  }
  containers.sort((left, right) => right.depth - left.depth || left.end - right.end);

  for (const container of containers) {
    let start = container.end - 1;
    while (start >= 0) {
      const depth = field.getElementInfo(start)?.depth;
      if (typeof depth !== "number" || depth <= container.depth) break;
      start -= 1;
    }
    start += 1;

    const entries: Array<{
      offset: number;
      latex: string;
      x: number;
      y: number;
    }> = [];
    for (let offset = start; offset < container.end; offset += 1) {
      const info = field.getElementInfo(offset);
      if (info?.depth !== container.depth + 1) continue;
      const bounds = verticalModelBounds(field, offset);
      if (!bounds) continue;
      const latex = (info.latex ?? "").trim();
      // Empty branch sentinels have a negative width and accurately represent
      // the visual band. Positive-width empty atoms are internal layout boxes
      // and would create false intermediate bands for stackrel/stackbin.
      if (!latex && bounds.width >= 0) continue;
      entries.push({
        offset,
        latex,
        x: bounds.left + Math.max(0, bounds.width) / 2,
        y: bounds.top + bounds.height / 2,
      });
    }
    if (entries.length < 2) continue;

    entries.sort((left, right) => left.y - right.y);
    const bands: Array<{
      y: number;
      entries: typeof entries;
    }> = [];
    for (const entry of entries) {
      const previous = bands.at(-1);
      if (previous && Math.abs(previous.y - entry.y) <= 14) {
        previous.entries.push(entry);
        previous.y =
          previous.entries.reduce((sum, item) => sum + item.y, 0) /
          previous.entries.length;
      } else {
        bands.push({ y: entry.y, entries: [entry] });
      }
    }
    if (bands.length < 2) continue;

    let currentBandIndex = 0;
    for (let index = 1; index < bands.length; index += 1) {
      if (
        Math.abs(bands[index].y - currentY) <
        Math.abs(bands[currentBandIndex].y - currentY)
      ) {
        currentBandIndex = index;
      }
    }
    const targetBandIndex =
      currentBandIndex + (direction === "up" ? -1 : 1);
    const targetBand = bands[targetBandIndex];
    if (!targetBand) continue;

    const leafCandidates: Array<{
      offset: number;
      latex: string;
      x: number;
      y: number;
    }> = [];
    for (let offset = start; offset < container.end; offset += 1) {
      const info = field.getElementInfo(offset);
      const bounds = verticalModelBounds(field, offset);
      const latex = (info?.latex ?? "").trim();
      if (
        typeof info?.depth !== "number" ||
        info.depth <= container.depth ||
        !bounds ||
        !latex ||
        customVerticalStructurePattern.test(latex)
      ) {
        continue;
      }
      // Structured closing atoms contain braces. Their visible descendants are
      // better caret targets; placeholders are the only brace-bearing leaf we
      // select directly.
      if (latex !== "\\placeholder{}" && latex.includes("{")) continue;
      leafCandidates.push({
        offset,
        latex,
        x: bounds.left + bounds.width / 2,
        y: bounds.top + bounds.height / 2,
      });
    }

    const leafTarget = leafCandidates
      .filter(
        (candidate) =>
          candidate.offset !== currentOffset &&
          Math.abs(candidate.y - targetBand.y) <= 18,
      )
      .sort(
        (left, right) =>
          Math.abs(left.y - targetBand.y) * 4 +
          Math.abs(left.x - currentX) -
          (Math.abs(right.y - targetBand.y) * 4 +
            Math.abs(right.x - currentX)),
      )[0];

    let targetOffset = leafTarget?.offset ??
      field.getOffsetFromPoint(currentX, targetBand.y, { bias: 1 });
    if (
      targetOffset < start ||
      targetOffset >= container.end ||
      targetOffset === currentOffset
    ) {
      const candidate = [...targetBand.entries]
        .filter((entry) => entry.offset !== currentOffset)
        .sort(
          (left, right) =>
            Math.abs(left.x - currentX) - Math.abs(right.x - currentX),
        )[0];
      if (!candidate) continue;
      targetOffset = candidate.offset;
    }

    const targetLatex =
      field.getElementInfo(targetOffset)?.latex?.trim() ?? "";
    if (targetLatex === "\\placeholder{}" && targetOffset > 0) {
      field.selection = {
        ranges: [[targetOffset - 1, targetOffset]],
        direction: "none",
      };
    } else {
      field.selection = {
        ranges: [[targetOffset, targetOffset]],
        direction: "none",
      };
      field.position = targetOffset;
    }
    field.focus();
    field.shadowRoot
      ?.querySelector<HTMLElement>('[part="keyboard-sink"]')
      ?.focus({ preventScroll: true });
    return true;
  }
  return moveWithinCustomVerticalStructureByModel(
    field,
    direction,
    currentOffset,
  );
}

const previousTargetToolbarCommandIds = new Set([
  "scripts",
  "lower-script",
  "upper-script",
  "power",
  "subscript",
  "degree",
  "overline",
  "underline",
  "hat",
  "widehat",
  "tilde",
  "widetilde",
  "dotaccent",
  "ddotaccent",
  "checkaccent",
  "breveaccent",
  "acuteaccent",
  "graveaccent",
  "ringaccent",
  "overrightarrow",
  "overleftarrow",
  "overleftrightarrow",
  "overleftharpoon",
  "overrightharpoon",
  "overarc",
  "overgroup",
  "overparen",
  "overlinesegment",
  "underarc",
  "undergroup",
  "underparen",
  "underleftarrow",
  "underrightarrow",
  "underleftrightarrow",
  "underlinesegment",
  "overbrace",
  "underbrace",
  "overset",
  "underset",
  "overunderset",
  "stackrel",
  "stackbin",
  "vector",
  "unitvector",
  "timederivative",
  "timesecond",
  "boxed",
  "evalbar",
  "boldsymbol",
  "blackboard-bold",
  "math-italic",
  "math-roman",
  "math-sans",
  "math-typewriter",
  "math-calligraphic",
  "math-script",
  "math-fraktur",
  "bold-symbol",
  "math-normal",
]);

const previousTargetToolbarCommandPattern =
  /^\\(?:acute|grave|dot|ddot|dddot|ddddot|tilde|widetilde|bar|breve|check|hat|widehat|vec|overline|underline|overrightarrow|overleftarrow|overleftrightarrow|overleftharpoon|overrightharpoon|overarc|overgroup|overparen|overlinesegment|underarc|undergroup|underparen|underleftarrow|underrightarrow|underleftrightarrow|underlinesegment|mathring|boxed|mathbf|boldsymbol|mathbb|mathit|mathrm|mathsf|mathtt|mathcal|mathscr|mathfrak|mathnormal)$/;

const nonTargetablePreviousLatex =
  /^(?:[+\-*/=<>:,;.!?]+|\\(?:pm|mp|times|div|cdot|ast|star|circ|bullet|cap|cup|land|lor|leq?|geq?|neq?|approx|equiv|sim|simeq|cong|propto|in|notin|subseteq?|supseteq?|parallel|perp|mid|nmid|to|leftarrow|rightarrow|leftrightarrow|Rightarrow|Leftarrow|Leftrightarrow))$/;

function commandTargetsPreviousExpression(command: LatexCommand) {
  return (
    previousTargetToolbarCommandIds.has(command.id) ||
    previousTargetToolbarCommandPattern.test(command.command.trim())
  );
}

function previousExpressionSelection(field: MathfieldElement) {
  if (
    field.mode !== "math" ||
    !field.selectionIsCollapsed ||
    field.position <= 0 ||
    hasRawLatexInput(field)
  ) {
    return null;
  }

  const originalSelection = captureSelection(field);
  const extended = field.executeCommand("extendSelectionBackward");
  if (!extended || field.selectionIsCollapsed) {
    field.selection = originalSelection;
    return null;
  }

  const selectedLatex = field.getValue(field.selection).trim();
  if (
    !selectedLatex ||
    selectedLatex === "\\placeholder{}" ||
    nonTargetablePreviousLatex.test(selectedLatex)
  ) {
    field.selection = originalSelection;
    return null;
  }

  return {
    latex: selectedLatex,
    selection: captureSelection(field),
  };
}

function templateForSelection(
  command: LatexCommand,
  selectedLatex: string,
): string {
  if (!selectedLatex) return command.insertTemplate;

  switch (command.id) {
    case "scripts":
      return selectedLatex + "_{\\placeholder{}}^{\\placeholder{}}";
    case "lower-script":
    case "subscript":
      return selectedLatex + "_{\\placeholder{}}";
    case "upper-script":
    case "power":
      return selectedLatex + "^{\\placeholder{}}";
    case "degree":
      return selectedLatex + "^{\\circ}";
    case "overset":
    case "underset":
    case "stackrel":
    case "stackbin":
      return (
        replaceTextualPlaceholder(command.insertTemplate, 1, selectedLatex) ??
        command.insertTemplate
      );
    case "overunderset":
      return (
        replaceTextualPlaceholder(command.insertTemplate, 2, selectedLatex) ??
        command.insertTemplate
      );
    case "sum":
    case "series":
      return "\\sum_{\\placeholder{}}^{\\placeholder{}} " + selectedLatex;
    case "prod":
    case "productseries":
      return "\\prod_{\\placeholder{}}^{\\placeholder{}} " + selectedLatex;
    case "int":
      return "\\int_{\\placeholder{}}^{\\placeholder{}} " + selectedLatex + "\\,\\mathrm{d}\\placeholder{}";
    case "intplain":
      return "\\int " + selectedLatex + "\\,\\mathrm{d}\\placeholder{}";
    case "lineintegral":
      return "\\int_{C} " + selectedLatex + "\\,\\mathrm{d}s";
    case "surfaceintegral":
      return "\\iint_{S} " + selectedLatex + "\\,\\mathrm{d}S";
    case "volumeintegral":
      return "\\iiint_{V} " + selectedLatex + "\\,\\mathrm{d}V";
    case "closed-surface-integral":
      return "\\oiint_{S} " + selectedLatex + "\\,\\mathrm{d}S";
    case "closed-volume-integral":
      return "\\oiiint_{V} " + selectedLatex + "\\,\\mathrm{d}V";
    case "frac":
    case "smallfrac":
    case "displayfrac":
      return command.command + "{" + selectedLatex + "}{\\placeholder{}}";
    case "sqrt":
      return "\\sqrt{" + selectedLatex + "}";
    case "parentheses":
      return "\\left(" + selectedLatex + "\\right)";
    case "brackets":
      return "\\left[" + selectedLatex + "\\right]";
    case "braces":
      return "\\left\\{" + selectedLatex + "\\right\\}";
    case "absolute":
      return "\\left|" + selectedLatex + "\\right|";
    default:
      return command.insertTemplate.replace("\\placeholder{}", selectedLatex);
  }
}

function FormulaField(props: FormulaFieldProps) {
  const hostRef = useRef<HTMLDivElement>(null);
  const fieldRef = useRef<MathfieldElement | null>(null);
  const registeredLineIdRef = useRef(props.lineId);
  const syncFrameSizeRef = useRef<(() => void) | null>(null);
  const defaultInlineShortcutsRef =
    useRef<VisualTexInlineShortcutDefinitions | null>(null);
  const lastSnapshotRef = useRef<ReturnType<typeof captureFieldSnapshot> | null>(null);
  const previousSelectionSnapshotRef =
    useRef<ReturnType<typeof captureFieldSnapshot> | null>(null);
  const lastSelectionChangeAtRef = useRef(0);
  const compositionStartRef = useRef<ReturnType<typeof captureFieldSnapshot> | null>(null);
  const structuredCompositionAnchorRef =
    useRef<StructuredCompositionAnchor | null>(null);
  const sizingZoomRef = useRef(props.zoom);
  const sizingRowVerticalInsetRef = useRef(props.formulaRowVerticalInset);
  const propsRef = useRef(props);
  propsRef.current = props;

  useLayoutEffect(() => {
    const host = hostRef.current;
    if (!host) return;

    const initialLineId = propsRef.current.lineId;
    registeredLineIdRef.current = initialLineId;
    const lineId = initialLineId;
    const field = new MathfieldElement();
    MathfieldElement.locale = propsRef.current.language === "en" ? "en" : "zh-cn";
    field.value = propsRef.current.latex;
    field.className = "visual-mathfield";
    field.smartMode = false;
    field.smartFence = propsRef.current.autoPairDelimiters;
    field.readOnly = propsRef.current.readOnly;
    // VisualTeX handles superscript and subscript auto-exit independently.
    // Keep MathLive's built-in superscript heuristic disabled so it cannot
    // move out of an empty superscript before the first character is inserted.
    field.smartSuperscript = false;
    field.popoverPolicy = "auto";
    field.maxMatrixCols = 10;
    field.setAttribute("math-virtual-keyboard-policy", "manual");
    const isEn = propsRef.current.language === "en";
    field.setAttribute(
      "aria-label",
      isEn
        ? "Formula line " + (propsRef.current.index + 1)
        : "第 " + (propsRef.current.index + 1) + " 行公式",
    );
    field.removeAttribute("placeholder");
    const initialMetrics = formulaRowHeightMetrics(
      propsRef.current.latex,
      propsRef.current.zoom,
      propsRef.current.formulaRowVerticalInset,
    );
    const initialRowHeight = predictedFormulaRowHeight(
      propsRef.current.latex,
      propsRef.current.zoom,
      propsRef.current.formulaRowVerticalInset,
      host,
    );
    let initialHeightFloor = initialRowHeight;
    field.style.fontSize = initialMetrics.fontSize + "px";
    field.classList.toggle(
      "is-simple-formula",
      !initialMetrics.hasTallStructure,
    );
    field.style.height = initialRowHeight + "px";
    field.style.minHeight = initialRowHeight + "px";
    host.closest<HTMLElement>(".formula-line")?.style.setProperty(
      "--formula-row-height",
      initialRowHeight + "px",
    );
    installMathLiveContourIntegralShadowStyle(field);
    installCustomSymbolShadowStyle(field);
    installVisualTexStructuralPlaceholderStyle(field);
    applyVisualTexFormulaFonts(
      field,
      propsRef.current.formulaLetterFont,
      propsRef.current.formulaChineseFont,
    );

    let pointerPlaceholderFrame = 0;
    const schedulePointerPlaceholderSnapshotStyle = () => {
      window.cancelAnimationFrame(pointerPlaceholderFrame);
      pointerPlaceholderFrame = window.requestAnimationFrame(() => {
        if (
          field.isConnected &&
          visualTexPointerSelectingFields.has(field)
        ) {
          if (!visualTexPointerPlaceholderStyles.has(field)) {
            installPointerPlaceholderSnapshotStyle(field);
          }
          restorePointerPlaceholderSnapshotStyle(field);
        }
      });
    };
    let resizeFrame = 0;
    const measureFrameSize = () => {
      const metrics = formulaRowHeightMetrics(
        field.value,
        propsRef.current.zoom,
        propsRef.current.formulaRowVerticalInset,
      );
      const { fontSize, hasTallStructure, baseHeight, verticalPadding } =
        metrics;
      const content = field.shadowRoot?.querySelector<HTMLElement>(
        '[part="content"]',
      );
      const formulaRects = content
        ? Array.from(
            content.querySelectorAll<HTMLElement>(
              "[data-atom-id], .ML__base, .ML__mfrac, .ML__sqrt, " +
                ".ML__op-group, .ML__vlist",
            ),
          )
            .map((node) => node.getBoundingClientRect())
            .filter((rect) => rect.height > 0 && rect.width >= 0)
        : [];
      const formulaHeight = formulaRects.length
        ? Math.max(...formulaRects.map((rect) => rect.bottom)) -
          Math.min(...formulaRects.map((rect) => rect.top))
        : fontSize;
      const measuredHeight = Math.ceil(
        Math.max(baseHeight, formulaHeight + verticalPadding),
      );
      if (measuredHeight >= initialHeightFloor - 1) {
        initialHeightFloor = 0;
      }
      const nextHeight = Math.max(measuredHeight, initialHeightFloor);

      field.classList.toggle("is-simple-formula", !hasTallStructure);
      field.style.height = nextHeight + "px";
      field.style.minHeight = nextHeight + "px";
      host.closest<HTMLElement>(".formula-line")?.style.setProperty(
        "--formula-row-height",
        nextHeight + "px",
      );
    };
    const syncFrameSize = () => {
      window.cancelAnimationFrame(resizeFrame);
      resizeFrame = window.requestAnimationFrame(measureFrameSize);
    };
    syncFrameSizeRef.current = syncFrameSize;
    const handleLayoutRefresh = () => {
      syncFrameSize();
    };
    window.addEventListener(
      EDITOR_LAYOUT_REFRESH_EVENT,
      handleLayoutRefresh,
    );

    const imeGuard = new ImeCompositionGuard();
    let physicalBackslashGuard: {
      kind: PhysicalBackslashInputKind;
      beforeValue: string;
      expiresAt: number;
      acceptedInput: boolean;
    } | null = null;
    let suppressBackslashKeyReplayUntil = 0;
    let suppressUnarmedBackslashInputUntil = 0;
    let backslashGuardTimer = 0;
    let pendingAutoExitSetting: InputBehaviorSettingKey | null = null;
    let pendingAutoExitScriptKey: string | null = null;
    let pendingAccentAutoExit: CapturedAccentAutoExit | null = null;
    const capturePendingAutoExit = () => {
      pendingAccentAutoExit = null;
      pendingAutoExitSetting = getCaretAutoExitSetting(field);
      const context = getScriptCaretContext(field);
      pendingAutoExitScriptKey =
        pendingAutoExitSetting === "autoExitSuperscript" ||
        pendingAutoExitSetting === "autoExitSubscript"
          ? context?.autoExitKey ?? null
          : null;
    };
    const armSelectedAccentAutoExit = (
      state: VisualTexPlaceholderBranchState,
    ) => {
      const command = state.restoreLatex?.match(/^\\[A-Za-z]+/)?.[0] ?? "";
      const range = state.selection?.ranges.at(-1) ?? null;
      if (!command || !range) return;
      pendingAutoExitSetting = "autoExitAccent";
      pendingAutoExitScriptKey = null;
      pendingAccentAutoExit = {
        command,
        expectedBoundary: Math.max(range[0], range[1]) + 1,
      };
    };
    const clearPendingAutoExit = () => {
      pendingAutoExitSetting = null;
      pendingAutoExitScriptKey = null;
      pendingAccentAutoExit = null;
    };
    let pendingWrapperInput: {
      command: string;
      content: string;
      range: [number, number];
      anchorStyle: Readonly<Style>;
      visualCaret: WrapperCaretAnchor | null;
      autoExitSetting: "autoExitWrapperCommand";
      parentAutoExitSetting: InputBehaviorSettingKey | null;
      parentAutoExitScriptKey: string | null;
    } | null = null;
    let pendingPackageMacroInput: {
      macroName: string;
      placeholderIndex: number;
      sourcePrefix: string;
      sourceSuffix: string;
      content: string;
      modelStart: number;
    } | null = null;
    const clearPendingPackageMacroInput = () => {
      pendingPackageMacroInput = null;
    };
    let replacingPendingWrapperInput = false;
    let restoringRawCommandAnchor = false;
    let wrapperPlaceholderFrame = 0;
    let wrapperPlaceholderPass = 0;
    let wrapperMeasure: HTMLSpanElement | null = null;
    const clearPendingWrapperPlaceholderPosition = () => {
      host.style.removeProperty("--pending-wrapper-left");
      host.style.removeProperty("--pending-wrapper-top");
      host.style.removeProperty("--pending-wrapper-width");
      host.style.removeProperty("--pending-wrapper-height");
      delete host.dataset.pendingWrapperAnchorY;
    };
    const measurePendingWrapperPlaceholderPosition = () => {
      if (!field.isConnected || !pendingWrapperInput) return;
      const hostBounds = host.getBoundingClientRect();
      const anchor =
        pendingWrapperInput.visualCaret ?? captureWrapperCaretAnchor(field);
      if (!pendingWrapperInput.visualCaret && anchor) {
        pendingWrapperInput.visualCaret = anchor;
      }
      const markers = Array.from(
        field.shadowRoot?.querySelectorAll<HTMLElement>(
          ".visualtex-structural-placeholder-caret, .ML__caret, .ML__text-caret, .ML__latex-caret",
        ) ?? [],
      )
        .map((marker) => {
          const bounds = marker.getBoundingClientRect();
          return {
            left: bounds.right - hostBounds.left,
            centerY: bounds.top - hostBounds.top + bounds.height / 2,
            height: bounds.height,
          };
        })
        .filter((marker) => marker.height > 0)
        .sort(
          (first, second) =>
            Math.abs(first.centerY - (anchor?.centerY ?? first.centerY)) -
            Math.abs(second.centerY - (anchor?.centerY ?? second.centerY)),
        );
      const closestMarker = markers[0] ?? null;
      const verticalCaret = anchor ?? closestMarker;
      if (!verticalCaret) {
        clearPendingWrapperPlaceholderPosition();
        return;
      }

      if (!wrapperMeasure) {
        wrapperMeasure = document.createElement("span");
        wrapperMeasure.className = "pending-wrapper-measure";
        wrapperMeasure.setAttribute("aria-hidden", "true");
        host.append(wrapperMeasure);
      }
      const content = pendingWrapperInput.content;
      let renderedWidth = 0;
      if (content) {
        wrapperMeasure.style.fontSize = field.style.fontSize;
        wrapperMeasure.innerHTML = convertVisualTexLatexToMarkup(
          pendingWrapperInput.command + "{" + content + "}",
          { defaultMode: "math" },
        );
        renderedWidth = wrapperMeasure.getBoundingClientRect().width;
      } else {
        wrapperMeasure.replaceChildren();
      }
      const frameWidth = Math.max(18, Math.ceil(renderedWidth + 10));
      const fallbackFrameLeft = content
        ? (closestMarker?.left ?? verticalCaret.left) - renderedWidth
        : closestMarker?.left ?? verticalCaret.left;
      const frameLeft = anchor?.left ?? fallbackFrameLeft;
      const frameCenterX = frameLeft + frameWidth / 2;
      const formulaFontSize =
        Number.parseFloat(field.style.fontSize) || BASE_FORMULA_FONT_SIZE;
      const minimumFrameHeight = Math.max(12, formulaFontSize * 0.52);
      const maximumFrameHeight = Math.max(
        minimumFrameHeight,
        formulaFontSize * 1.08,
      );
      const frameHeight = Math.max(
        minimumFrameHeight,
        Math.min(maximumFrameHeight, verticalCaret.height + 4),
      );
      host.style.setProperty("--pending-wrapper-left", `${frameCenterX}px`);
      host.style.setProperty(
        "--pending-wrapper-top",
        `${verticalCaret.centerY}px`,
      );
      host.style.setProperty("--pending-wrapper-width", `${frameWidth}px`);
      host.style.setProperty(
        "--pending-wrapper-height",
        `${frameHeight}px`,
      );
      host.dataset.pendingWrapperAnchorY = String(verticalCaret.centerY);

      wrapperPlaceholderPass += 1;
      if (
        wrapperPlaceholderPass < 3 &&
        host.classList.contains("has-pending-wrapper-placeholder")
      ) {
        wrapperPlaceholderFrame = window.requestAnimationFrame(
          measurePendingWrapperPlaceholderPosition,
        );
      }
    };
    const schedulePendingWrapperPlaceholderPosition = () => {
      window.cancelAnimationFrame(wrapperPlaceholderFrame);
      if (!host.classList.contains("has-pending-wrapper-placeholder")) {
        clearPendingWrapperPlaceholderPosition();
        return;
      }
      wrapperPlaceholderPass = 0;
      wrapperPlaceholderFrame = window.requestAnimationFrame(
        measurePendingWrapperPlaceholderPosition,
      );
    };
    const syncPendingWrapperPlaceholder = () => {
      const showPlaceholder = Boolean(pendingWrapperInput);
      host.classList.toggle("has-pending-wrapper-placeholder", showPlaceholder);
      if (showPlaceholder && pendingWrapperInput) {
        host.dataset.pendingWrapperCommand = pendingWrapperInput.command;
        host.dataset.pendingWrapperLength = String(
          Array.from(pendingWrapperInput.content).length,
        );
      } else {
        delete host.dataset.pendingWrapperCommand;
        delete host.dataset.pendingWrapperLength;
      }
      schedulePendingWrapperPlaceholderPosition();
    };
    const clearPendingWrapperInput = () => {
      pendingWrapperInput = null;
      delete field.dataset.pendingWrapperCommand;
      syncPendingWrapperPlaceholder();
    };
    const applyPendingWrapperParentAutoExit = (
      pending: NonNullable<typeof pendingWrapperInput>,
    ) => {
      const setting = pending.parentAutoExitSetting;
      if (!setting || !propsRef.current.inputBehavior[setting]) return false;
      return moveCaretThroughEnabledAutoExitContainers(
        field,
        propsRef.current.inputBehavior,
        setting,
        pending.parentAutoExitScriptKey,
      );
    };
    const replacePendingWrapperInput = (
      command: string,
      content: string,
      trailingInput = "",
    ) => {
      const pending = pendingWrapperInput;
      if (!pending) return false;

      const [rangeStart, rangeEnd] = pending.range;
      field.mode = "math";
      field.selection = {
        ranges: [[rangeStart, rangeEnd]],
        direction: "forward",
      };
      replacingPendingWrapperInput = true;
      let inserted = false;
      try {
        inserted = field.insert(
          command + "{" + content + "}" + trailingInput,
          {
            mode: "math",
            format: "latex",
            insertionMode: "replaceSelection",
            selectionMode: "after",
            focus: true,
            scrollIntoView: false,
          },
        );
      } finally {
        replacingPendingWrapperInput = false;
      }
      if (!inserted) return false;

      field.applyStyle(pending.anchorStyle);
      pending.command = command;
      pending.content = content;
      if (!trailingInput) pending.range = [rangeStart, field.position];
      return true;
    };
    let compositionDeleteObserved = false;
    let suppressPostCompositionDeleteUntil = 0;

    const armPhysicalBackslashGuard = (
      kind: PhysicalBackslashInputKind,
      timeStamp: number,
    ) => {
      physicalBackslashGuard = {
        kind,
        beforeValue: field.value,
        expiresAt: timeStamp + 240,
        acceptedInput: false,
      };
      window.clearTimeout(backslashGuardTimer);
      const expectedGuard = physicalBackslashGuard;
      backslashGuardTimer = window.setTimeout(() => {
        if (physicalBackslashGuard === expectedGuard) {
          physicalBackslashGuard = null;
        }
      }, 280);
    };

    const normalizeGuardedBackslashInput = (timeStamp: number) => {
      const guard = physicalBackslashGuard;
      if (!guard || timeStamp > guard.expiresAt) {
        physicalBackslashGuard = null;
        return;
      }

      const activeRawInput = rawLatexInput(field);
      if (
        guard.kind === "latin-backslash" &&
        activeRawInput.length > 1 &&
        /^\\+$/.test(activeRawInput)
      ) {
        // Some WebKit/IME transitions apply the same physical Backslash more
        // than once directly to MathLive's raw-LaTeX DOM. The public field
        // value is still unchanged in raw mode, so normalize that DOM through
        // MathLive commands rather than rebuilding the formula snapshot.
        restoringRawCommandAnchor = true;
        try {
          for (let index = 1; index < activeRawInput.length; index += 1) {
            field.executeCommand("deleteBackward");
          }
        } finally {
          restoringRawCommandAnchor = false;
        }
        // Chromium can emit more than one `char` event for the same physical
        // Backslash after the first duplicate has already been normalized.
        // Keep this guard alive until its original deadline so any trailing
        // event from the same key transaction is normalized as well.
        guard.acceptedInput = true;
        suppressUnarmedBackslashInputUntil = Math.max(
          suppressUnarmedBackslashInputUntil,
          timeStamp + 180,
        );
        return;
      }

      const rawValue = field.value;
      const normalizedValue = normalizePhysicalBackslashInput(
        guard.beforeValue,
        rawValue,
        guard.kind,
      );
      if (normalizedValue === rawValue) return;

      const previousPosition = field.position;
      const removedCharacters = rawValue.length - normalizedValue.length;
      field.setValue(normalizedValue, {
        mode: "math",
        format: "latex",
        insertionMode: "replaceAll",
        selectionMode: "after",
        silenceNotifications: true,
      });
      const correctedPosition = Math.max(
        0,
        Math.min(field.lastOffset, previousPosition - removedCharacters),
      );
      field.position = correctedPosition;
      field.selection = {
        ranges: [[correctedPosition, correctedPosition]],
        direction: "none",
      };
      physicalBackslashGuard = null;
    };

    const emitEdit = (
      before: ReturnType<typeof captureFieldSnapshot>,
      after: ReturnType<typeof captureFieldSnapshot>,
      editKind: EditKind,
      source: FormulaEditSource,
    ) => {
      lastSnapshotRef.current = after;
      if (before.latex === after.latex) return;
      propsRef.current.onEdit(
        {
          lineId,
          beforeLatex: before.latex,
          afterLatex: after.latex,
          beforeSelection: before.selection,
          afterSelection: after.selection,
          editKind,
          source,
        },
        field,
      );
      field.resetUndo();
    };
    const handleCompositionStart = () => {
      compositionDeleteObserved = false;
      suppressPostCompositionDeleteUntil = 0;
      physicalBackslashGuard = null;
      suppressUnarmedBackslashInputUntil = 0;
      window.clearTimeout(backslashGuardTimer);
      capturePendingAutoExit();
      propsRef.current.onCommitPending();
      imeGuard.compositionStart();
      const liveCompositionStart = captureFieldSnapshot(field);
      compositionStartRef.current = liveCompositionStart;
      structuredCompositionAnchorRef.current =
        captureStructuredCompositionAnchor(field, liveCompositionStart);
    };
    const applyPendingPackageMacroInput = (
      event: Event,
      nextContent: string,
    ) => {
      const pending = pendingPackageMacroInput;
      if (!pending) return false;
      const replacement = nextContent || "\\placeholder{}";
      const nextLatex =
        pending.sourcePrefix + replacement + pending.sourceSuffix;

      event.preventDefault();
      event.stopImmediatePropagation();
      const before = captureFieldSnapshot(field);
      field.setValue(nextLatex, {
        mode: "math",
        format: "latex",
        insertionMode: "replaceAll",
        selectionMode: "after",
        silenceNotifications: true,
      });
      pending.content = nextContent;
      if (nextContent) {
        const position = Math.max(
          0,
          Math.min(
            field.lastOffset,
            pending.modelStart + Array.from(nextContent).length,
          ),
        );
        field.position = position;
        field.selection = {
          ranges: [[position, position]],
          direction: "none",
        };
      } else {
        const placeholderRange = modelRangeForTextualPlaceholder(
          field,
          nextLatex,
          pending.placeholderIndex,
        );
        if (placeholderRange) {
          field.selection = {
            ranges: [placeholderRange],
            direction: "none",
          };
          field.position = placeholderRange[1];
        } else {
          selectFirstLatexPlaceholder(field, `\\${pending.macroName}`);
        }
      }
      markVisualTexStructuralPlaceholders(field);
      field.focus();
      field.shadowRoot
        ?.querySelector<HTMLElement>('[part="keyboard-sink"]')
        ?.focus({ preventScroll: true });
      const after = captureFieldSnapshot(field);
      emitEdit(before, after, "insert", "keyboard");
      propsRef.current.onInputActivity(field);
      syncFrameSize();
      return true;
    };
    const replaceSelectedPackageMacroPlaceholder = (
      event: Event,
      replacement: string,
    ) => {
      let packagePlaceholder = selectedPackageMacroPlaceholder(field);
      if (!packagePlaceholder) {
        const macroName = field.dataset.toolbarPackageMacroName ?? "";
        const placeholderIndex = Number.parseInt(
          field.dataset.toolbarPackageMacroPlaceholderIndex ?? "",
          10,
        );
        const modelStart = Number.parseInt(
          field.dataset.toolbarPackageMacroModelStart ?? "",
          10,
        );
        const latex = normalizeChineseLatex(field.value);
        if (
          macroName &&
          Number.isInteger(placeholderIndex) &&
          placeholderIndex >= 0 &&
          Number.isInteger(modelStart) &&
          modelStart >= 0 &&
          packageMacroForTextualPlaceholder(latex, placeholderIndex) === macroName
        ) {
          packagePlaceholder = {
            latex,
            placeholderIndex,
            range: [modelStart, modelStart + 1],
            macroName,
          };
        }
      }
      if (!packagePlaceholder || !replacement) return false;
      const placeholderParts = splitTextualPlaceholder(
        packagePlaceholder.latex,
        packagePlaceholder.placeholderIndex,
      );
      if (!placeholderParts) return false;
      pendingPackageMacroInput = {
        macroName: packagePlaceholder.macroName,
        placeholderIndex: packagePlaceholder.placeholderIndex,
        sourcePrefix: placeholderParts.prefix,
        sourceSuffix: placeholderParts.suffix,
        content: "",
        modelStart: packagePlaceholder.range[0],
      };
      clearToolbarPackageMacroHint(field);
      if (applyPendingPackageMacroInput(event, replacement)) return true;
      clearPendingPackageMacroInput();
      return false;
    };
    const handleCompositionEnd = (event: CompositionEvent) => {
      const cancelledByCompositionDelete =
        event.data === "" && compositionDeleteObserved;
      const before =
        compositionStartRef.current ??
        lastSnapshotRef.current ??
        captureFieldSnapshot(field);
      const structuredAnchor = structuredCompositionAnchorRef.current;
      if (event.data !== "" && structuredAnchor) {
        restoreStructuredCompositionPlaceholder(
          field,
          structuredAnchor,
          event.data,
        );
      }
      imeGuard.compositionEnd(event.timeStamp);
      suppressPostCompositionDeleteUntil = cancelledByCompositionDelete
        ? event.timeStamp + 160
        : 0;
      suppressUnarmedBackslashInputUntil =
        event.data === "" ? event.timeStamp + 260 : 0;
      compositionDeleteObserved = false;
      normalizeGuardedBackslashInput(event.timeStamp);

      // Cancelling an uncommitted macOS IME candidate with Backspace can make
      // WKWebView/MathLive apply the same physical key to the confirmed formula.
      // The composition contains no committed text in this case, so restore the
      // exact pre-composition formula and selection instead of recording a delete.
      if (event.data === "" && field.value !== before.latex) {
        field.setValue(before.latex, {
          mode: "math",
          format: "latex",
          insertionMode: "replaceAll",
          selectionMode: "after",
          silenceNotifications: true,
        });
        const restored = clampSelection(before.selection, field.lastOffset);
        field.selection = restored;
        const restoredRange = restored.ranges.at(-1);
        if (restoredRange) field.position = restoredRange[1];
        field.resetUndo();
        lastSnapshotRef.current = captureFieldSnapshot(field);
        clearPendingAutoExit();
        compositionStartRef.current = null;
        structuredCompositionAnchorRef.current = null;
        syncFrameSize();
        return;
      }

      let after = captureFieldSnapshot(field);
      if (pendingAutoExitSetting && before.latex !== after.latex) {
        moveCaretThroughEnabledAutoExitContainers(
          field,
          propsRef.current.inputBehavior,
          pendingAutoExitSetting,
          pendingAutoExitScriptKey,
        );
        after = captureFieldSnapshot(field);
      }
      clearPendingAutoExit();
      compositionStartRef.current = null;
      structuredCompositionAnchorRef.current = null;
      emitEdit(before, after, "composition", "keyboard");
      syncFrameSize();
    };
  const handleBeforeInput = (event: InputEvent) => {
    if (restoringRawCommandAnchor) return;
    const selectedAccentState = captureSelectedAccentPlaceholderState(field);
    if (selectedAccentState) {
      activateVisualTexAccentPlaceholder(field, selectedAccentState);
      if (
        !event.isComposing &&
        event.inputType === "insertText" &&
        event.data &&
        Array.from(event.data).length === 1
      ) {
        armSelectedAccentAutoExit(selectedAccentState);
      }
    }
      if (
        !pendingWrapperInput &&
        !event.isComposing &&
        event.inputType === "insertText" &&
        event.data &&
        replaceSelectedPackageMacroPlaceholder(event, event.data)
      ) {
        return;
      }
      if (
        event.inputType === "deleteContentBackward" &&
        !pendingWrapperInput &&
        Boolean(rawCommandAnchors.get(field))
      ) {
        const anchor = rawCommandAnchors.get(field);
        const rawInput = rawLatexInput(field);
        if (anchor && Array.from(rawInput).length <= 1) {
          event.preventDefault();
          event.stopImmediatePropagation();
          const before = captureFieldSnapshot(field);
          restoringRawCommandAnchor = true;
          try {
            restoreCancelledRawCommandAnchor(field, anchor);
          } finally {
            restoringRawCommandAnchor = false;
          }
          rawCommandAnchors.delete(field);
          markVisualTexStructuralPlaceholders(field);
          const after = captureFieldSnapshot(field);
          emitEdit(before, after, "delete-backward", "keyboard");
          propsRef.current.onInputActivity(field);
          syncFrameSize();
          return;
        }
      }
      if (
        pendingWrapperInput &&
        !replacingPendingWrapperInput &&
        !event.isComposing
      ) {
        if (event.inputType === "insertText" && event.data !== null) {
          event.preventDefault();
          event.stopImmediatePropagation();
          const before = captureFieldSnapshot(field);
          const inputCharacters = Array.from(event.data);
          const pending = pendingWrapperInput;
          const autoExit =
            propsRef.current.inputBehavior[pending.autoExitSetting] &&
            inputCharacters.length > 0;
          const wrappedInput = autoExit
            ? inputCharacters.slice(0, 1).join("")
            : event.data;
          const trailingInput = autoExit
            ? inputCharacters.slice(1).join("")
            : "";
          const exitsParent = Boolean(
            autoExit &&
              pending.parentAutoExitSetting &&
              propsRef.current.inputBehavior[pending.parentAutoExitSetting],
          );
          const nextCommand =
            pending.command === "\\mathcal" &&
            pending.content.length === 0 &&
            /^[a-z]$/.test(wrappedInput)
              ? "\\mathscr"
              : pending.command;
          const nextContent = pending.content + wrappedInput;
          if (
            !replacePendingWrapperInput(
              nextCommand,
              nextContent,
              exitsParent ? "" : trailingInput,
            )
          ) {
            return;
          }
          field.dataset.pendingWrapperCommand = nextCommand;
          syncPendingWrapperPlaceholder();
          field.focus();
          if (autoExit) {
            clearPendingWrapperInput();
            if (exitsParent) {
              applyPendingWrapperParentAutoExit(pending);
              if (trailingInput) {
                replacingPendingWrapperInput = true;
                try {
                  field.insert(trailingInput, {
                    mode: "math",
                    format: "latex",
                    insertionMode: "insertAfter",
                    selectionMode: "after",
                    focus: true,
                    scrollIntoView: false,
                  });
                } finally {
                  replacingPendingWrapperInput = false;
                }
              }
            }
          }
          field.shadowRoot
            ?.querySelector<HTMLElement>('[part="keyboard-sink"]')
            ?.focus({ preventScroll: true });
          const after = captureFieldSnapshot(field);
          emitEdit(before, after, "insert", "keyboard");
          syncFrameSize();
          return;
        }
        if (event.inputType === "deleteContentBackward") {
          if (pendingWrapperInput.content) {
            event.preventDefault();
            event.stopImmediatePropagation();
            const before = captureFieldSnapshot(field);
            const nextContent = Array.from(pendingWrapperInput.content)
              .slice(0, -1)
              .join("");
            if (
              !replacePendingWrapperInput(
                pendingWrapperInput.command,
                nextContent,
              )
            ) {
              return;
            }
            syncPendingWrapperPlaceholder();
            field.focus();
            const after = captureFieldSnapshot(field);
            emitEdit(before, after, "delete-backward", "keyboard");
            syncFrameSize();
            return;
          }
          clearPendingWrapperInput();
        }
      }
      if (
        event.inputType === "deleteContentBackward" &&
        event.timeStamp <= suppressPostCompositionDeleteUntil
      ) {
        suppressPostCompositionDeleteUntil = 0;
        event.preventDefault();
        event.stopImmediatePropagation();
        return;
      }
      if (!event.isComposing && !imeGuard.isComposing()) {
        if (isSingleDirectInput(event, field)) {
          // Keep the script type captured during keydown when WebKit's
          // beforeinput geometry is temporarily incomplete. A non-null
          // beforeinput result may refine it, but null must not erase it.
          const nextSetting = getCaretAutoExitSetting(field);
          if (nextSetting) {
            pendingAutoExitSetting = nextSetting;
            if (
              nextSetting === "autoExitSuperscript" ||
              nextSetting === "autoExitSubscript"
            ) {
              pendingAutoExitScriptKey =
                getScriptCaretContext(field)?.autoExitKey ??
                pendingAutoExitScriptKey;
            }
          }
        } else {
          clearPendingAutoExit();
        }
      }
      if (event.data === "\\") {
        const guard = physicalBackslashGuard;
        const guardedLatinInput = Boolean(
          guard &&
            guard.kind === "latin-backslash" &&
            event.timeStamp <= guard.expiresAt,
        );
        if (guardedLatinInput && guard) {
          if (guard.acceptedInput) {
            clearPendingAutoExit();
            event.preventDefault();
            event.stopImmediatePropagation();
            return;
          }
          guard.acceptedInput = true;
          suppressUnarmedBackslashInputUntil = 0;
        } else if (
          event.timeStamp <= suppressBackslashKeyReplayUntil ||
          event.timeStamp <= suppressUnarmedBackslashInputUntil
        ) {
          clearPendingAutoExit();
          event.preventDefault();
          event.stopImmediatePropagation();
          return;
        }
      }
    };
  const handleInput = (event: Event) => {
    if (
      replacingPendingWrapperInput ||
      restoringRawCommandAnchor ||
      visualTexRestoringPlaceholderFields.has(field)
    ) {
      return;
    }
      if (imeGuard.isComposing()) {
        if (
          event instanceof InputEvent &&
          event.inputType === "deleteCompositionText"
        ) {
          compositionDeleteObserved = true;
        }
        return;
      }
      normalizeGuardedBackslashInput(event.timeStamp);
      nativeInputPopoverActiveField = field;
      scheduleStableNativeInputPopoverSync();
      const before = lastSnapshotRef.current ?? captureFieldSnapshot(field);
      const directInputSetting =
        event instanceof InputEvent && isSingleDirectInput(event, field)
          ? getCaretAutoExitSetting(field)
          : null;
      const directInputScriptKey =
        directInputSetting === "autoExitSuperscript" ||
        directInputSetting === "autoExitSubscript"
          ? getScriptCaretContext(field)?.autoExitKey ?? null
          : null;
      const autoExitSetting = pendingAutoExitSetting ?? directInputSetting;
      const autoExitScriptKey =
        pendingAutoExitScriptKey ?? directInputScriptKey;
      const capturedAccentAutoExit = pendingAccentAutoExit;
      const shouldRetryDirectAutoExit =
        event instanceof InputEvent && isSingleDirectInput(event, field);
      let autoExitMoved = false;
      if (
        autoExitSetting &&
        propsRef.current.inputBehavior[autoExitSetting]
      ) {
        if (!(autoExitSetting === "autoExitAccent" && capturedAccentAutoExit)) {
          autoExitMoved = moveCaretThroughEnabledAutoExitContainers(
            field,
            propsRef.current.inputBehavior,
            autoExitSetting,
            autoExitScriptKey,
          );
        }
      }
      clearPendingAutoExit();
    normalizeCompletedDifferentialDisplay(field);
    const inputType =
      event instanceof InputEvent ? event.inputType || "insertText" : "insertText";
    let postInputSnapshot = captureFieldSnapshot(field);
    observeVisualTexActiveAccentPlaceholder(field);
    if (inputType.startsWith("delete")) {
      const restoredPlaceholder = restoreDeletedVisualTexPlaceholder(field);
      settleVisualTexAccentPlaceholderDelete(field);
      settleVisualTexPlaceholderDelete(field);
      if (restoredPlaceholder) {
        postInputSnapshot = captureFieldSnapshot(field);
      }
    }
    const after = postInputSnapshot;
      emitEdit(
        before,
        after,
        inferEditKind(inputType, before.selection),
        inferEditSource(inputType),
      );
      propsRef.current.onInputActivity(field);
      syncFrameSize();
      window.requestAnimationFrame(() => {
        if (!field.isConnected) return;
        const deferredBefore =
          lastSnapshotRef.current ?? captureFieldSnapshot(field);
        if (!autoExitMoved && shouldRetryDirectAutoExit) {
          const deferredSetting =
            autoExitSetting ?? getCaretAutoExitSetting(field);
          const deferredScriptKey =
            autoExitScriptKey ?? getScriptCaretContext(field)?.autoExitKey ?? null;
          if (
            deferredSetting &&
            propsRef.current.inputBehavior[deferredSetting]
          ) {
            autoExitMoved =
              deferredSetting === "autoExitAccent" && capturedAccentAutoExit
                ? moveCaretAfterCapturedAccent(field, capturedAccentAutoExit)
                : moveCaretThroughEnabledAutoExitContainers(
                    field,
                    propsRef.current.inputBehavior,
                    deferredSetting,
                    deferredScriptKey,
                  );
          }
        }
        if (
          normalizeCompletedDifferentialDisplay(field) || autoExitMoved
        ) {
          emitEdit(
            deferredBefore,
            captureFieldSnapshot(field),
            "replace",
            "keyboard",
          );
        }
        if (
          !autoExitMoved &&
          autoExitSetting === "autoExitAccent" &&
          capturedAccentAutoExit &&
          propsRef.current.inputBehavior.autoExitAccent
        ) {
          window.requestAnimationFrame(() => {
            if (!field.isConnected) return;
            const retryBefore =
              lastSnapshotRef.current ?? captureFieldSnapshot(field);
            const retryMoved = moveCaretAfterCapturedAccent(
              field,
              capturedAccentAutoExit,
            );
            if (retryMoved) {
              emitEdit(
                retryBefore,
                captureFieldSnapshot(field),
                "replace",
                "keyboard",
              );
              propsRef.current.onInputActivity(field);
            }
          });
        }
        propsRef.current.onInputActivity(field);
        decorateNativeSuggestionPreviews();
      });
    };
    const handleSelectionChange = () => {
      markVisualTexStructuralPlaceholders(field);
      syncPostOperatorCaretSpacing(field);
      const selectedAccentState = captureSelectedAccentPlaceholderState(field);
      if (selectedAccentState) {
        activateVisualTexAccentPlaceholder(field, selectedAccentState);
      }
      observeVisualTexActiveAccentPlaceholder(field);
      schedulePointerPlaceholderSnapshotStyle();
      syncFrameSize();
      const selection = captureSelection(field);
      propsRef.current.onSelectionChange(lineId, selection);
      if (imeGuard.isComposing() || !lastSnapshotRef.current) return;
      previousSelectionSnapshotRef.current = lastSnapshotRef.current;
      lastSelectionChangeAtRef.current = performance.now();
      lastSnapshotRef.current = {
        ...lastSnapshotRef.current,
        selection,
      };
    };
    const handleFocus = () => {
      if (field.classList.contains(visualTexSourcePreviewClass)) {
        field.blur();
        queueMicrotask(() => {
          document
            .querySelector<HTMLElement>(".source-panel .cm-content")
            ?.focus({ preventScroll: true });
        });
        return;
      }
      nativeInputPopoverActiveField = field;
      scheduleStableNativeInputPopoverSync();
      propsRef.current.onFocus(propsRef.current.index, field);
      lastSnapshotRef.current = captureFieldSnapshot(field);
    };
    const handleBlur = () => {
      clearPendingWrapperInput();
      clearPendingPackageMacroInput();
      rawCommandAnchors.delete(field);
      if (nativeInputPopoverActiveField === field) {
        nativeInputPopoverActiveField = null;
        scheduleStableNativeInputPopoverSync();
      }
      propsRef.current.onCommitPending();
    };
    const confirmPendingWrapperInput = (event: KeyboardEvent) => {
      if (
        !pendingWrapperInput ||
        event.isComposing ||
        event.metaKey ||
        event.ctrlKey ||
        event.altKey ||
        event.key !== "Enter"
      ) {
        return false;
      }

      event.preventDefault();
      event.stopImmediatePropagation();
      const pending = pendingWrapperInput;
      const confirmedPosition = field.position;
      const exitsParent = pending.content.length > 0;
      clearPendingWrapperInput();
      field.mode = "math";
      field.selection = {
        ranges: [[confirmedPosition, confirmedPosition]],
        direction: "none",
      };
      field.position = confirmedPosition;
      if (exitsParent) applyPendingWrapperParentAutoExit(pending);
      field.focus();
      field.shadowRoot
        ?.querySelector<HTMLElement>('[part="keyboard-sink"]')
        ?.focus({ preventScroll: true });
      propsRef.current.onCommitPending();
      syncFrameSize();
      return true;
    };
    const confirmRawPlaceholderCommand = (event: KeyboardEvent) => {
      if (
        pendingWrapperInput ||
        event.isComposing ||
        event.metaKey ||
        event.ctrlKey ||
        event.altKey ||
        !(
          event.key === "Enter" ||
          event.key === "Tab" ||
          event.key === " " ||
          event.code === "Space"
        )
      ) {
        return false;
      }

      const rawQuery = rawCommandQuery(field) || trailingCommandQuery(field);
      const selectedNativeCommand =
        field.dataset.pendingNativeSuggestion ||
        getVisibleNativeSuggestionItems(field).find((item) =>
          item.classList.contains("ML__popover__current"),
        )?.dataset.command ||
        "";
      // Keep Windows' synthetic cases environment on the native candidate
      // commit path while the user is still typing a prefix. That path records
      // candidate usage, so subsequent \\b / \\be / \\beg pools preserve the
      // existing frequency-ranking behavior. Other compatibility structures
      // can use the prefix-aware placeholder path below.
      if (
        selectedNativeCommand === CASES_ENVIRONMENT_COMMAND &&
        rawQuery !== CASES_ENVIRONMENT_COMMAND
      ) {
        return false;
      }
      const exactRawTemplate = rawQuery
        ? exactRawPlaceholderTemplate(rawQuery)
        : null;
      const selectedMatchesRawQuery = Boolean(
        selectedNativeCommand &&
          (!rawQuery || selectedNativeCommand.startsWith(rawQuery)),
      );
      const placeholderCommand = exactRawTemplate
        ? rawQuery
        : selectedMatchesRawQuery
          ? selectedNativeCommand
          : "";
      const placeholderTemplate =
        exactRawTemplate ??
        (placeholderCommand
          ? exactRawPlaceholderTemplate(placeholderCommand)
          : null);
      if (!placeholderCommand || !placeholderTemplate) return false;

      const anchor = rawCommandAnchors.get(field);
      const rawInput = rawLatexInput(field).trim();
      const queryRange = rawInput
        ? findTrailingCommandRange(field, rawInput)
        : null;
      if (!anchor && !queryRange && field.mode !== "latex") return false;

      event.preventDefault();
      event.stopImmediatePropagation();
      clearPendingAutoExit();
      if (anchor?.selectedPlaceholder) {
        const before = {
          latex: anchor.latex,
          selection: anchor.selection,
        };
        clearVisualTexPlaceholderRestoreState(field);
        let accepted = field.executeCommand([
          "complete",
          "accept-suggestion",
        ]);
        if (rawLatexInput(field)) {
          accepted =
            field.executeCommand(["complete", "accept-all"]) || accepted;
        }
        if (!accepted || rawLatexInput(field)) return false;
        const placeholderTextIndex = anchor.selectedPlaceholderTextIndex;
        if (placeholderTextIndex === null) return false;
        const restoredLatex = replaceTextualPlaceholder(
          anchor.latex,
          placeholderTextIndex,
          placeholderTemplate,
        );
        if (!restoredLatex) return false;
        field.setValue(restoredLatex, {
          mode: "math",
          format: "latex",
          insertionMode: "replaceAll",
          selectionMode: "after",
          silenceNotifications: true,
        });
        const placeholderRanges = latexPlaceholderRanges(field);
        const insertedPlaceholderCount =
          placeholderTemplate.match(/\\placeholder\{\}/g)?.length ?? 0;
        const basePlaceholderIndex = anchor.selectedPlaceholderIndex;
        const selectedModelIndex =
          basePlaceholderIndex === null
            ? null
            : basePlaceholderIndex +
              (reverseModelPlaceholderOrderCommands.has(placeholderCommand)
                ? Math.max(0, insertedPlaceholderCount - 1)
                : 0);
        const selectedRange =
          selectedModelIndex === null
            ? null
            : placeholderRanges[selectedModelIndex] ?? null;
        window.requestAnimationFrame(() => {
          if (!field.isConnected) return;
          if (selectedRange) {
            field.selection = {
              ranges: [selectedRange],
              direction: "none",
            };
          }
          if (
            !selectedRange ||
            hasBoundedOperatorPlaceholderOrder(placeholderTemplate)
          ) {
            selectFirstLatexPlaceholder(
              field,
              placeholderCommand,
              placeholderTemplate,
            );
          }
          markVisualTexStructuralPlaceholders(field);
          field.focus();
          field.shadowRoot
            ?.querySelector<HTMLElement>('[part="keyboard-sink"]')
            ?.focus({ preventScroll: true });
          syncFrameSize();
        });
        rawCommandAnchors.delete(field);
        delete field.dataset.pendingNativeSuggestion;
        dismissNativeSuggestionPopover(field);
        markVisualTexStructuralPlaceholders(field);
        field.focus();
        field.shadowRoot
          ?.querySelector<HTMLElement>('[part="keyboard-sink"]')
          ?.focus({ preventScroll: true });
        const after = captureFieldSnapshot(field);
        emitEdit(before, after, "replace", "candidate");
        propsRef.current.onInputActivity(field);
        syncFrameSize();
        return true;
      }
      if (anchor) {
        restoreRawCommandInsertionAnchor(field, anchor);
      } else {
        field.mode = "math";
        if (queryRange) {
          field.selection = {
            ranges: [queryRange],
            direction: "forward",
          };
        }
      }
      const before = captureFieldSnapshot(field);
      const inserted = field.insert(placeholderTemplate, {
        mode: "math",
        format: "latex",
        insertionMode: "replaceSelection",
        selectionMode: "placeholder",
        focus: true,
        scrollIntoView: false,
      });
      if (!inserted) return false;
      selectFirstLatexPlaceholder(
        field,
        placeholderCommand,
        placeholderTemplate,
      );

      rawCommandAnchors.delete(field);
      delete field.dataset.pendingNativeSuggestion;
      dismissNativeSuggestionPopover(field);
      markVisualTexStructuralPlaceholders(field);
      field.focus();
      field.shadowRoot
        ?.querySelector<HTMLElement>('[part="keyboard-sink"]')
        ?.focus({ preventScroll: true });
      const after = captureFieldSnapshot(field);
      emitEdit(before, after, "replace", "candidate");
      propsRef.current.onInputActivity(field);
      syncFrameSize();
      return true;
    };
    const confirmRawWrapperCommand = (event: KeyboardEvent) => {
      if (
        pendingWrapperInput ||
        event.isComposing ||
        event.metaKey ||
        event.ctrlKey ||
        event.altKey ||
        !(
          event.key === "Enter" ||
          event.key === "Tab" ||
          event.key === " " ||
          event.code === "Space"
        )
      ) {
        return false;
      }

      const wrapperQuery = rawCommandQuery(field) || trailingCommandQuery(field);
      const selectedNativeCommand =
        field.dataset.pendingNativeSuggestion ||
        getVisibleNativeSuggestionItems(field).find((item) =>
          item.classList.contains("ML__popover__current"),
        )?.dataset.command ||
        "";
      const wrapperCommand =
        (wrapperQuery ? exactWrapperCommand(wrapperQuery) : null) ??
        (selectedNativeCommand
          ? exactWrapperCommand(selectedNativeCommand)
          : null);
      if (
        !wrapperCommand ||
        (field.mode !== "latex" && field.lastOffset !== 0)
      ) {
        return false;
      }
      const wrapperOutputCommand =
        compatibilityWrapperCanonicalTargets.get(wrapperCommand.command) ??
        wrapperCommand.command;

      event.preventDefault();
      event.stopImmediatePropagation();
      clearPendingAutoExit();
      const before = captureFieldSnapshot(field);
      const anchor = rawCommandAnchors.get(field) ?? {
        latex: before.latex,
        selection: before.selection,
        position: field.position,
        visualCaret: captureWrapperCaretAnchor(field),
        selectedPlaceholder: false,
        selectedPlaceholderIndex: null,
        selectedPlaceholderTextIndex: null,
        verticalPlaceholder: null,
        autoExitSetting: null,
        autoExitScriptKey: null,
      };
      let anchorSelection: MathSelectionSnapshot;
      let replaceAcceptedWrapper = false;
      if (anchor.selectedPlaceholder) {
        clearVisualTexPlaceholderRestoreState(field);
        field.executeCommand(["complete", "reject"]);
        field.mode = "math";
        const insertionStart = field.position;
        const insertedWrapper = field.insert(`${wrapperOutputCommand}{}`, {
          mode: "math",
          format: "latex",
          insertionMode: "replaceSelection",
          selectionMode: "after",
          focus: true,
          scrollIntoView: false,
        });
        if (!insertedWrapper) return false;
        anchorSelection = {
          ranges: [[insertionStart, field.position]],
          direction: "none",
        };
        replaceAcceptedWrapper = true;
      } else {
        anchorSelection = restoreRawCommandAnchor(field, anchor);
      }
      const anchorRange = anchorSelection.ranges.at(-1) ?? [anchor.position, anchor.position];
      const rangeStart = Math.min(anchorRange[0], anchorRange[1]);
      const rangeEnd = replaceAcceptedWrapper
        ? Math.max(anchorRange[0], anchorRange[1])
        : rangeStart;
      rawCommandAnchors.delete(field);
      delete field.dataset.pendingNativeSuggestion;
      const styleAtAnchor =
        field.getElementInfo(rangeStart)?.style ??
        field.getElementInfo(Math.max(0, rangeStart - 1))?.style ??
        {};
      const anchorStyle: Readonly<Style> = {
        variant: styleAtAnchor.variant ?? "normal",
        variantStyle: styleAtAnchor.variantStyle ?? "",
        fontFamily: styleAtAnchor.fontFamily ?? "none",
        fontShape: styleAtAnchor.fontShape ?? "",
        fontSeries: styleAtAnchor.fontSeries ?? "",
      };
      pendingWrapperInput = {
        command: wrapperOutputCommand,
        content: "",
        range: [rangeStart, rangeEnd],
        anchorStyle,
        visualCaret: anchor.visualCaret,
        autoExitSetting: "autoExitWrapperCommand",
        parentAutoExitSetting: anchor.selectedPlaceholder
          ? anchor.autoExitSetting
          : null,
        parentAutoExitScriptKey: anchor.selectedPlaceholder
          ? anchor.autoExitScriptKey
          : null,
      };
      field.dataset.pendingWrapperCommand = wrapperOutputCommand;
      field.focus();
      field.shadowRoot
        ?.querySelector<HTMLElement>('[part="keyboard-sink"]')
        ?.focus({ preventScroll: true });
      const pendingReference = pendingWrapperInput;
      window.requestAnimationFrame(() => {
        window.requestAnimationFrame(() => {
          if (
            !field.isConnected ||
            !pendingReference ||
            pendingWrapperInput !== pendingReference
          ) {
            return;
          }
          if (!pendingReference.visualCaret) {
            pendingReference.visualCaret = captureWrapperCaretAnchor(field);
          }
          syncPendingWrapperPlaceholder();
        });
      });
      const after = captureFieldSnapshot(field);
      emitEdit(before, after, "replace", "candidate");
      syncFrameSize();
      return true;
  };
    const confirmRawNativeCommand = (event: KeyboardEvent) => {
      if (
        pendingWrapperInput ||
        event.isComposing ||
        event.metaKey ||
        event.ctrlKey ||
        event.altKey ||
        !(
          event.key === "Enter" ||
          event.key === "Tab" ||
          event.key === " " ||
          event.code === "Space"
        )
      ) {
        return false;
      }

      const rawQuery = rawCommandQuery(field);
      if (!rawQuery) return false;
      const selectedNativeCommand =
        field.dataset.pendingNativeSuggestion ||
        getVisibleNativeSuggestionItems(field).find((item) =>
          item.classList.contains("ML__popover__current"),
        )?.dataset.command ||
        "";
      // A raw query such as `\\bet` is only a prefix. Commit the complete
      // command selected by MathLive (for example `\\beta`), not the prefix
      // itself. If the native list has no selected item, let MathLive handle
      // the key instead of turning an incomplete query into an error atom.
      if (!selectedNativeCommand) return false;

      event.preventDefault();
      event.stopImmediatePropagation();
      clearPendingAutoExit();
      const before = captureFieldSnapshot(field);
      const committed = commitNativeSuggestion(
        field,
        propsRef.current.inputBehavior,
        selectedNativeCommand,
      );
      if (!committed) return false;

      delete field.dataset.pendingNativeSuggestion;
      markVisualTexStructuralPlaceholders(field);
      field.focus();
      field.shadowRoot
        ?.querySelector<HTMLElement>('[part="keyboard-sink"]')
        ?.focus({ preventScroll: true });
      const after = captureFieldSnapshot(field);
      emitEdit(before, after, "replace", "candidate");
      propsRef.current.onInputActivity(field);
      syncFrameSize();
      return true;
    };
  const moveWithinCustomVerticalStructureFromRecentSelection = (
    direction: "up" | "down",
  ) => {
    const currentLatex = normalizeChineseLatex(field.value);
    const recentNativeSelectionChange =
      performance.now() - lastSelectionChangeAtRef.current <= 250;
    const candidateOffsets: number[] = [];
    const pushSelectionOffset = (selection: MathSelectionSnapshot | null) => {
      const range = selection?.ranges.at(-1);
      if (!range) return;
      const offset = Math.max(0, Math.min(field.lastOffset, range[1]));
      if (!candidateOffsets.includes(offset)) candidateOffsets.push(offset);
    };

    pushSelectionOffset(captureSelection(field));
    if (lastSnapshotRef.current?.latex === currentLatex) {
      pushSelectionOffset(lastSnapshotRef.current.selection);
    }
    if (
      recentNativeSelectionChange &&
      previousSelectionSnapshotRef.current?.latex === currentLatex
    ) {
      pushSelectionOffset(previousSelectionSnapshotRef.current.selection);
    }

    return candidateOffsets.some((offset) =>
      moveWithinCustomVerticalStructure(field, direction, offset),
    );
  };
  const handleRawWrapperKeyDown = (event: KeyboardEvent) => {
    const selectedAccentState = captureSelectedAccentPlaceholderState(field);
    if (selectedAccentState) {
      activateVisualTexAccentPlaceholder(field, selectedAccentState);
    }
    if (event.key === "Backspace" || event.key === "Delete") {
      armVisualTexPlaceholderRestore(field);
    }
    if (confirmPendingWrapperInput(event)) return;
      if (confirmRawPlaceholderCommand(event)) return;
      if (confirmRawWrapperCommand(event)) return;
      confirmRawNativeCommand(event);
  };
  const handleWindowRawWrapperKeyDown = (event: KeyboardEvent) => {
    if (!event.composedPath().includes(field)) return;
    const verticalStructureDirection =
      !event.defaultPrevented &&
      !event.metaKey &&
      !event.ctrlKey &&
      !event.altKey &&
      !event.shiftKey &&
      event.key === "ArrowUp"
        ? "up"
        : !event.defaultPrevented &&
            !event.metaKey &&
            !event.ctrlKey &&
            !event.altKey &&
            !event.shiftKey &&
            event.key === "ArrowDown"
          ? "down"
          : null;
    if (
      verticalStructureDirection &&
      moveWithinCustomVerticalStructureFromRecentSelection(
        verticalStructureDirection,
      )
    ) {
      event.preventDefault();
      event.stopImmediatePropagation();
      markVisualTexStructuralPlaceholders(field);
      propsRef.current.onInputActivity(field);
      return;
    }
    const selectedAccentState = captureSelectedAccentPlaceholderState(field);
    if (selectedAccentState) {
      activateVisualTexAccentPlaceholder(field, selectedAccentState);
    }
    if (event.key === "Backspace" || event.key === "Delete") {
      armVisualTexPlaceholderRestore(field);
    }
    // WebView2 can report an empty/Unidentified `code` for a real backslash
    // key even though `key` is correct. Requiring code === "Backslash" then
    // loses the insertion anchor, so accepting a candidate appends it after
    // the raw prefix (for example `\\par\\partial`) instead of replacing it.
    const isUnmodifiedBackslash =
        event.key === "\\" &&
        !event.metaKey &&
        !event.ctrlKey &&
        !event.altKey;
      if (
        isUnmodifiedBackslash &&
        !pendingWrapperInput &&
        !rawLatexInput(field)
      ) {
        rememberRawCommandAnchor(field);
      }
      if (confirmPendingWrapperInput(event)) return;
      if (confirmRawPlaceholderCommand(event)) return;
      if (confirmRawWrapperCommand(event)) return;
      // Own raw MathLive completion at the earliest capture boundary. WebView2
      // can otherwise let MathLive consume Space first, leaving the rendered
      // field at the completed command while VisualTeX only records the raw
      // prefix (for example visible \\partial with source stuck at \\par).
      // confirmRawNativeCommand() is itself restricted to raw command mode and
      // Enter/Tab/Space, so ordinary editor shortcuts still fall through.
      if (confirmRawNativeCommand(event)) return;
    };
    const scheduleInputActivity = () => {
      window.requestAnimationFrame(() => {
        if (!field.isConnected) return;
        propsRef.current.onInputActivity(field);
        decorateNativeSuggestionPreviews();
      });
    };
  const handleKeyDown = (event: KeyboardEvent) => {
    if (field.dataset.cancelPendingPackageMacroInput === "true") {
      delete field.dataset.cancelPendingPackageMacroInput;
      clearPendingPackageMacroInput();
    }
    if (
      pendingPackageMacroInput &&
      !event.isComposing &&
      !imeGuard.isComposing() &&
      !event.metaKey &&
      !event.ctrlKey &&
      !event.altKey
    ) {
      if (event.key === "Enter") {
        event.preventDefault();
        event.stopImmediatePropagation();
        clearPendingPackageMacroInput();
        propsRef.current.onCommitPending();
        return;
      }
      if (event.key === "Backspace") {
        const nextContent = Array.from(pendingPackageMacroInput.content)
          .slice(0, -1)
          .join("");
        if (applyPendingPackageMacroInput(event, nextContent)) return;
      }
      if (
        event.key !== "\\" &&
        Array.from(event.key).length === 1 &&
        /^[\x20-\x7E]$/.test(event.key)
      ) {
        const nextContent = pendingPackageMacroInput.content + event.key;
        if (applyPendingPackageMacroInput(event, nextContent)) return;
      }
      if (
        event.key === "Escape" ||
        event.key === "Tab" ||
        event.key.startsWith("Arrow") ||
        event.key === "Home" ||
        event.key === "End"
      ) {
        clearPendingPackageMacroInput();
      }
    }
    const directPackagePlaceholderCharacter =
      !pendingWrapperInput &&
      !pendingPackageMacroInput &&
      !event.isComposing &&
      !imeGuard.isComposing() &&
      !event.metaKey &&
      !event.ctrlKey &&
      !event.altKey &&
      event.key !== "\\" &&
      Array.from(event.key).length === 1 &&
      /^[\x20-\x7E]$/.test(event.key)
        ? event.key
        : "";
    if (
      directPackagePlaceholderCharacter &&
      replaceSelectedPackageMacroPlaceholder(
        event,
        directPackagePlaceholderCharacter,
      )
    ) {
      return;
    }
    const selectedAccentState = captureSelectedAccentPlaceholderState(field);
    if (selectedAccentState) {
      activateVisualTexAccentPlaceholder(field, selectedAccentState);
    }
    if (event.key === "Backspace" || event.key === "Delete") {
      armVisualTexPlaceholderRestore(field);
    }
    const isUnmodifiedPhysicalBackslash =
        event.code === "Backslash" &&
        !event.metaKey &&
        !event.ctrlKey &&
        !event.altKey;
      if (event.key === "Escape") rawCommandAnchors.delete(field);
      if (isUnmodifiedPhysicalBackslash && event.key === "、") {
        armPhysicalBackslashGuard("ideographic-comma", event.timeStamp);
        suppressBackslashKeyReplayUntil = event.timeStamp + 180;
        suppressUnarmedBackslashInputUntil = event.timeStamp + 180;
        event.preventDefault();
        event.stopPropagation();
        return;
      }
      if (isUnmodifiedPhysicalBackslash && event.key === "\\") {
        const existingGuard = physicalBackslashGuard;
        if (
          event.repeat ||
          event.timeStamp <= suppressBackslashKeyReplayUntil ||
          Boolean(existingGuard && event.timeStamp <= existingGuard.expiresAt)
        ) {
          event.preventDefault();
          event.stopImmediatePropagation();
          return;
        }
        suppressUnarmedBackslashInputUntil = 0;
        armPhysicalBackslashGuard("latin-backslash", event.timeStamp);
      }

      if (
        event.key === "Backspace" &&
        !pendingWrapperInput &&
        rawCommandAnchors.has(field) &&
        Array.from(rawLatexInput(field)).length <= 1
      ) {
        event.preventDefault();
        event.stopImmediatePropagation();
        const anchor = rawCommandAnchors.get(field);
        if (anchor) {
          const before = captureFieldSnapshot(field);
          restoringRawCommandAnchor = true;
          try {
            restoreCancelledRawCommandAnchor(field, anchor);
          } finally {
            restoringRawCommandAnchor = false;
          }
          rawCommandAnchors.delete(field);
          markVisualTexStructuralPlaceholders(field);
          const after = captureFieldSnapshot(field);
          emitEdit(before, after, "delete-backward", "keyboard");
          propsRef.current.onInputActivity(field);
          syncFrameSize();
        }
        return;
      }

      const imeDecision = imeGuard.keyDown(event, event.timeStamp);
      if (imeDecision === "composition") return;
      if (imeDecision === "post-composition-enter") {
        // macOS WebKit can replay the Enter used to confirm an IME candidate
        // after compositionend. Consume only that one synthetic follow-up so
        // VisualTeX does not also create a new formula line.
        event.preventDefault();
        event.stopPropagation();
        return;
      }
      if (compositionStartRef.current) {
        compositionStartRef.current = null;
        lastSnapshotRef.current = captureFieldSnapshot(field);
      }

      const accentNavigationDirection =
        !event.metaKey &&
        !event.ctrlKey &&
        !event.altKey &&
        !event.shiftKey &&
        event.key === "ArrowLeft"
          ? "left"
          : !event.metaKey &&
              !event.ctrlKey &&
              !event.altKey &&
              !event.shiftKey &&
              event.key === "ArrowRight"
            ? "right"
            : null;
      if (
        accentNavigationDirection &&
        selectAdjacentAccentPlaceholder(field, accentNavigationDirection)
      ) {
        event.preventDefault();
        event.stopImmediatePropagation();
        markVisualTexStructuralPlaceholders(field);
        propsRef.current.onInputActivity(field);
        return;
      }

      const verticalStructureDirection =
        !event.metaKey &&
        !event.ctrlKey &&
        !event.altKey &&
        !event.shiftKey &&
        event.key === "ArrowUp"
          ? "up"
          : !event.metaKey &&
              !event.ctrlKey &&
              !event.altKey &&
              !event.shiftKey &&
              event.key === "ArrowDown"
            ? "down"
            : null;
      if (
        verticalStructureDirection &&
        moveWithinCustomVerticalStructureFromRecentSelection(
          verticalStructureDirection,
        )
      ) {
        event.preventDefault();
        event.stopImmediatePropagation();
        markVisualTexStructuralPlaceholders(field);
        propsRef.current.onInputActivity(field);
        return;
      }

      const capturesDirectMathInput =
        !event.isComposing &&
        !event.metaKey &&
        !event.ctrlKey &&
        !event.altKey &&
        field.mode !== "latex" &&
        event.key !== "\\" &&
        Array.from(event.key).length === 1;
      if (capturesDirectMathInput) {
        capturePendingAutoExit();
        if (selectedAccentState) armSelectedAccentAutoExit(selectedAccentState);
      } else if (
        event.key !== "Shift" &&
        event.key !== "Control" &&
        event.key !== "Alt" &&
        event.key !== "Meta"
      ) {
        clearPendingAutoExit();
      }

      if (confirmPendingWrapperInput(event)) return;
      if (confirmRawPlaceholderCommand(event)) return;
      if (confirmRawWrapperCommand(event)) return;
      if (confirmRawNativeCommand(event)) return;

      propsRef.current.onKeyDown(propsRef.current.index, event, field);
    };
    const suppressMathLiveContextMenu = (event: Event) => {
      event.preventDefault();
      event.stopImmediatePropagation();
      const pointer = event as MouseEvent;
      propsRef.current.onContextMenu?.(pointer.clientX, pointer.clientY);
    };
    const handlePaste = (event: ClipboardEvent) => {
      const clipboard = event.clipboardData;
      if (!clipboard) return;

      const multiLinePayload = clipboard.getData(
        VISUALTEX_MULTILINE_LATEX_CLIPBOARD_TYPE,
      );
      if (multiLinePayload && propsRef.current.onPasteLatexLines) {
        try {
          const parsed = JSON.parse(multiLinePayload) as {
            lines?: unknown;
          };
          const lines = Array.isArray(parsed.lines)
            ? parsed.lines.filter(
                (line): line is string => typeof line === "string",
              )
            : [];
          if (lines.length > 1) {
            event.preventDefault();
            event.stopImmediatePropagation();
            propsRef.current.onCommitPending();
            propsRef.current.onFocus(propsRef.current.index, field);
            propsRef.current.onPasteLatexLines(
              propsRef.current.lineId,
              field,
              lines,
            );
            return;
          }
        } catch {
          // Ignore malformed custom clipboard data and fall back to MathLive.
        }
      }

      if (!propsRef.current.onPasteImage) return;
      const item = Array.from(clipboard.items).find(
        (candidate) =>
          candidate.kind === "file" && candidate.type.startsWith("image/"),
      );
      const image = item?.getAsFile() ??
        Array.from(clipboard.files).find((file) => file.type.startsWith("image/"));
      if (!image) return;

      event.preventDefault();
      event.stopPropagation();
      propsRef.current.onCommitPending();
      propsRef.current.onFocus(propsRef.current.index, field);

      const selection = field.selection;
      propsRef.current.onPasteImage(image, {
        lineId: propsRef.current.lineId,
        ranges: selection.ranges.map(
          ([start, end]) => [start, end] as [number, number],
        ),
        direction: selection.direction ?? "none",
      });
    };
    const handlePointerSelectionEnd = () => {
      if (!visualTexPointerSelectingFields.delete(field)) return;
      field.classList.remove(visualTexPointerSelectingClass);
      removePointerPlaceholderSnapshotStyle(field);
      window.requestAnimationFrame(() => {
        if (!field.isConnected) return;
        markVisualTexStructuralPlaceholders(field);
      });
    };
    const handlePointerDown = (event: PointerEvent) => {
      const opensContextMenu =
        event.button === 2 || (event.button === 0 && event.ctrlKey);
      if (opensContextMenu) return;
      if (event.button !== 0) return;
      installPointerPlaceholderSnapshotStyle(field);
      visualTexPointerSelectingFields.add(field);
      field.classList.add(visualTexPointerSelectingClass);
      schedulePointerPlaceholderSnapshotStyle();
      clearPendingWrapperInput();
      clearPendingPackageMacroInput();
      rawCommandAnchors.delete(field);
      propsRef.current.onCommitPending();

      const content = field.shadowRoot?.querySelector<HTMLElement>(
        '[part="content"]',
      );
      const contentBounds = content?.getBoundingClientRect();
      const hostBounds = host.getBoundingClientRect();
      const clickedInsideHost =
        event.clientX >= hostBounds.left &&
        event.clientX <= hostBounds.right &&
        event.clientY >= hostBounds.top &&
        event.clientY <= hostBounds.bottom;
      if (!clickedInsideHost) return;

      const structuralBoundaryOffset = structuralBoundaryOffsetFromPoint(
        field,
        event.clientX,
      );
      if (
        structuralBoundaryOffset !== null &&
        !event.altKey &&
        !event.ctrlKey &&
        !event.metaKey &&
        !event.shiftKey
      ) {
        event.preventDefault();
        event.stopPropagation();
        field.focus();
        field.selection = {
          ranges: [[structuralBoundaryOffset, structuralBoundaryOffset]],
          direction: "none",
        };
        field.position = structuralBoundaryOffset;
        field.shadowRoot
          ?.querySelector<HTMLElement>('[part="keyboard-sink"]')
          ?.focus({ preventScroll: true });
        propsRef.current.onFocus(propsRef.current.index, field);
        return;
      }

      const hasVisibleFormula = Boolean(field.value.trim()) && contentBounds;
      const clickedInLeftBlankArea = hasVisibleFormula
        ? event.clientX < contentBounds.left - 6
        : false;
      const clickedInRightBlankArea = hasVisibleFormula
        ? event.clientX > contentBounds.right + 6
        : true;

      // Preserve MathLive's native hit testing on rendered formula atoms.
      // Blank row space maps to the nearest mathematical edge so centered and
      // right-aligned formulas remain easy to focus and edit.
      if (!clickedInLeftBlankArea && !clickedInRightBlankArea) return;

      event.preventDefault();
      event.stopPropagation();

      const target = clickedInLeftBlankArea ? 0 : field.lastOffset;
      field.focus();
      field.selection = {
        ranges: [[target, target]],
        direction: "none",
      };
      field.position = target;
      field.shadowRoot
        ?.querySelector<HTMLElement>('[part="keyboard-sink"]')
        ?.focus({ preventScroll: true });
      propsRef.current.onFocus(propsRef.current.index, field);
    };
    host.replaceChildren(field);
    installMathLiveOptionMutationGuard(field);
    // WebView2 exposes a richer mounted macro dictionary than MathLive's
    // deferred pre-mount options (for example, it includes native \\bmod).
    // Merge compatibility aliases only after mount so Windows does not lose
    // those native commands, while the mutation guard still handles transient
    // model initialization safely.
    field.macros = composeCustomSymbolMacrosForMathfield(
      field,
      field.macros,
      VISUALTEX_MATHLIVE_COMPATIBILITY_MACROS,
    );
    defaultInlineShortcutsRef.current = { ...field.inlineShortcuts };
    field.inlineShortcuts = resolveVisualTexInlineShortcuts(
      defaultInlineShortcutsRef.current,
      propsRef.current.inputBehavior.autoEscapeShortcuts,
    );
    field.menuItems = [];
    installMathLiveContourIntegralShadowStyle(field);
    installCustomSymbolShadowStyle(field);
    installVisualTexStructuralPlaceholderStyle(field);
    applyVisualTexFormulaFonts(
      field,
      propsRef.current.formulaLetterFont,
      propsRef.current.formulaChineseFont,
    );
    // MathLive mounts a pre-filled field with the whole formula selected.
    // Collapse that implicit selection so toolbar commands insert at the end
    // instead of unexpectedly replacing/wrapping the entire line.
    field.position = field.lastOffset;
    field.resetUndo();
    lastSnapshotRef.current = captureFieldSnapshot(field);
    fieldRef.current = field;
    propsRef.current.register(initialLineId, field);
    // Capture before MathLive's keyboard sink replaces a selected placeholder;
    // the bubble phase is already too late because the parent structure is gone.
    field.addEventListener("compositionstart", handleCompositionStart, true);
    field.addEventListener("compositionend", handleCompositionEnd);
    field.addEventListener("beforeinput", handleBeforeInput, true);
    field.addEventListener("input", handleInput);
    field.addEventListener("selection-change", handleSelectionChange);
    field.addEventListener("focus", handleFocus);
    field.addEventListener("blur", handleBlur);
    window.addEventListener("keydown", handleWindowRawWrapperKeyDown, true);
    field.addEventListener("keydown", handleKeyDown, true);
    const keyboardSink = field.shadowRoot?.querySelector<HTMLElement>(
      '[part="keyboard-sink"]',
    );
    keyboardSink?.addEventListener("keydown", handleRawWrapperKeyDown, true);
    keyboardSink?.addEventListener("input", scheduleInputActivity, true);
    keyboardSink?.addEventListener("keyup", scheduleInputActivity, true);
    field.addEventListener("paste", handlePaste, true);
    field.shadowRoot?.addEventListener(
      "contextmenu",
      suppressMathLiveContextMenu,
      true,
    );
    host.addEventListener("contextmenu", suppressMathLiveContextMenu, true);
    host.addEventListener("pointerdown", handlePointerDown, true);
    window.addEventListener("pointerup", handlePointerSelectionEnd, true);
    window.addEventListener("pointercancel", handlePointerSelectionEnd, true);
    const content = field.shadowRoot?.querySelector<HTMLElement>('[part="content"]');
    const resizeObserver = content
      ? new ResizeObserver(() => {
          syncFrameSize();
          schedulePendingWrapperPlaceholderPosition();
        })
      : null;
    const inputMutationObserver = field.shadowRoot
    ? new MutationObserver(() => {
        observeVisualTexActiveAccentPlaceholder(field);
        scheduleDeletedVisualTexPlaceholderRestore(field);
        markVisualTexStructuralPlaceholders(field);
        markVisualTexChineseGlyphs(field);
        syncPostOperatorCaretSpacing(field);
        syncFrameSize();
        schedulePointerPlaceholderSnapshotStyle();
          scheduleInputActivity();
          schedulePendingWrapperPlaceholderPosition();
        })
      : null;
    if (content) resizeObserver?.observe(content);
    if (field.shadowRoot) {
      inputMutationObserver?.observe(field.shadowRoot, {
        childList: true,
        characterData: true,
        attributes: true,
        attributeFilter: ["class"],
        subtree: true,
      });
    }
    // The field is now connected, but React's layout effect still runs before
    // the browser's first paint. Resolve the actual MathLive geometry here so
    // a newly inserted line never paints with the CSS fallback or predicted
    // height and then visibly shrinks on the next animation frame.
    measureFrameSize();
    syncPostOperatorCaretSpacing(field);
    queueMicrotask(() => {
      if (!field.isConnected) return;
      measureFrameSize();
      syncPostOperatorCaretSpacing(field);
    });

    return () => {
      window.cancelAnimationFrame(resizeFrame);
      window.removeEventListener(
        EDITOR_LAYOUT_REFRESH_EVENT,
        handleLayoutRefresh,
      );
      window.cancelAnimationFrame(pointerPlaceholderFrame);
      window.cancelAnimationFrame(wrapperPlaceholderFrame);
      window.clearTimeout(backslashGuardTimer);
      resizeObserver?.disconnect();
      inputMutationObserver?.disconnect();
      syncFrameSizeRef.current = null;
      field.removeEventListener("compositionstart", handleCompositionStart, true);
      field.removeEventListener("compositionend", handleCompositionEnd);
      field.removeEventListener("beforeinput", handleBeforeInput, true);
      field.removeEventListener("input", handleInput);
      field.removeEventListener("selection-change", handleSelectionChange);
      field.removeEventListener("focus", handleFocus);
      field.removeEventListener("blur", handleBlur);
      window.removeEventListener("keydown", handleWindowRawWrapperKeyDown, true);
      field.removeEventListener("keydown", handleKeyDown, true);
      keyboardSink?.removeEventListener("keydown", handleRawWrapperKeyDown, true);
      keyboardSink?.removeEventListener("input", scheduleInputActivity, true);
      keyboardSink?.removeEventListener("keyup", scheduleInputActivity, true);
      field.removeEventListener("paste", handlePaste, true);
      field.shadowRoot?.removeEventListener(
        "contextmenu",
        suppressMathLiveContextMenu,
        true,
      );
      host.removeEventListener("contextmenu", suppressMathLiveContextMenu, true);
      host.removeEventListener("pointerdown", handlePointerDown, true);
      window.removeEventListener("pointerup", handlePointerSelectionEnd, true);
      window.removeEventListener("pointercancel", handlePointerSelectionEnd, true);
      visualTexPointerSelectingFields.delete(field);
      field.classList.remove(visualTexPointerSelectingClass);
      removePointerPlaceholderSnapshotStyle(field);
      host.closest<HTMLElement>(".formula-line")?.style.removeProperty(
        "--formula-row-height",
      );
      propsRef.current.register(registeredLineIdRef.current, null, field);
      fieldRef.current = null;
      defaultInlineShortcutsRef.current = null;
      lastSnapshotRef.current = null;
      compositionStartRef.current = null;
      structuredCompositionAnchorRef.current = null;
      clearPendingAutoExit();
      clearPendingWrapperInput();
      rawCommandAnchors.delete(field);
      const caretRepaintFrame = visualTexCaretRepaintFrames.get(field);
      if (caretRepaintFrame) {
        window.cancelAnimationFrame(caretRepaintFrame);
        visualTexCaretRepaintFrames.delete(field);
      }
      field.classList.remove(visualTexCaretRepaintClass);
      host.replaceChildren();
    };
  }, []);

  useLayoutEffect(() => {
    const field = fieldRef.current;
    if (!field) return;
    const previousLineId = registeredLineIdRef.current;
    if (previousLineId === props.lineId) return;
    propsRef.current.register(previousLineId, null, field);
    propsRef.current.register(props.lineId, field);
    registeredLineIdRef.current = props.lineId;
  }, [props.lineId]);

  useLayoutEffect(() => {
    const field = fieldRef.current;
    const host = hostRef.current;
    if (!field || !host) return;
    const zoomChanged = sizingZoomRef.current !== props.zoom;
    const rowVerticalInsetChanged =
      sizingRowVerticalInsetRef.current !== props.formulaRowVerticalInset;
    sizingZoomRef.current = props.zoom;
    sizingRowVerticalInsetRef.current = props.formulaRowVerticalInset;

    normalizeCompletedDifferentialDisplay(field);
    installCustomSymbolShadowStyle(field);

    // 本地输入仅因中文规范化而与 store 等值时，不重建 MathLive 模型；
    // 只更新事务基准，保留当前光标、选区和删除键内部状态。
    if (normalizeChineseLatex(field.value) === props.latex) {
      lastSnapshotRef.current = {
        latex: props.latex,
        selection: captureSelection(field),
      };
      if (!zoomChanged && !rowVerticalInsetChanged) return;
    } else {
      const currentLatex = normalizeChineseLatex(field.value);
      const applyExternalValue = () =>
        field.setValue(props.latex, {
          mode: "math",
          format: "latex",
          insertionMode: "replaceAll",
          selectionMode: "after",
          silenceNotifications: true,
        });
      if (
        props.freshExternalSync &&
        needsCleanMathLiveModelForExternalSync(currentLatex, props.latex)
      ) {
        resetMathLiveModelRootForExternalSync(field);
      }
      applyExternalValue();
      if (
        props.freshExternalSync &&
        normalizeChineseLatex(field.value) !== props.latex &&
        resetMathLiveModelRootForExternalSync(field)
      ) {
        applyExternalValue();
      }
      installCustomSymbolShadowStyle(field);
      field.resetUndo();
    }

    const metrics = formulaRowHeightMetrics(
      props.latex,
      props.zoom,
      props.formulaRowVerticalInset,
    );
    const predictedHeight = predictedFormulaRowHeight(
      props.latex,
      props.zoom,
      props.formulaRowVerticalInset,
      host,
    );
    field.classList.toggle("is-simple-formula", !metrics.hasTallStructure);
    field.style.fontSize = metrics.fontSize + "px";
    field.style.height = predictedHeight + "px";
    field.style.minHeight = predictedHeight + "px";
    host.closest<HTMLElement>(".formula-line")?.style.setProperty(
      "--formula-row-height",
      predictedHeight + "px",
    );
    lastSnapshotRef.current = captureFieldSnapshot(field);
    syncFrameSizeRef.current?.();
  }, [props.formulaRowVerticalInset, props.latex, props.zoom]);

  useEffect(() => {
    if (fieldRef.current) {
      fieldRef.current.smartFence = props.autoPairDelimiters;
    }
  }, [props.autoPairDelimiters]);

  useEffect(() => {
    if (fieldRef.current) fieldRef.current.readOnly = props.readOnly;
  }, [props.readOnly]);

  useEffect(() => {
    const field = fieldRef.current;
    const defaults = defaultInlineShortcutsRef.current;
    if (!field || !defaults) return;
    field.inlineShortcuts = resolveVisualTexInlineShortcuts(
      defaults,
      props.inputBehavior.autoEscapeShortcuts,
    );
  }, [props.inputBehavior.autoEscapeShortcuts]);

  useEffect(() => {
    const field = fieldRef.current;
    if (!field) return;
    applyVisualTexFormulaFonts(
      field,
      props.formulaLetterFont,
      props.formulaChineseFont,
    );
    syncFrameSizeRef.current?.();
    const frame = window.requestAnimationFrame(() => {
      if (!field.isConnected) return;
      syncFrameSizeRef.current?.();
    });
    return () => window.cancelAnimationFrame(frame);
  }, [props.formulaChineseFont, props.formulaLetterFont]);

  useEffect(() => {
    const field = fieldRef.current;
    if (!field) return;
    MathfieldElement.locale = props.language === "en" ? "en" : "zh-cn";
    const isEn = props.language === "en";
    field.setAttribute(
      "aria-label",
      isEn
        ? "Formula line " + (props.index + 1)
        : "第 " + (props.index + 1) + " 行公式",
    );
    field.removeAttribute("placeholder");
  }, [props.index, props.language]);

  return <div ref={hostRef} className="mathfield-host" />;
}

export const MathEditor = forwardRef<MathEditorHandle, Props>(
  function MathEditor(
    {
      lines,
      activeLineId,
      formulaAlignment,
      latexCodeFormat,
      zoom,
      reuseLineSlots = false,
      readOnly = false,
      previewOnly = false,
      onPreviewActivate,
      draftError,
      onPasteImage,
      onCopyPng,
      onHistoryBusyChange,
      overlay,
    },
    ref,
  ) {
    const surfaceRef = useRef<HTMLDivElement>(null);
    const fieldRefs = useRef(new Map<string, MathfieldElement>());
    const linesRef = useRef(lines);
    const activeIndexRef = useRef(0);
    const activeLineIdRef = useRef<string | null>(activeLineId);
    const focusRequestRef = useRef(0);
    const previewOnlyRef = useRef(previewOnly);
    const greekLetterHotkeyLineIdRef = useRef<string | null>(null);
    const suppressedHistoryLineIdRef = useRef<string | null>(null);
    const multiLineSelectionRef = useRef<MultiLineSelectionState | null>(null);
    const lastSelectionTargetRef = useRef<MathEditorSelectionTarget | null>(null);
    const pointerSelectionSessionRef = useRef<PointerSelectionSession | null>(
      null,
    );
    const multiLineSelectedIdsRef = useRef(new Set<string>());
    const [, setMultiLineSelectionRevision] = useState(0);
    const pendingFocusRef = useRef<{
      lineId: string;
      latex: string | null;
      selection: MathSelectionSnapshot | null;
      moveToEnd: boolean;
      deferredRepair: boolean;
    } | null>(null);
    const [activeIndex, setActiveIndex] = useState(() =>
      Math.max(0, lines.findIndex((line) => line.id === activeLineId)),
    );
    const [fieldRenderEpoch, setFieldRenderEpoch] = useState(0);
    const [query, setQuery] = useState("");
    const [selectedIndex, setSelectedIndex] = useState(0);
    const [contextMenu, setContextMenu] = useState<{
      left: number;
      top: number;
    } | null>(null);
    const [contextMenuBusy, setContextMenuBusy] = useState(false);
    const [popupPosition, setPopupPosition] = useState({ left: 72, top: 132 });
    const selectedIndexRef = useRef(0);
    const queryRef = useRef("");
    const suppressedSuggestionRef = useRef<{
      lineId: string;
      value: string;
    } | null>(null);
    const usage = useEditorStore((state) => state.usage);
    const personalize = useEditorStore((state) => state.personalize);
    const suggestionCount = useEditorStore((state) => state.suggestionCount);
    const recordCommand = useEditorStore((state) => state.recordCommand);
    const language = useEditorStore((state) => state.language);
    const pngExportBackground = useEditorStore(
      (state) => state.pngExportBackground,
    );
    const autoPairDelimiters = useEditorStore(
      (state) => state.autoPairDelimiters,
    );
    const showLineNumbers = useEditorStore((state) => state.showLineNumbers);
    const formulaInsetLeft = useEditorStore((state) => state.formulaInsetLeft);
    const formulaInsetRight = useEditorStore((state) => state.formulaInsetRight);
    const formulaRowVerticalInset = useEditorStore(
      (state) => state.formulaRowVerticalInset,
    );
    const formulaLetterFont = useEditorStore((state) => state.formulaLetterFont);
    const formulaChineseFont = useEditorStore((state) => state.formulaChineseFont);
    const inputBehavior = useEditorStore((state) => state.inputBehavior);
    const formulaHotkeyBindings = useFormulaHotkeyStore(
      (state) => state.bindings,
    );
    const customSymbolRevision = useCustomSymbolRevision();
    const isEn = language === "en";
    const interactionReadOnly = readOnly || previewOnly;
    previewOnlyRef.current = previewOnly;

    useEffect(() => {
      installCustomSymbolGlobalStyle();
      fieldRefs.current.forEach((field) => refreshCustomSymbolMathfield(field));
    }, [customSymbolRevision]);

    linesRef.current = lines;
    const resolvedActiveLineId =
      lines.find((line) => line.id === activeLineId)?.id ?? lines[0]?.id ?? null;
    activeLineIdRef.current = resolvedActiveLineId;

    const resolveExplicitAlignmentVisualAnchor = (marker: HTMLElement) => {
      const markerBounds = marker.getBoundingClientRect();
      const parent = marker.parentElement;
      if (!parent) return markerBounds.left;

      for (
        let sibling = marker.nextElementSibling;
        sibling;
        sibling = sibling.nextElementSibling
      ) {
        const candidates: Element[] = sibling.hasAttribute("data-atom-id")
          ? [sibling, ...sibling.querySelectorAll("[data-atom-id]")]
          : [...sibling.querySelectorAll("[data-atom-id]")];
        for (const candidate of candidates) {
          if (!(candidate instanceof HTMLElement)) continue;
          const bounds = candidate.getBoundingClientRect();
          if (bounds.width <= 0.01 || bounds.height <= 0.01) continue;
          return bounds.left;
        }
      }

      return markerBounds.left;
    };

    const refreshExplicitAlignmentLayout = () => {
      const registered = Array.from(fieldRefs.current.values());
      for (const field of registered) {
        const host = field.closest<HTMLElement>(".mathfield-host");
        host?.classList.remove("has-explicit-align-marker");
        field.style.removeProperty("margin-left");
        const previousMarkerCount = Number.parseInt(
          field.dataset.visualtexAlignmentMarkerCount ?? "0",
          10,
        );
        if (Number.isFinite(previousMarkerCount)) {
          for (let markerIndex = 0; markerIndex < previousMarkerCount; markerIndex += 1) {
            field.style.removeProperty(`--visualtex-align-marker-${markerIndex}-left`);
            field.style.removeProperty(`--visualtex-align-marker-${markerIndex}-right`);
          }
        }
        delete field.dataset.visualtexAlignmentMarkerCount;
      }
      const hasOcrAlignmentMarkers = linesRef.current.some((line) =>
        hasVisualTexAlignmentMarker(line.latex),
      );
      if (!usesExplicitAlignmentPoints(latexCodeFormat) && !hasOcrAlignmentMarkers) return;

      const marked = linesRef.current.flatMap((line) => {
        const field = fieldRefs.current.get(line.id);
        if (!field?.isConnected) return [];
        const host = field.closest<HTMLElement>(".mathfield-host");
        const markers = Array.from(
          field.shadowRoot?.querySelectorAll<HTMLElement>(
            `.${VISUALTEX_ALIGNMENT_MARKER_CLASS}`,
          ) ?? [],
        );
        if (!host || !markers.length) return [];
        const fieldBounds = field.getBoundingClientRect();
        const markerOffsets = markers.map(
          (marker) => resolveExplicitAlignmentVisualAnchor(marker) - fieldBounds.left,
        );
        const segmentWidths = markerOffsets.map((offset, index) =>
          Math.max(0, offset - (index === 0 ? 0 : markerOffsets[index - 1])),
        );
        segmentWidths.push(
          Math.max(0, fieldBounds.right - fieldBounds.left - markerOffsets.at(-1)!),
        );
        return [{ field, host, markers, segmentWidths }];
      });
      if (!marked.length) return;

      const maxMarkerCount = Math.max(...marked.map((entry) => entry.markers.length));
      const columnWidths = Array.from({ length: maxMarkerCount + 1 }, (_, column) =>
        Math.max(0, ...marked.map((entry) => entry.segmentWidths[column] ?? 0)),
      );
      // TeX align/aligned groups columns in right/left pairs. There is no gap
      // inside a pair, while consecutive pairs are separated by 2em. A single
      // marker therefore keeps the exact historical VisualTeX layout; extra
      // markers add only the inter-pair spacing needed by `&&`, `&&&`, ... .
      const fontSizePx = Number.parseFloat(getComputedStyle(marked[0].field).fontSize);
      const pairGap = Number.isFinite(fontSizePx) ? fontSizePx * 2 : 0;
      const pairGapCount = Math.floor(maxMarkerCount / 2);
      const alignedWidth =
        columnWidths.reduce((total, width) => total + width, 0) +
        pairGap * pairGapCount;

      for (const entry of marked) {
        const shadowRoot = entry.field.shadowRoot;
        if (shadowRoot) {
          let alignmentStyle = shadowRoot.getElementById(
            visualTexAlignmentMarkerStyleId,
          ) as HTMLStyleElement | null;
          if (!alignmentStyle) {
            alignmentStyle = document.createElement("style");
            alignmentStyle.id = visualTexAlignmentMarkerStyleId;
            shadowRoot.append(alignmentStyle);
          }
          // MathLive may rebuild its rendered atom tree after the math-field is
          // laid out. Keep compensation in field-owned CSS variables and a
          // stable shadow-root stylesheet instead of mutating transient marker
          // nodes directly. Top-level alignment markers are siblings, so the
          // Selectors-4 `of <selector>` form addresses the Nth marker rather
          // than the Nth arbitrary MathLive atom.
          alignmentStyle.textContent = Array.from(
            { length: maxMarkerCount },
            (_, markerIndex) => `
              .${VISUALTEX_ALIGNMENT_MARKER_CLASS}:nth-child(${markerIndex + 1} of .${VISUALTEX_ALIGNMENT_MARKER_CLASS}) {
                margin-left: var(--visualtex-align-marker-${markerIndex}-left, 0px) !important;
                margin-right: var(--visualtex-align-marker-${markerIndex}-right, 0px) !important;
              }
            `,
          ).join("\n");
        }

        const hostWidth = entry.host.getBoundingClientRect().width;
        const groupStart =
          formulaAlignment === "left"
            ? 0
            : formulaAlignment === "right"
              ? Math.max(0, hostWidth - alignedWidth)
              : Math.max(0, (hostWidth - alignedWidth) / 2);
        const fieldOffset = Math.max(
          0,
          groupStart + columnWidths[0] - entry.segmentWidths[0],
        );
        entry.host.classList.add("has-explicit-align-marker");
        entry.field.style.marginLeft = `${fieldOffset}px`;

        entry.field.dataset.visualtexAlignmentMarkerCount = String(entry.markers.length);
        entry.markers.forEach((_marker, markerIndex) => {
          let left = 0;
          // Apply each column's compensation immediately before its own marker.
          // Putting the next-column fill on the preceding marker's right margin
          // leaves one MathLive marker-atom width behind for consecutive `&&`
          // markers in WebView2/Chromium, which visibly shifts later anchors.
          if (markerIndex > 0) {
            left = Math.max(
              0,
              columnWidths[markerIndex] -
                (entry.segmentWidths[markerIndex] ?? 0),
            );
            if (markerIndex % 2 !== 0) left += pairGap;
          }
          entry.field.style.setProperty(
            `--visualtex-align-marker-${markerIndex}-left`,
            `${left}px`,
          );
          entry.field.style.setProperty(
            `--visualtex-align-marker-${markerIndex}-right`,
            "0px",
          );
        });
      }

      // MathLive's zero-width class atom can report a different inline box
      // origin when two markers are consecutive (`&&`). Reconcile the rendered
      // marker positions from left to right after the analytical column pass;
      // each non-negative correction also advances every later column.
      for (let markerIndex = 1; markerIndex < maxMarkerCount; markerIndex += 1) {
        const positioned = marked.flatMap((entry) => {
          const marker = entry.markers[markerIndex];
          return marker
            ? [{ entry, marker, left: marker.getBoundingClientRect().left }]
            : [];
        });
        if (!positioned.length) continue;
        const targetLeft = Math.max(...positioned.map((item) => item.left));
        for (const item of positioned) {
          const correction = Math.max(0, targetLeft - item.left);
          if (correction <= 0.01) continue;
          const property = `--visualtex-align-marker-${markerIndex}-left`;
          const current = Number.parseFloat(
            item.entry.field.style.getPropertyValue(property) || "0",
          );
          item.entry.field.style.setProperty(
            property,
            `${(Number.isFinite(current) ? current : 0) + correction}px`,
          );
        }
      }
    };

    useLayoutEffect(() => {
      let firstFrame = 0;
      let secondFrame = 0;
      const schedule = () => {
        window.cancelAnimationFrame(firstFrame);
        window.cancelAnimationFrame(secondFrame);
        firstFrame = window.requestAnimationFrame(() => {
          refreshExplicitAlignmentLayout();
          secondFrame = window.requestAnimationFrame(
            refreshExplicitAlignmentLayout,
          );
        });
      };
      schedule();
      window.addEventListener("resize", schedule);
      window.addEventListener(EDITOR_LAYOUT_REFRESH_EVENT, schedule);
      return () => {
        window.cancelAnimationFrame(firstFrame);
        window.cancelAnimationFrame(secondFrame);
        window.removeEventListener("resize", schedule);
        window.removeEventListener(EDITOR_LAYOUT_REFRESH_EVENT, schedule);
      };
    }, [
      fieldRenderEpoch,
      formulaAlignment,
      formulaInsetLeft,
      formulaInsetRight,
      formulaRowVerticalInset,
      latexCodeFormat,
      lines,
      showLineNumbers,
      zoom,
    ]);

    const captureEditorScrollSnapshot = (
      preferredLineId?: string | null,
    ): EditorScrollSnapshot | null => {
      const scroller =
        surfaceRef.current?.closest<HTMLElement>(".editor-pane-scroll") ?? null;
      if (!scroller) return null;
      const scrollerRect = scroller.getBoundingClientRect();
      const rows = Array.from(
        surfaceRef.current?.querySelectorAll<HTMLElement>(".formula-line") ?? [],
      );
      const preferredRow = preferredLineId
        ? rows.find((row) => row.dataset.lineId === preferredLineId) ?? null
        : null;
      const visibleRow = rows.find((row) => {
        const rect = row.getBoundingClientRect();
        return rect.bottom > scrollerRect.top && rect.top < scrollerRect.bottom;
      });
      const anchorRow = preferredRow ?? visibleRow ?? null;
      return {
        scroller,
        anchorLineId: anchorRow?.dataset.lineId ?? null,
        anchorOffset: anchorRow
          ? anchorRow.getBoundingClientRect().top - scrollerRect.top
          : 0,
        scrollTop: scroller.scrollTop,
      };
    };

    const applyEditorScrollSnapshot = (
      snapshot: EditorScrollSnapshot | null,
      targetLineId?: string | null,
      ensureTargetVisible = false,
    ) => {
      if (!snapshot?.scroller.isConnected) return;
      const { scroller } = snapshot;
      const scrollerRect = scroller.getBoundingClientRect();
      const anchorRow = snapshot.anchorLineId
        ? surfaceRef.current?.querySelector<HTMLElement>(
            `[data-line-id="${snapshot.anchorLineId}"]`,
          ) ?? null
        : null;
      if (anchorRow?.isConnected) {
        const currentOffset =
          anchorRow.getBoundingClientRect().top - scrollerRect.top;
        const offsetDelta = currentOffset - snapshot.anchorOffset;
        if (Math.abs(offsetDelta) > 0.5) {
          scroller.scrollTop += offsetDelta;
        }
      } else if (Math.abs(scroller.scrollTop - snapshot.scrollTop) > 0.5) {
        scroller.scrollTop = snapshot.scrollTop;
      }

      if (!ensureTargetVisible || !targetLineId) return;
      const targetRow = surfaceRef.current?.querySelector<HTMLElement>(
        `[data-line-id="${targetLineId}"]`,
      );
      if (!targetRow?.isConnected) return;
      const viewport = scroller.getBoundingClientRect();
      const target = targetRow.getBoundingClientRect();
      const inset = 8;
      const top = viewport.top + inset;
      const bottom = viewport.bottom - inset;
      const availableHeight = Math.max(0, bottom - top);
      if (target.height > availableHeight) {
        scroller.scrollTop += target.top - top;
      } else if (target.top < top) {
        scroller.scrollTop -= top - target.top;
      } else if (target.bottom > bottom) {
        scroller.scrollTop += target.bottom - bottom;
      }
    };

    const stabilizeEditorScroll = (
      snapshot: EditorScrollSnapshot | null,
      targetLineId?: string | null,
      ensureTargetVisible = false,
    ) => {
      const apply = () =>
        applyEditorScrollSnapshot(
          snapshot,
          targetLineId,
          ensureTargetVisible,
        );
      apply();
      queueMicrotask(apply);
      window.requestAnimationFrame(apply);
    };

    useEffect(() => {
      nativeSuggestionUsageSnapshot = usage;
      nativeSuggestionPersonalizeSnapshot = personalize;
      scheduleStableNativeInputPopoverSync();
    }, [usage, personalize]);

    const suggestions = useMemo(
      () =>
        query
          ? visibleCommandSuggestions(
              query,
              usage,
              personalize,
              suggestionCount,
              inputBehavior,
            )
          : [],
      [query, usage, personalize, suggestionCount, inputBehavior],
    );

    const selectSuggestionIndex = (index: number) => {
      selectedIndexRef.current = index;
      setSelectedIndex(index);
    };

    const applyFocusState = (
      lineId: string,
      expectedLatex: string | null,
      selection: MathSelectionSnapshot | null,
      moveToEnd: boolean,
      requestId: number,
    ) => {
      if (
        requestId !== focusRequestRef.current ||
        activeLineIdRef.current !== lineId
      ) {
        return false;
      }

      const field = fieldRefs.current.get(lineId);
      if (!field?.isConnected) return false;

      if (
        expectedLatex !== null &&
        normalizeChineseLatex(field.value) !== expectedLatex
      ) {
        field.setValue(expectedLatex, {
          mode: "math",
          format: "latex",
          insertionMode: "replaceAll",
          selectionMode: "after",
          silenceNotifications: true,
        });
      }
      field.resetUndo();

      // Establish the final model position before focusing MathLive's hidden
      // keyboard sink. WebKit can fail to repaint the caret when a focused
      // sink receives a programmatic selection change, leaving the correct
      // selection in the model but no visible caret until the next input.
      if (selection) {
        const clamped = clampSelection(selection, field.lastOffset);
        field.selection = clamped;
        const range = clamped.ranges[0];
        if (range && range[0] === range[1]) field.position = range[1];
      } else if (moveToEnd) {
        const end = field.lastOffset;
        field.selection = {
          ranges: [[end, end]],
          direction: "none",
        };
        field.position = end;
      }

      (field as HTMLElement).focus({ preventScroll: true });
      field.shadowRoot
        ?.querySelector<HTMLElement>('[part="keyboard-sink"]')
        ?.focus({ preventScroll: true });
      return true;
    };

    const focusLine = (
      lineId: string,
      options: {
        latex?: string | null;
        selection?: MathSelectionSnapshot | null;
        moveToEnd?: boolean;
        deferredRepair?: boolean;
      } = {},
      remainingAttempts = 10,
      requestId = ++focusRequestRef.current,
    ) => {
      const index = linesRef.current.findIndex((line) => line.id === lineId);
      if (index < 0) return false;

      const expectedLatex = options.latex ?? null;
      const selection = options.selection ?? null;
      const moveToEnd = options.moveToEnd ?? false;
      const deferredRepair = options.deferredRepair ?? true;
      activeIndexRef.current = index;
      activeLineIdRef.current = lineId;
      setActiveIndex((current) => (current === index ? current : index));
      const currentState = useEditorStore.getState();
      if (currentState.activeLineId !== lineId) {
        currentState.setActiveLineId(lineId);
      }
      pendingFocusRef.current = {
        lineId,
        latex: expectedLatex,
        selection,
        moveToEnd,
        deferredRepair,
      };

      const apply = () =>
        applyFocusState(
          lineId,
          expectedLatex,
          selection,
          moveToEnd,
          requestId,
        );
      const finish = () => {
        if (!apply()) return false;
        pendingFocusRef.current = null;
        if (!deferredRepair) return true;
        window.requestAnimationFrame(() => {
          if (!apply()) return;
          window.setTimeout(() => {
            const currentField = fieldRefs.current.get(lineId);
            // Do not let the delayed focus repair overwrite input that started
            // immediately after a toolbar insertion.
            if (
              !currentField?.isConnected ||
              currentField.mode !== "math" ||
              rawLatexInput(currentField) ||
              (expectedLatex !== null &&
                normalizeChineseLatex(currentField.value) !== expectedLatex)
            ) {
              return;
            }
            apply();
          }, 80);
        });
        return true;
      };

      if (finish()) return true;
      window.requestAnimationFrame(() => {
        if (finish() || remainingAttempts <= 0) return;
        window.setTimeout(
          () => focusLine(lineId, options, remainingAttempts - 1, requestId),
          16,
        );
      });
      return true;
    };

    const registerField = (
      lineId: string,
      field: MathfieldElement | null,
      expectedField?: MathfieldElement,
    ) => {
      if (field) {
        fieldRefs.current.set(lineId, field);
      } else if (
        !expectedField ||
        fieldRefs.current.get(lineId) === expectedField
      ) {
        fieldRefs.current.delete(lineId);
      }

      const pending = pendingFocusRef.current;
      if (field && pending?.lineId === lineId) {
        focusLine(lineId, {
          latex: pending.latex,
          selection: pending.selection,
          moveToEnd: pending.moveToEnd,
          deferredRepair: pending.deferredRepair,
        });
      }
    };

    const prepareFocusBeforeStructuralRemoval = (
      lineId: string,
      selection: MathSelectionSnapshot,
    ) => {
      const field = fieldRefs.current.get(lineId);
      if (!field?.isConnected) return false;

      // Transfer the native focus while both keyboard sinks are still in the
      // document. WKWebView drops a post-removal focus request made after the
      // keydown target has already been detached.
      focusRequestRef.current += 1;
      const index = linesRef.current.findIndex((line) => line.id === lineId);
      if (index >= 0) {
        activeIndexRef.current = index;
        activeLineIdRef.current = lineId;
        setActiveIndex((current) => (current === index ? current : index));
      }
      const currentState = useEditorStore.getState();
      if (currentState.activeLineId !== lineId) {
        currentState.setActiveLineId(lineId);
      }
      const clamped = clampSelection(selection, field.lastOffset);
      field.selection = clamped;
      const range = clamped.ranges[0];
      if (range && range[0] === range[1]) field.position = range[1];
      (field as HTMLElement).focus({ preventScroll: true });
      field.shadowRoot
        ?.querySelector<HTMLElement>('[part="keyboard-sink"]')
        ?.focus({ preventScroll: true });
      return true;
    };

    const finalizeFocusAfterStructuralRemoval = (
      lineId: string,
      selection: MathSelectionSnapshot,
    ) => {
      queueMicrotask(() => {
        if (
          activeLineIdRef.current !== lineId ||
          !fieldRefs.current.get(lineId)?.isConnected
        ) {
          return;
        }
        const field = fieldRefs.current.get(lineId);
        if (!field?.isConnected) return;
        const clamped = clampSelection(selection, field.lastOffset);
        field.selection = clamped;
        const range = clamped.ranges[0];
        if (range && range[0] === range[1]) field.position = range[1];
        repaintMathLiveCaret(field);
      });
    };

    const updatePopupPosition = (field: MathfieldElement) => {
      const fieldWithCaret = field as MathfieldElement & {
        getCaretPoint?: () => { x: number; y: number; height?: number };
      };
      const popupWidth = Math.min(440, Math.max(280, window.innerWidth - 24));
      const clampLeft = (left: number) =>
        Math.max(12, Math.min(window.innerWidth - popupWidth - 12, left));
      const caret = fieldWithCaret.getCaretPoint?.();

      if (caret) {
        setPopupPosition({
          left: clampLeft(caret.x),
          top: Math.max(
            64,
            caret.y + (caret.height ?? 28) + 8,
          ),
        });
      } else {
        const fieldRect = field.getBoundingClientRect();
        setPopupPosition({
          left: clampLeft(fieldRect.left + 48),
          top: fieldRect.bottom + 8,
        });
      }
    };

    const refreshSuggestionQuery = (
      lineId: string,
      field: MathfieldElement,
      normalized: string,
    ) => {
      if (lineId !== activeLineIdRef.current) return;
      const rawCommandActive = hasRawLatexInput(field);
      const activeCommandQuery = rawCommandActive
        ? ""
        : trailingCommandQuery(field, normalized);
      const suppressed = suppressedSuggestionRef.current;
      if (suppressed) {
        if (
          suppressed.lineId === lineId &&
          suppressed.value.trim() === normalized.trim()
        ) {
          queryRef.current = "";
          setQuery("");
          return;
        }
        suppressedSuggestionRef.current = null;
      }

      if (activeCommandQuery) {
        const queryChanged = queryRef.current !== activeCommandQuery;
        queryRef.current = activeCommandQuery;
        setQuery(activeCommandQuery);
        if (queryChanged) selectSuggestionIndex(0);
        requestAnimationFrame(() => updatePopupPosition(field));
      } else {
        queryRef.current = "";
        setQuery("");
      }
    };

    const setActiveLine = (lineId: string) => {
      const index = linesRef.current.findIndex((line) => line.id === lineId);
      if (index < 0) return;
      if (activeLineIdRef.current !== lineId) {
        historyManager.commitPendingTransaction();
        focusRequestRef.current += 1;
      }
      activeIndexRef.current = index;
      activeLineIdRef.current = lineId;
      setActiveIndex((current) => (current === index ? current : index));
      const state = useEditorStore.getState();
      if (state.activeLineId !== lineId) state.setActiveLineId(lineId);
    };

    const clearMultiLineSelection = () => {
      for (const lineId of multiLineSelectedIdsRef.current) {
        const field = fieldRefs.current.get(lineId);
        if (!field?.isConnected) continue;
        field.classList.remove("has-visualtex-multi-line-selection");
        field
          .closest<HTMLElement>(".formula-line")
          ?.classList.remove("is-multi-line-selected");
        if (!field.selectionIsCollapsed) {
          const position = Math.max(0, Math.min(field.position, field.lastOffset));
          field.selection = {
            ranges: [[position, position]],
            direction: "none",
          };
        }
      }
      const hadSelection = multiLineSelectedIdsRef.current.size > 0;
      multiLineSelectedIdsRef.current.clear();
      multiLineSelectionRef.current = null;
      if (hadSelection) {
        setMultiLineSelectionRevision((revision) => revision + 1);
      }
    };

    useLayoutEffect(() => {
      const fields = Array.from(fieldRefs.current.values()).filter(
        (field) => field.isConnected,
      );

      if (!previewOnly) {
        for (const field of fields) {
          field.classList.remove(visualTexSourcePreviewClass);
          field.readOnly = readOnly;
        }
        return;
      }

      historyManager.commitPendingTransaction();
      queryRef.current = "";
      setQuery("");
      selectSuggestionIndex(0);
      suppressedSuggestionRef.current = null;
      lastSelectionTargetRef.current = null;
      pointerSelectionSessionRef.current = null;
      clearMultiLineSelection();

      for (const field of fields) {
        field.classList.add(visualTexSourcePreviewClass);
        field.readOnly = true;
        const position = Math.max(0, Math.min(field.position, field.lastOffset));
        if (!field.selectionIsCollapsed) {
          field.selection = {
            ranges: [[position, position]],
            direction: "none",
          };
        }
        field.blur();
        delete field.dataset.pendingNativeSuggestion;
        field.classList.remove("has-visualtex-multi-line-selection");
        const host = field.closest<HTMLElement>(".mathfield-host");
        host?.classList.remove("has-pending-wrapper-placeholder");
        if (host) delete host.dataset.pendingWrapperCommand;
        field
          .closest<HTMLElement>(".formula-line")
          ?.classList.remove("is-multi-line-selected");
        dismissNativeSuggestionPopover(field);
      }

      return () => {
        if (previewOnlyRef.current) return;
        for (const field of fields) {
          if (!field.isConnected) continue;
          field.classList.remove(visualTexSourcePreviewClass);
          field.readOnly = readOnly;
        }
      };
    }, [lines, previewOnly, readOnly]);

    const resolveMultiLineSelectionPoint = (
      clientX: number,
      clientY: number,
      preferredLineId?: string,
    ): MultiLineSelectionPoint | null => {
      const mountedLines = linesRef.current.flatMap((line, lineIndex) => {
        const field = fieldRefs.current.get(line.id);
        const row = field?.closest<HTMLElement>(".formula-line");
        return field?.isConnected && row
          ? [{ lineId: line.id, lineIndex, field, rowRect: row.getBoundingClientRect() }]
          : [];
      });
      if (!mountedLines.length) return null;

      const preferred = preferredLineId
        ? mountedLines.find((line) => line.lineId === preferredLineId)
        : null;
      const target =
        preferred ??
        mountedLines.find(
          ({ rowRect }) => clientY >= rowRect.top && clientY <= rowRect.bottom,
        ) ??
        mountedLines.reduce((nearest, line) => {
          const distance =
            clientY < line.rowRect.top
              ? line.rowRect.top - clientY
              : clientY > line.rowRect.bottom
                ? clientY - line.rowRect.bottom
                : 0;
          const nearestDistance =
            clientY < nearest.rowRect.top
              ? nearest.rowRect.top - clientY
              : clientY > nearest.rowRect.bottom
                ? clientY - nearest.rowRect.bottom
                : 0;
          return distance < nearestDistance ? line : nearest;
        });
      const content = target.field.shadowRoot?.querySelector<HTMLElement>(
        '[part="content"]',
      );
      const contentRect = content?.getBoundingClientRect();
      const sampleY = contentRect
        ? Math.max(contentRect.top + 1, Math.min(clientY, contentRect.bottom - 1))
        : clientY;
      const structuralOffset = structuralBoundaryOffsetFromPoint(
        target.field,
        clientX,
      );
      const offset = Math.max(
        0,
        Math.min(
          structuralOffset ??
            target.field.getOffsetFromPoint(clientX, sampleY, { bias: 0 }),
          target.field.lastOffset,
        ),
      );
      return {
        lineId: target.lineId,
        lineIndex: target.lineIndex,
        offset,
      };
    };

    const rememberSelectionTarget = (
      lineId: string,
      selection: MathSelectionSnapshot,
    ) => {
      if (!selectionHasContent(selection)) return;
      lastSelectionTargetRef.current = {
        selections: [
          {
            lineId,
            ranges: selection.ranges,
            direction: selection.direction,
          },
        ],
      };
    };

    const applyMultiLineSelection = (
      anchor: MultiLineSelectionPoint,
      focus: MultiLineSelectionPoint,
    ) => {
      const isForward =
        anchor.lineIndex < focus.lineIndex ||
        (anchor.lineIndex === focus.lineIndex && anchor.offset <= focus.offset);
      const start = isForward ? anchor : focus;
      const end = isForward ? focus : anchor;
      const nextSelectedIds = new Set<string>();

      for (const lineId of multiLineSelectedIdsRef.current) {
        if (
          linesRef.current.findIndex((line) => line.id === lineId) >=
            start.lineIndex &&
          linesRef.current.findIndex((line) => line.id === lineId) <=
            end.lineIndex
        ) {
          continue;
        }
        const field = fieldRefs.current.get(lineId);
        if (!field?.isConnected) continue;
        field.classList.remove("has-visualtex-multi-line-selection");
        field
          .closest<HTMLElement>(".formula-line")
          ?.classList.remove("is-multi-line-selected");
        const position = Math.max(0, Math.min(field.position, field.lastOffset));
        field.selection = {
          ranges: [[position, position]],
          direction: "none",
        };
      }

      for (let lineIndex = start.lineIndex; lineIndex <= end.lineIndex; lineIndex += 1) {
        const line = linesRef.current[lineIndex];
        const field = line ? fieldRefs.current.get(line.id) : null;
        if (!line || !field?.isConnected) continue;
        const rangeStart =
          lineIndex === start.lineIndex ? start.offset : 0;
        const rangeEnd =
          lineIndex === end.lineIndex ? end.offset : field.lastOffset;
        field.selection = {
          ranges: [[Math.min(rangeStart, rangeEnd), Math.max(rangeStart, rangeEnd)]],
          direction: isForward ? "forward" : "backward",
        };
        field.classList.add("has-visualtex-multi-line-selection");
        field
          .closest<HTMLElement>(".formula-line")
          ?.classList.add("is-multi-line-selected");
        nextSelectedIds.add(line.id);
      }

      multiLineSelectedIdsRef.current = nextSelectedIds;
      multiLineSelectionRef.current = { anchor, focus };
      const selections = linesRef.current.flatMap((line) => {
        if (!nextSelectedIds.has(line.id)) return [];
        const field = fieldRefs.current.get(line.id);
        if (!field?.isConnected) return [];
        const selection = captureSelection(field);
        return selectionHasContent(selection)
          ? [
              {
                lineId: line.id,
                ranges: selection.ranges,
                direction: selection.direction,
              } satisfies MathEditorInsertionTarget,
            ]
          : [];
      });
      if (selections.length) lastSelectionTargetRef.current = { selections };
      setMultiLineSelectionRevision((revision) => revision + 1);
    };

    const handleFieldEdit = (
      edit: FormulaFieldEdit,
      field: MathfieldElement,
    ) => {
      lastSelectionTargetRef.current = null;
      if (multiLineSelectionRef.current) clearMultiLineSelection();
      const state = useEditorStore.getState();
      const currentLine = state.lines.find((line) => line.id === edit.lineId);
      if (!currentLine) return;
      const beforeActiveLineId = state.activeLineId;
      const beforeLatex = currentLine.latex;

      state.replaceFormulaLine(edit.lineId, edit.afterLatex);
      state.setActiveLineId(edit.lineId);
      linesRef.current = useEditorStore.getState().lines;
      setActiveLine(edit.lineId);
      refreshSuggestionQuery(edit.lineId, field, edit.afterLatex);

      if (
        historyManager.getState().isReplaying ||
        suppressedHistoryLineIdRef.current === edit.lineId ||
        beforeLatex === edit.afterLatex
      ) {
        return;
      }

      historyManager.recordFormulaEdit({
        ...edit,
        beforeLatex,
        beforeActiveLineId,
        afterActiveLineId: edit.lineId,
      });
    };

    const applyDiscreteFormulaMutation = (
      lineId: string,
      field: MathfieldElement,
      source: FormulaEditSource,
      mutate: () => boolean,
    ) => {
      historyManager.commitPendingTransaction();
      const state = useEditorStore.getState();
      const currentLine = state.lines.find((line) => line.id === lineId);
      if (!currentLine) return false;

      const before = captureFieldSnapshot(field);
      const beforeActiveLineId = state.activeLineId;
      suppressedHistoryLineIdRef.current = lineId;
      let changed = false;
      try {
        changed = mutate();
      } finally {
        suppressedHistoryLineIdRef.current = null;
      }
      if (!changed) return false;

      normalizeCompletedDifferentialDisplay(field);
      const after = captureFieldSnapshot(field);
      if (before.latex === after.latex) {
        field.resetUndo();
        return true;
      }
      state.replaceFormulaLine(lineId, after.latex);
      state.setActiveLineId(lineId);
      linesRef.current = useEditorStore.getState().lines;
      setActiveLine(lineId);
      field.resetUndo();

      const entry: ReplaceFormulaEntry = {
        type: "replace-formula",
        lineId,
        beforeLatex: before.latex,
        afterLatex: after.latex,
        beforeSelection: before.selection,
        afterSelection: after.selection,
        beforeActiveLineId,
        afterActiveLineId: lineId,
        timestamp: Date.now(),
        source,
      };
      historyManager.push(entry);
      return true;
    };

    const resolveTargetField = () => {
      let targetLineId = activeLineIdRef.current;
      let field = targetLineId
        ? fieldRefs.current.get(targetLineId)
        : undefined;
      if (!field?.isConnected) {
        targetLineId =
          linesRef.current.find((line) =>
            Boolean(fieldRefs.current.get(line.id)?.isConnected),
          )?.id ?? null;
        field = targetLineId
          ? fieldRefs.current.get(targetLineId)
          : undefined;
      }
      return targetLineId && field?.isConnected
        ? { lineId: targetLineId, field }
        : null;
    };

    const insertCommand = (
      command: LatexCommand,
      source: CommandSource = "toolbar",
      activeQuery = "",
    ) => {
      historyManager.commitPendingTransaction();
      const target = resolveTargetField();
      if (!target) return;
      const { lineId: targetLineId, field } = target;
      setActiveLine(targetLineId);
      field.focus();

      const rawAnchor = activeQuery
        ? rawCommandAnchors.get(field) ?? null
        : null;
      const originalSelection = rawAnchor?.selection ?? captureSelection(field);
      let insertionSelection = originalSelection;
      let implicitPreviousLatex = "";
      if (
        !activeQuery &&
        field.selectionIsCollapsed &&
        commandTargetsPreviousExpression(command)
      ) {
        const previousTarget = previousExpressionSelection(field);
        if (previousTarget) {
          insertionSelection = previousTarget.selection;
          implicitPreviousLatex = previousTarget.latex;
        }
      }
      const queryRange = activeQuery
        ? findTrailingCommandRange(field, activeQuery)
        : null;
      const replacesRawCommand = Boolean(
        activeQuery && !queryRange && rawAnchor,
      );
      if (activeQuery && !queryRange && !replacesRawCommand) {
        setQuery("");
        selectSuggestionIndex(0);
        return;
      }

      const selectedLatex = activeQuery
        ? ""
        : implicitPreviousLatex ||
          (insertionSelection.ranges[0]?.[0] ===
          insertionSelection.ranges[0]?.[1]
            ? ""
            : field.getValue(insertionSelection));
      const insertionTemplate = activeQuery
        ? command.insertTemplate
        : templateForSelection(command, selectedLatex);
      const autoExitSetting =
        rawAnchor?.autoExitSetting ?? getCaretAutoExitSetting(field);
      const autoExitScriptKey = rawAnchor?.autoExitScriptKey ?? null;
      const historySource: FormulaEditSource =
        source === "candidate"
          ? "candidate"
          : source === "shortcut"
            ? "shortcut"
            : "toolbar";

      if (
        queryRange &&
        field.getValue(queryRange[0], queryRange[1], "latex").trim() ===
          insertionTemplate.trim()
      ) {
        const normalizedValue = normalizeChineseLatex(field.value);
        suppressedSuggestionRef.current = {
          lineId: targetLineId,
          value: normalizedValue,
        };
        recordCommand(command.id, activeQuery, source);
        setQuery("");
        selectSuggestionIndex(0);
        if (
          source === "candidate" &&
          !structuredSuggestionCommands.has(command.command)
        ) {
          dismissNativeSuggestionPopover(field);
        }
        field.focus();
        return;
      }

      const tryInsert = () => {
        if (rawAnchor) restoreRawCommandInsertionAnchor(field, rawAnchor);
        else field.selection = insertionSelection;
        const inserted = applyDiscreteFormulaMutation(
          targetLineId,
          field,
          historySource,
          () => {
            const isBareOperator = command.id.endsWith("-bare");
            const hasPlaceholder = insertionTemplate.includes("\\placeholder{}");
            if (queryRange) {
              field.selection = {
                ranges: [queryRange],
                direction: "forward",
              };
            }
            const insertCurrentTemplate = () =>
              field.insert(insertionTemplate, {
                mode: "math",
                format: "latex",
                insertionMode: "replaceSelection",
                selectionMode: hasPlaceholder ? "placeholder" : "after",
                style: {
                  variant: "normal",
                  variantStyle: undefined,
                },
                focus: true,
                scrollIntoView: false,
              });
            const valueBeforeInsertion = normalizeChineseLatex(field.value);
            const bareOperatorCountBefore = isBareOperator
              ? valueBeforeInsertion.split(insertionTemplate).length - 1
              : 0;
            const insertedBareOperator = () =>
              normalizeChineseLatex(field.value).split(insertionTemplate).length - 1 >
              bareOperatorCountBefore;
            let inserted = insertCurrentTemplate();
            if (isBareOperator && !insertedBareOperator()) {
              const retryValue = field.value;
              const retrySelection = captureSelection(field);
              field.executeCommand("deleteBackward");
              inserted = insertCurrentTemplate();
              if (!insertedBareOperator()) {
                field.position = field.lastOffset;
                field.selection = {
                  ranges: [[field.lastOffset, field.lastOffset]],
                  direction: "none",
                };
                inserted = insertCurrentTemplate();
              }
              if (!insertedBareOperator()) {
                field.setValue(retryValue, {
                  mode: "math",
                  format: "latex",
                  insertionMode: "replaceAll",
                  selectionMode: "after",
                  silenceNotifications: true,
                });
                field.selection = retrySelection;
              }
            }
            const insertionChangedValue =
              normalizeChineseLatex(field.value) !== valueBeforeInsertion &&
              (!isBareOperator || insertedBareOperator());
            if (inserted && insertionChangedValue) {
              field.dataset.cancelPendingPackageMacroInput = "true";
            }
            if (inserted && insertionChangedValue && hasPlaceholder) {
              // MathLive already selects the first editable argument for
              // \nicefrac. Reconstructing that selection from exported
              // offsets can point at its compatibility wrapper instead and
              // make the next toolbar insertion a no-op.
              if (command.id !== "skewed-fraction" && !isBareOperator) {
                selectFirstLatexPlaceholder(
                  field,
                  command.command,
                  insertionTemplate,
                );
              }
              markVisualTexStructuralPlaceholders(field);
              const packageMacroName = command.command.replace(/^\\/, "");
              if (visualTexPackageMacroNameSet.has(packageMacroName)) {
                const activeRange = field.selection.ranges.at(-1) ?? null;
                const normalizedLatex = normalizeChineseLatex(field.value);
                if (activeRange && activeRange[0] !== activeRange[1]) {
                  const normalizedRange: [number, number] = [
                    Math.min(activeRange[0], activeRange[1]),
                    Math.max(activeRange[0], activeRange[1]),
                  ];
                  const modelPlaceholderIndex = latexPlaceholderRanges(field).findIndex(
                    ([start, end]) =>
                      start === normalizedRange[0] && end === normalizedRange[1],
                  );
                  const placeholderIndex =
                    textualPlaceholderIndexForRange(
                      normalizedLatex,
                      normalizedRange,
                    ) ??
                    (modelPlaceholderIndex >= 0 ? modelPlaceholderIndex : null);
                  if (placeholderIndex !== null) {
                    field.dataset.toolbarPackageMacroName = packageMacroName;
                    field.dataset.toolbarPackageMacroPlaceholderIndex = String(
                      placeholderIndex,
                    );
                    field.dataset.toolbarPackageMacroModelStart = String(
                      normalizedRange[0],
                    );
                  } else {
                    clearToolbarPackageMacroHint(field);
                  }
                } else {
                  clearToolbarPackageMacroHint(field);
                }
              } else {
                clearToolbarPackageMacroHint(field);
              }
              window.requestAnimationFrame(() => {
                if (field.isConnected) {
                  markVisualTexStructuralPlaceholders(field);
                }
              });
            } else if (inserted && insertionChangedValue) {
              clearToolbarPackageMacroHint(field);
            }
            if (
              inserted &&
              insertionChangedValue &&
              !hasPlaceholder &&
              autoExitSetting &&
              inputBehavior[autoExitSetting]
            ) {
              moveCaretThroughEnabledAutoExitContainers(
                field,
                inputBehavior,
                autoExitSetting,
                autoExitScriptKey,
              );
            }
            return inserted && insertionChangedValue;
          },
        );
        if (inserted) rawCommandAnchors.delete(field);
        else field.selection = originalSelection;
        return inserted;
      };

      const finishInsertion = () => {
        const normalizedValue = normalizeChineseLatex(field.value);
        suppressedSuggestionRef.current = {
          lineId: targetLineId,
          value: normalizedValue,
        };
        recordCommand(command.id, activeQuery, source);
        setQuery("");
        selectSuggestionIndex(0);
        if (
          source === "candidate" &&
          !structuredSuggestionCommands.has(command.command)
        ) {
          dismissNativeSuggestionPopover(field);
        }
        focusLine(targetLineId, {
          latex: normalizedValue,
          selection: captureSelection(field),
          // Placeholder templates already synchronously focus MathLive's keyboard
          // sink after insertion. Replaying that focus/selection 80 ms later can
          // race the user's very first key (notably a physical backslash) before
          // raw-LaTeX mode has had a chance to appear.
          deferredRepair: !insertionTemplate.includes("\\placeholder{}"),
        });
      };

      if (tryInsert()) {
        finishInsertion();
        return;
      }

      window.requestAnimationFrame(() => {
        if (!field.isConnected) return;
        field.focus();
        if (tryInsert()) finishInsertion();
      });
    };

    const setFormulaLineMode = (
      lineId: string,
      mode: FormulaLine["mode"],
    ) => {
      if (
        interactionReadOnly ||
        latexCodeFormat !== "mixed-inline-display" ||
        (mode !== "inline" && mode !== "display")
      ) {
        return;
      }
      const state = useEditorStore.getState();
      const current = state.lines.find((line) => line.id === lineId);
      const currentMode = current?.mode === "inline" ? "inline" : "display";
      if (!current || currentMode === mode) return;

      historyManager.commitPendingTransaction();
      const selectionByLineId = Object.fromEntries(
        linesRef.current.flatMap((line) => {
          const currentField = fieldRefs.current.get(line.id);
          return currentField?.isConnected
            ? [[line.id, captureSelection(currentField)] as const]
            : [];
        }),
      );
      const before = getEditorDocumentSnapshot(selectionByLineId);
      const after: ReplaceDocumentEntry["after"] = {
        ...before,
        lines: before.lines.map((line) =>
          line.id === lineId ? { ...line, mode } : { ...line },
        ),
        activeLineId: lineId,
      };
      flushSync(() => state.replaceDocumentState(after));
      linesRef.current = useEditorStore.getState().lines;
      setActiveLine(lineId);
      historyManager.push({
        type: "replace-document",
        before,
        after,
        source: "source-apply",
        timestamp: Date.now(),
      });
      focusLine(lineId, {
        latex: current.latex,
        selection: before.selectionByLineId[lineId] ?? null,
      });
    };

    const addLineAfter = (
      index: number,
      requestedMode?: FormulaLine["mode"],
    ) => {
      historyManager.commitPendingTransaction();
      const state = useEditorStore.getState();
      const beforeActiveLineId = state.activeLineId;
      const beforeField = beforeActiveLineId
        ? fieldRefs.current.get(beforeActiveLineId)
        : undefined;
      const beforeSelection = beforeField
        ? captureSelection(beforeField)
        : null;
      const nextIndex = Math.max(0, Math.min(index + 1, state.lines.length));
      const anchorLineId =
        state.lines[Math.max(0, Math.min(index, state.lines.length - 1))]?.id ??
        beforeActiveLineId;
      const scrollSnapshot = captureEditorScrollSnapshot(anchorLineId);
      const inheritedMode =
        requestedMode ??
        state.lines[Math.max(0, Math.min(index, state.lines.length - 1))]?.mode ??
        "display";
      const line = createFormulaLine("", undefined, inheritedMode);
      const afterSelection: MathSelectionSnapshot = {
        ranges: [[0, 0]],
        direction: "none",
      };

      const nextLines = state.lines.map((currentLine) => ({ ...currentLine }));
      nextLines.splice(nextIndex, 0, line);
      const nextDocument: ReplaceDocumentEntry["after"] = {
        title: state.title,
        lines: nextLines,
        activeLineId: line.id,
        formulaAlignment: state.formulaAlignment,
        selectionByLineId: {},
      };

      flushSync(() => state.replaceDocumentState(nextDocument));
      linesRef.current = useEditorStore.getState().lines;
      setActiveLine(line.id);

      const entry: AddLineEntry = {
        type: "add-line",
        line,
        index: nextIndex,
        beforeActiveLineId,
        afterActiveLineId: line.id,
        beforeSelection,
        afterSelection,
        timestamp: Date.now(),
      };
      historyManager.push(entry);
      setQuery("");
      focusLine(line.id, {
        latex: line.latex,
        selection: afterSelection,
        deferredRepair: false,
      });
      stabilizeEditorScroll(scrollSnapshot, line.id, false);
    };

    const pasteLatexLines = (
      lineId: string,
      field: MathfieldElement,
      pastedLines: string[],
    ) => {
      if (interactionReadOnly || pastedLines.length <= 1) return;
      const state = useEditorStore.getState();
      const currentIndex = state.lines.findIndex((line) => line.id === lineId);
      const currentLine = state.lines[currentIndex];
      if (currentIndex < 0 || !currentLine) return;

      const activeRange = field.selection.ranges.at(-1) ?? [
        field.position,
        field.position,
      ];
      const selectionStart = Math.max(
        0,
        Math.min(activeRange[0], activeRange[1], field.lastOffset),
      );
      const selectionEnd = Math.max(
        selectionStart,
        Math.min(Math.max(activeRange[0], activeRange[1]), field.lastOffset),
      );
      const liveLatex = normalizeChineseLatex(field.value);
      const leftLatex = normalizeChineseLatex(
        field.getValue(0, selectionStart, "latex"),
      );
      const rightLatex = normalizeChineseLatex(
        field.getValue(selectionEnd, field.lastOffset, "latex"),
      );
      const canonicalize = (latex: string) => {
        const verifier = new MathfieldElement();
        verifier.setValue(latex, {
          mode: "math",
          format: "latex",
          insertionMode: "replaceAll",
          selectionMode: "after",
          silenceNotifications: true,
        });
        return normalizeChineseLatex(verifier.value);
      };
      const concatenate = (left: string, right: string) => {
        const separator =
          /\\[A-Za-z]+$/.test(left) && /^[A-Za-z]/.test(right) ? " " : "";
        return canonicalize(`${left}${separator}${right}`);
      };
      const normalizedLines = pastedLines.map(canonicalize);
      const firstLatex = concatenate(leftLatex, normalizedLines[0] ?? "");
      const lastPastedLatex = normalizedLines.at(-1) ?? "";
      const lastLatex = concatenate(lastPastedLatex, rightLatex);
      const insertedLines = normalizedLines.slice(1).map((latex, index, lines) =>
        createFormulaLine(
          index === lines.length - 1 ? lastLatex : latex,
          undefined,
          currentLine.mode,
        ),
      );
      const lastLine = insertedLines.at(-1);
      if (!lastLine) return;

      historyManager.commitPendingTransaction();
      const selectionByLineId = Object.fromEntries(
        linesRef.current.flatMap((line) => {
          const currentField = fieldRefs.current.get(line.id);
          return currentField?.isConnected
            ? [[line.id, captureSelection(currentField)] as const]
            : [];
        }),
      );
      const before = getEditorDocumentSnapshot(selectionByLineId);
      before.lines = before.lines.map((line) =>
        line.id === lineId ? { ...line, latex: liveLatex } : line,
      );
      const nextLines = before.lines.map((line) =>
        line.id === lineId ? { ...line, latex: firstLatex } : { ...line },
      );
      nextLines.splice(currentIndex + 1, 0, ...insertedLines);

      const afterSelection: MathSelectionSnapshot = {
        ranges: [[Number.MAX_SAFE_INTEGER, Number.MAX_SAFE_INTEGER]],
        direction: "none",
      };
      const after: ReplaceDocumentEntry["after"] = {
        title: before.title,
        lines: nextLines,
        activeLineId: lastLine.id,
        formulaAlignment: before.formulaAlignment,
        selectionByLineId: {
          ...before.selectionByLineId,
          [lineId]: {
            ranges: [[Number.MAX_SAFE_INTEGER, Number.MAX_SAFE_INTEGER]],
            direction: "none",
          },
          [lastLine.id]: afterSelection,
        },
      };

      const scrollSnapshot = captureEditorScrollSnapshot(lineId);
      clearMultiLineSelection();
      lastSelectionTargetRef.current = null;
      flushSync(() => useEditorStore.getState().replaceDocumentState(after));
      linesRef.current = useEditorStore.getState().lines;
      setActiveLine(lastLine.id);
      historyManager.push({
        type: "replace-document",
        before,
        after,
        source: "paste-multi-line",
        timestamp: Date.now(),
      });
      setQuery("");
      selectSuggestionIndex(0);
      focusLine(lastLine.id, {
        latex: lastLatex,
        moveToEnd: true,
        deferredRepair: false,
      });
      stabilizeEditorScroll(scrollSnapshot, lastLine.id, false);
    };

    const splitLineAtCaret = (
      index: number,
      lineId: string,
      field: MathfieldElement,
      requestedMode?: FormulaLine["mode"],
    ) => {
      // Raw LaTeX input still belongs to MathLive's command transaction. In
      // ordinary math input, Enter follows Word: a selection is removed first,
      // then the remaining content is split at the selection boundary.
      if (hasRawLatexInput(field)) {
        addLineAfter(index, requestedMode);
        return;
      }

      const selectedRange = field.selection.ranges[0];
      if (field.selection.ranges.length !== 1 || !selectedRange) {
        addLineAfter(index, requestedMode);
        return;
      }
      const splitStart = Math.max(
        0,
        Math.min(
          field.selectionIsCollapsed
            ? field.position
            : Math.min(selectedRange[0], selectedRange[1]),
          field.lastOffset,
        ),
      );
      const splitEnd = Math.max(
        splitStart,
        Math.min(
          field.selectionIsCollapsed
            ? field.position
            : Math.max(selectedRange[0], selectedRange[1]),
          field.lastOffset,
        ),
      );
      if (field.selectionIsCollapsed && splitEnd >= field.lastOffset) {
        addLineAfter(index, requestedMode);
        return;
      }

      const originalLatex = normalizeChineseLatex(field.value);
      const leftLatex = normalizeChineseLatex(
        field.getValue(0, splitStart, "latex"),
      );
      const rightLatex = normalizeChineseLatex(
        field.getValue(splitEnd, field.lastOffset, "latex"),
      );
      const comparable = (value: string) =>
        value
          .replace(/\s+/g, "")
          .replace(/\{([A-Za-z0-9])\}/g, "$1");
      const verifier = new MathfieldElement();
      const canonicalize = (latex: string) => {
        verifier.setValue(latex, {
          mode: "math",
          format: "latex",
          insertionMode: "replaceAll",
          selectionMode: "after",
          silenceNotifications: true,
        });
        return comparable(verifier.value);
      };
      // MathLive offsets can point inside a structured atom such as a fraction
      // or matrix. Reparse the two serialized ranges before comparing them:
      // MathLive legitimately normalizes braces and command whitespace at a
      // safe boundary, which made direct string concatenation reject complex
      // trailing structures even though their model was lossless.
      if (
        field.selectionIsCollapsed &&
        (!rightLatex.trim() ||
          canonicalize(`${leftLatex} ${rightLatex}`) !==
            canonicalize(originalLatex))
      ) {
        addLineAfter(index, requestedMode);
        return;
      }

      historyManager.commitPendingTransaction();
      const state = useEditorStore.getState();
      const currentIndex = state.lines.findIndex((line) => line.id === lineId);
      if (currentIndex < 0) {
        addLineAfter(index, requestedMode);
        return;
      }

      const selectionByLineId = Object.fromEntries(
        linesRef.current.flatMap((line) => {
          const currentField = fieldRefs.current.get(line.id);
          return currentField?.isConnected
            ? [[line.id, captureSelection(currentField)] as const]
            : [];
        }),
      );
      const before = getEditorDocumentSnapshot(selectionByLineId);
      before.lines = before.lines.map((line) =>
        line.id === lineId ? { ...line, latex: originalLatex } : line,
      );

      const scrollSnapshot = captureEditorScrollSnapshot(lineId);
      const nextLine = createFormulaLine(
        rightLatex,
        undefined,
        requestedMode ?? before.lines[currentIndex]?.mode ?? "display",
      );
      const nextLines = before.lines.map((line) =>
        line.id === lineId ? { ...line, latex: leftLatex } : { ...line },
      );
      nextLines.splice(currentIndex + 1, 0, nextLine);
      const startSelection: MathSelectionSnapshot = {
        ranges: [[0, 0]],
        direction: "none",
      };
      const after: ReplaceDocumentEntry["after"] = {
        title: before.title,
        lines: nextLines,
        activeLineId: nextLine.id,
        formulaAlignment: before.formulaAlignment,
        selectionByLineId: {
          ...before.selectionByLineId,
          [lineId]: {
            ranges: [[Number.MAX_SAFE_INTEGER, Number.MAX_SAFE_INTEGER]],
            direction: "none",
          },
          [nextLine.id]: startSelection,
        },
      };

      flushSync(() => useEditorStore.getState().replaceDocumentState(after));
      linesRef.current = useEditorStore.getState().lines;
      setActiveLine(nextLine.id);

      const entry: ReplaceDocumentEntry = {
        type: "replace-document",
        before,
        after,
        source: "split-line",
        timestamp: Date.now(),
      };
      historyManager.push(entry);
      setQuery("");
      selectSuggestionIndex(0);
      focusLine(nextLine.id, {
        latex: rightLatex,
        selection: startSelection,
        deferredRepair: false,
      });
      stabilizeEditorScroll(scrollSnapshot, nextLine.id, false);
    };

    const mergeLineWithPrevious = (
      index: number,
      lineId: string,
      field: MathfieldElement,
    ) => {
      if (index <= 0) return false;
      const state = useEditorStore.getState();
      const currentIndex = state.lines.findIndex((line) => line.id === lineId);
      if (currentIndex <= 0) return false;
      const currentLine = state.lines[currentIndex];
      const previousLine = state.lines[currentIndex - 1];
      if (!currentLine || !previousLine) return false;

      historyManager.commitPendingTransaction();
      const previousField = fieldRefs.current.get(previousLine.id);
      const previousLatex = normalizeChineseLatex(
        previousField?.value ?? previousLine.latex,
      );
      const currentLatex = normalizeChineseLatex(field.value);
      const joinOffset = previousField?.lastOffset ?? 0;
      const verifier = new MathfieldElement();
      const commandSeparator =
        /\\[A-Za-z]+$/.test(previousLatex) && /^[A-Za-z]/.test(currentLatex)
          ? " "
          : "";
      verifier.setValue(`${previousLatex}${commandSeparator}${currentLatex}`, {
        mode: "math",
        format: "latex",
        insertionMode: "replaceAll",
        selectionMode: "after",
        silenceNotifications: true,
      });
      const mergedLatex = normalizeChineseLatex(verifier.value);

      const selectionByLineId = Object.fromEntries(
        linesRef.current.flatMap((line) => {
          const currentField = fieldRefs.current.get(line.id);
          return currentField?.isConnected
            ? [[line.id, captureSelection(currentField)] as const]
            : [];
        }),
      );
      const before = getEditorDocumentSnapshot(selectionByLineId);
      before.lines = before.lines.map((line) => {
        if (line.id === previousLine.id) {
          return { ...line, latex: previousLatex };
        }
        if (line.id === currentLine.id) {
          return { ...line, latex: currentLatex };
        }
        return line;
      });
      const joinSelection: MathSelectionSnapshot = {
        ranges: [[joinOffset, joinOffset]],
        direction: "none",
      };
      const nextSelectionByLineId = { ...before.selectionByLineId };
      delete nextSelectionByLineId[currentLine.id];
      nextSelectionByLineId[previousLine.id] = joinSelection;
      const after: ReplaceDocumentEntry["after"] = {
        title: before.title,
        lines: before.lines
          .filter((line) => line.id !== currentLine.id)
          .map((line) =>
            line.id === previousLine.id
              ? { ...line, latex: mergedLatex }
              : { ...line },
          ),
        activeLineId: previousLine.id,
        formulaAlignment: before.formulaAlignment,
        selectionByLineId: nextSelectionByLineId,
      };

      const scrollSnapshot = captureEditorScrollSnapshot(previousLine.id);
      prepareFocusBeforeStructuralRemoval(previousLine.id, joinSelection);
      flushSync(() => useEditorStore.getState().replaceDocumentState(after));
      linesRef.current = useEditorStore.getState().lines;
      setActiveLine(previousLine.id);
      historyManager.push({
        type: "replace-document",
        before,
        after,
        source: "merge-line",
        timestamp: Date.now(),
      });
      setQuery("");
      selectSuggestionIndex(0);
      finalizeFocusAfterStructuralRemoval(previousLine.id, joinSelection);
      stabilizeEditorScroll(scrollSnapshot, previousLine.id, false);
      return true;
    };

    const deleteMultiLineSelection = () => {
      const selection = multiLineSelectionRef.current;
      if (!selection) return false;
      const anchorIndex = linesRef.current.findIndex(
        (line) => line.id === selection.anchor.lineId,
      );
      const focusIndex = linesRef.current.findIndex(
        (line) => line.id === selection.focus.lineId,
      );
      if (anchorIndex < 0 || focusIndex < 0 || anchorIndex === focusIndex) {
        return false;
      }

      const anchor = { ...selection.anchor, lineIndex: anchorIndex };
      const focus = { ...selection.focus, lineIndex: focusIndex };
      const isForward = anchor.lineIndex < focus.lineIndex;
      const start = isForward ? anchor : focus;
      const end = isForward ? focus : anchor;
      const startLine = linesRef.current[start.lineIndex];
      const endLine = linesRef.current[end.lineIndex];
      const startField = startLine ? fieldRefs.current.get(startLine.id) : null;
      const endField = endLine ? fieldRefs.current.get(endLine.id) : null;
      if (!startLine || !endLine || !startField || !endField) return false;

      historyManager.commitPendingTransaction();
      const startOffset = Math.max(0, Math.min(start.offset, startField.lastOffset));
      const endOffset = Math.max(0, Math.min(end.offset, endField.lastOffset));
      const leftLatex = normalizeChineseLatex(
        startField.getValue(0, startOffset, "latex"),
      );
      const rightLatex = normalizeChineseLatex(
        endField.getValue(endOffset, endField.lastOffset, "latex"),
      );
      const commandSeparator =
        /\\[A-Za-z]+$/.test(leftLatex) && /^[A-Za-z]/.test(rightLatex)
          ? " "
          : "";
      const verifier = new MathfieldElement();
      verifier.setValue(`${leftLatex}${commandSeparator}${rightLatex}`, {
        mode: "math",
        format: "latex",
        insertionMode: "replaceAll",
        selectionMode: "after",
        silenceNotifications: true,
      });
      const mergedLatex = normalizeChineseLatex(verifier.value);
      const prefixVerifier = new MathfieldElement();
      prefixVerifier.setValue(leftLatex, {
        mode: "math",
        format: "latex",
        insertionMode: "replaceAll",
        selectionMode: "after",
        silenceNotifications: true,
      });
      const joinOffset = prefixVerifier.lastOffset;
      const joinSelection: MathSelectionSnapshot = {
        ranges: [[joinOffset, joinOffset]],
        direction: "none",
      };

      const selectionByLineId = Object.fromEntries(
        linesRef.current.flatMap((line) => {
          const currentField = fieldRefs.current.get(line.id);
          return currentField?.isConnected
            ? [[line.id, captureSelection(currentField)] as const]
            : [];
        }),
      );
      const before = getEditorDocumentSnapshot(selectionByLineId);
      before.lines = before.lines.map((line) => {
        const currentField = fieldRefs.current.get(line.id);
        return currentField?.isConnected
          ? { ...line, latex: normalizeChineseLatex(currentField.value) }
          : line;
      });
      const removedIds = new Set(
        before.lines
          .slice(start.lineIndex + 1, end.lineIndex + 1)
          .map((line) => line.id),
      );
      const nextSelectionByLineId = { ...before.selectionByLineId };
      for (const lineId of removedIds) delete nextSelectionByLineId[lineId];
      nextSelectionByLineId[startLine.id] = joinSelection;
      const after: ReplaceDocumentEntry["after"] = {
        title: before.title,
        lines: before.lines
          .filter((line) => !removedIds.has(line.id))
          .map((line) =>
            line.id === startLine.id
              ? { ...line, latex: mergedLatex }
              : { ...line },
          ),
        activeLineId: startLine.id,
        formulaAlignment: before.formulaAlignment,
        selectionByLineId: nextSelectionByLineId,
      };

      const scrollSnapshot = captureEditorScrollSnapshot(startLine.id);
      prepareFocusBeforeStructuralRemoval(startLine.id, joinSelection);
      clearMultiLineSelection();
      flushSync(() => useEditorStore.getState().replaceDocumentState(after));
      linesRef.current = useEditorStore.getState().lines;
      setActiveLine(startLine.id);
      historyManager.push({
        type: "replace-document",
        before,
        after,
        source: "delete-multi-line",
        timestamp: Date.now(),
      });
      setQuery("");
      selectSuggestionIndex(0);
      finalizeFocusAfterStructuralRemoval(startLine.id, joinSelection);
      stabilizeEditorScroll(scrollSnapshot, startLine.id, false);
      return true;
    };

    const removeEmptyLine = (index: number) => {
      const state = useEditorStore.getState();
      if (state.lines.length <= 1) return;
      const removedLine = state.lines[index];
      if (!removedLine) return;

      historyManager.commitPendingTransaction();
      const removedField = fieldRefs.current.get(removedLine.id);
      const beforeSelection = removedField
        ? captureSelection(removedField)
        : null;
      const remainingLines = state.lines.filter(
        (line) => line.id !== removedLine.id,
      );
      const targetIndex = Math.max(0, index - 1);
      const targetLine = remainingLines[targetIndex] ?? remainingLines[0];
      if (!targetLine) return;
      const targetField = fieldRefs.current.get(targetLine.id);
      const targetEnd = targetField?.lastOffset ?? targetLine.latex.length;
      const afterSelection: MathSelectionSnapshot = {
        ranges: [[targetEnd, targetEnd]],
        direction: "none",
      };

      const scrollSnapshot = captureEditorScrollSnapshot(targetLine.id);
      const nextDocument: ReplaceDocumentEntry["after"] = {
        title: state.title,
        lines: remainingLines.map((line) => ({ ...line })),
        activeLineId: targetLine.id,
        formulaAlignment: state.formulaAlignment,
        selectionByLineId: {
          [targetLine.id]: afterSelection,
        },
      };
      prepareFocusBeforeStructuralRemoval(targetLine.id, afterSelection);
      flushSync(() => state.replaceDocumentState(nextDocument));
      linesRef.current = useEditorStore.getState().lines;
      setActiveLine(targetLine.id);

      const entry: RemoveLineEntry = {
        type: "remove-line",
        line: { ...removedLine },
        index,
        beforeActiveLineId: removedLine.id,
        afterActiveLineId: targetLine.id,
        beforeSelection,
        afterSelection,
        timestamp: Date.now(),
      };
      historyManager.push(entry);
      setQuery("");
      finalizeFocusAfterStructuralRemoval(targetLine.id, afterSelection);
      stabilizeEditorScroll(scrollSnapshot, targetLine.id, false);
    };

    const scheduleUnconsumedMathSpace = (
      lineId: string,
      field: MathfieldElement,
    ) => {
      const beforeNativeSpace = captureFieldSnapshot(field);
      queueMicrotask(() => {
        if (!field.isConnected) return;
        const afterNativeSpace = captureFieldSnapshot(field);
        if (
          beforeNativeSpace.latex !== afterNativeSpace.latex ||
          JSON.stringify(beforeNativeSpace.selection) !==
            JSON.stringify(afterNativeSpace.selection)
        ) {
          return;
        }

        const inserted = applyDiscreteFormulaMutation(
          lineId,
          field,
          "keyboard",
          () =>
            field.insert("\\ ", {
              mode: "math",
              format: "latex",
              insertionMode: "replaceSelection",
              selectionMode: "after",
              focus: true,
              scrollIntoView: false,
            }),
        );
        if (!inserted) return;
        suppressedSuggestionRef.current = null;
        queryRef.current = "";
        setQuery("");
        selectSuggestionIndex(0);
        focusLine(lineId, {
          latex: normalizeChineseLatex(field.value),
          selection: captureSelection(field),
        });
      });
    };

    const handleKeyDown = (
      index: number,
      lineId: string,
      event: KeyboardEvent,
      field: MathfieldElement,
    ) => {
      setActiveLine(lineId);

      if (
        (event.key === "Backspace" || event.key === "Delete") &&
        !event.altKey &&
        !event.ctrlKey &&
        !event.metaKey &&
        !event.shiftKey &&
        deleteMultiLineSelection()
      ) {
        event.preventDefault();
        event.stopImmediatePropagation();
        return;
      }

      if (
        greekLetterHotkeyLineIdRef.current &&
        greekLetterHotkeyLineIdRef.current !== lineId
      ) {
        greekLetterHotkeyLineIdRef.current = null;
      }

      const rawLatexInputActive = hasRawLatexInput(field);
      if (!rawLatexInputActive && isGreekLetterHotkeyPrefix(event)) {
        event.preventDefault();
        event.stopImmediatePropagation();
        greekLetterHotkeyLineIdRef.current = lineId;
        delete field.dataset.pendingNativeSuggestion;
        suppressedSuggestionRef.current = null;
        queryRef.current = "";
        setQuery("");
        selectSuggestionIndex(0);
        dismissNativeSuggestionPopover(field);
        return;
      }

      if (greekLetterHotkeyLineIdRef.current === lineId) {
        if (event.code === "ShiftLeft" || event.code === "ShiftRight") {
          return;
        }
        if (event.key === "Escape") {
          event.preventDefault();
          event.stopImmediatePropagation();
          greekLetterHotkeyLineIdRef.current = null;
          return;
        }
        const greekCommand = greekLetterHotkeyCommandFromEvent(event);
        greekLetterHotkeyLineIdRef.current = null;
        if (greekCommand) {
          event.preventDefault();
          event.stopImmediatePropagation();
          delete field.dataset.pendingNativeSuggestion;
          suppressedSuggestionRef.current = null;
          queryRef.current = "";
          setQuery("");
          selectSuggestionIndex(0);
          insertCommand(greekCommand, "shortcut");
          return;
        }
      }

      const formulaHotkey = rawLatexInputActive
        ? null
        : matchFormulaHotkey(event, formulaHotkeyBindings);
      if (formulaHotkey) {
        event.preventDefault();
        event.stopImmediatePropagation();
        delete field.dataset.pendingNativeSuggestion;
        suppressedSuggestionRef.current = null;
        queryRef.current = "";
        setQuery("");
        selectSuggestionIndex(0);
        insertCommand(
          resolveFormulaHotkeyCommand(formulaHotkey.target),
          "shortcut",
        );
        return;
      }

      const shortcutKey = event.key.toLocaleLowerCase();
      const primaryModifier = (event.metaKey || event.ctrlKey) && !event.altKey;
      const requestsUndo = primaryModifier && shortcutKey === "z" && !event.shiftKey;
      const requestsRedo =
        primaryModifier &&
        ((shortcutKey === "z" && event.shiftKey) ||
          (shortcutKey === "y" && !event.shiftKey));
      if (requestsUndo || requestsRedo) {
        event.preventDefault();
        event.stopPropagation();
        if (requestsRedo) historyManager.requestRedo();
        else historyManager.requestUndo();
        return;
      }

      if (
        event.key !== "ArrowDown" &&
        event.key !== "ArrowUp" &&
        event.key !== "Enter" &&
        event.key !== "Tab" &&
        event.key !== " " &&
        event.code !== "Space"
      ) {
        delete field.dataset.pendingNativeSuggestion;
      }

      const normalizedFieldValue = normalizeChineseLatex(field.value);
      const suppressedSuggestion = suppressedSuggestionRef.current;
      const suppressesCurrentTrailingCommand =
        suppressedSuggestion?.lineId === lineId &&
        suppressedSuggestion.value.trim() === normalizedFieldValue.trim();
      const rawCommandActive = hasRawLatexInput(field);
      const liveQuery =
        suppressesCurrentTrailingCommand || rawCommandActive
          ? ""
          : trailingCommandQuery(field);
      const candidateQuery =
        suppressesCurrentTrailingCommand || rawCommandActive
          ? ""
          : liveQuery || query;
      const currentState = useEditorStore.getState();
      const liveSuggestions = candidateQuery
        ? visibleCommandSuggestions(
            candidateQuery,
            currentState.usage,
            currentState.personalize,
            currentState.suggestionCount,
            currentState.inputBehavior,
          )
        : [];
      const wrapperQuery =
        rawCommandQuery(field) || trailingCommandQuery(field) || candidateQuery;
      const wrapperCommand = wrapperQuery
        ? exactWrapperCommand(wrapperQuery)
        : null;
      const confirmsWrapperCommand =
        wrapperCommand &&
        !event.metaKey &&
        !event.ctrlKey &&
        !event.altKey &&
        (event.key === "Enter" ||
          event.key === "Tab" ||
          event.key === " " ||
          event.code === "Space");

      if (confirmsWrapperCommand) {
        event.preventDefault();
        event.stopImmediatePropagation();
        insertCommand(wrapperCommand, "candidate", wrapperQuery);
        return;
      }

      if (liveSuggestions.length) {
        if (event.key === "ArrowDown") {
          event.preventDefault();
          event.stopPropagation();
          selectSuggestionIndex(
            (selectedIndexRef.current + 1) % liveSuggestions.length,
          );
          return;
        }
        if (event.key === "ArrowUp") {
          event.preventDefault();
          event.stopPropagation();
          selectSuggestionIndex(
            (selectedIndexRef.current - 1 + liveSuggestions.length) % liveSuggestions.length,
          );
          return;
        }
        if (event.key === "Enter" || event.key === "Tab") {
          event.preventDefault();
          event.stopImmediatePropagation();
          const suggestionIndex = Math.min(
            selectedIndexRef.current,
            liveSuggestions.length - 1,
          );
          suppressedSuggestionRef.current = {
            lineId,
            value: normalizeChineseLatex(field.value),
          };
          queryRef.current = "";
          setQuery("");
          insertCommand(
            liveSuggestions[suggestionIndex],
            "candidate",
            candidateQuery,
          );
          return;
        }
        if (event.key === "Escape") {
          event.preventDefault();
          event.stopPropagation();
          suppressedSuggestionRef.current = {
            lineId,
            value: normalizeChineseLatex(field.value),
          };
          queryRef.current = "";
          setQuery("");
          selectSuggestionIndex(0);
          return;
        }
      }

      const nativeRecommendationVisible =
        getVisibleNativeSuggestionItems(field).length > 0;
      const pendingNativeSuggestion =
        field.dataset.pendingNativeSuggestion ?? "";
      if (
        !liveSuggestions.length &&
        (nativeRecommendationVisible || Boolean(pendingNativeSuggestion))
      ) {
        if (
          nativeRecommendationVisible &&
          (event.key === "ArrowDown" || event.key === "ArrowUp")
        ) {
          event.preventDefault();
          event.stopImmediatePropagation();
          const selectedNativeCommand = moveNativeSuggestionSelection(
            field,
            event.key === "ArrowDown" ? 1 : -1,
          );
          if (selectedNativeCommand) {
            field.dataset.pendingNativeSuggestion = selectedNativeCommand;
          }
          return;
        }
        if (
          event.key === "Enter" ||
          event.key === "Tab" ||
          event.key === " " ||
          event.code === "Space"
        ) {
          event.preventDefault();
          event.stopImmediatePropagation();
          // The remembered native command is inserted synchronously. Waiting
          // for MathLive's popover mutation here used to add up to one second
          // before the editor state and history caught up with the field.
          const committed = applyDiscreteFormulaMutation(
            lineId,
            field,
            "candidate",
            () =>
              commitNativeSuggestion(
                field,
                currentState.inputBehavior,
                pendingNativeSuggestion,
              ),
          );
          if (committed) {
            delete field.dataset.pendingNativeSuggestion;
            setQuery("");
            selectSuggestionIndex(0);
            focusLine(lineId, {
              latex: normalizeChineseLatex(field.value),
              selection: captureSelection(field),
            });
          }
          return;
        }
        if (event.key === "Escape") {
          delete field.dataset.pendingNativeSuggestion;
          // Escape only dismisses the panel and does not rebuild its rows, so
          // MathLive can safely handle it itself.
          return;
        }
      }

      if (
        event.key === "ArrowRight" &&
        !event.isComposing &&
        !event.altKey &&
        !event.ctrlKey &&
        !event.metaKey &&
        !event.shiftKey &&
        !rawCommandActive &&
        liveSuggestions.length === 0 &&
        (field.dataset.visualtexBoundedOperatorStage === "lower" ||
          field.dataset.visualtexBoundedOperatorStage === "upper")
      ) {
        if (moveBoundedOperatorRight(field)) {
          event.preventDefault();
          event.stopImmediatePropagation();
          markVisualTexStructuralPlaceholders(field);
          focusLine(lineId, {
            latex: normalizeChineseLatex(field.value),
            selection: captureSelection(field),
          });
          return;
        }
      }

      if (
        event.key === "Tab" &&
        !event.isComposing &&
        !event.altKey &&
        !event.ctrlKey &&
        !event.metaKey &&
        !event.shiftKey &&
        !rawCommandActive &&
        liveSuggestions.length === 0 &&
        (field.dataset.visualtexBoundedOperatorStage === "lower" ||
          field.dataset.visualtexBoundedOperatorStage === "upper")
      ) {
        if (moveBoundedOperatorRight(field)) {
          event.preventDefault();
          event.stopImmediatePropagation();
          markVisualTexStructuralPlaceholders(field);
          focusLine(lineId, {
            latex: normalizeChineseLatex(field.value),
            selection: captureSelection(field),
          });
          return;
        }
      }

      const alignmentCaretDepth =
        field.getElementInfo(field.position)?.depth ??
        field.getElementInfo(Math.max(0, field.position - 1))?.depth ??
        0;
      const insertsExplicitAlignmentPoint =
        usesExplicitAlignmentPoints(latexCodeFormat) &&
        alignmentCaretDepth === 0 &&
        event.key === "&" &&
        !event.isComposing &&
        !event.altKey &&
        !event.ctrlKey &&
        !event.metaKey &&
        field.mode !== "latex" &&
        !rawCommandActive &&
        activeMathLiveEnvironmentName(field) === null;
      if (insertsExplicitAlignmentPoint) {
        event.preventDefault();
        event.stopImmediatePropagation();
        const inserted = applyDiscreteFormulaMutation(
          lineId,
          field,
          "keyboard",
          () =>
            field.insert(VISUALTEX_ALIGNMENT_MARKER_LATEX, {
              mode: "math",
              format: "latex",
              insertionMode: "replaceSelection",
              selectionMode: "after",
              focus: true,
              scrollIntoView: false,
            }),
        );
        if (inserted) {
          suppressedSuggestionRef.current = null;
          queryRef.current = "";
          setQuery("");
          selectSuggestionIndex(0);
          focusLine(lineId, {
            latex: normalizeChineseLatex(field.value),
            selection: captureSelection(field),
          });
        }
        return;
      }

      const insertsVisibleMathSpace =
        !event.isComposing &&
        !event.altKey &&
        !event.ctrlKey &&
        !event.metaKey &&
        !event.shiftKey &&
        (event.key === " " || event.code === "Space") &&
        !rawCommandActive &&
        field.mode !== "latex" &&
        !field.dataset.pendingWrapperCommand &&
        liveSuggestions.length === 0;
      if (insertsVisibleMathSpace) {
        scheduleUnconsumedMathSpace(lineId, field);
        return;
      }

      if (
        event.key === "Enter" &&
        activeMathLiveEnvironmentName(field) === "cases"
      ) {
        event.preventDefault();
        event.stopImmediatePropagation();
        const insertedRow = applyDiscreteFormulaMutation(
          lineId,
          field,
          "keyboard",
          () => field.executeCommand("addRowAfter"),
        );
        if (insertedRow) {
          suppressedSuggestionRef.current = null;
          queryRef.current = "";
          setQuery("");
          selectSuggestionIndex(0);
          focusLine(lineId, {
            latex: normalizeChineseLatex(field.value),
            selection: captureSelection(field),
          });
        }
        return;
      }

      if (event.key === "Enter") {
        event.preventDefault();
        event.stopImmediatePropagation();
        const currentLineMode =
          currentState.lines.find((line) => line.id === lineId)?.mode ??
          "display";
        const requestedMode = resolveNewFormulaLineMode(
          latexCodeFormat,
          currentLineMode,
          event,
        );
        splitLineAtCaret(index, lineId, field, requestedMode);
        return;
      }

      if (event.key === "Backspace" || event.key === "Delete") {
        const visibleLatex = field
          .getValue("latex-without-placeholders")
          .trim();
        const rawCommandInput = rawLatexInput(field);
        const state = useEditorStore.getState();
        const currentLine = state.lines.find((line) => line.id === lineId);
        const trulyEmpty = Boolean(
          currentLine &&
            visibleLatex.length === 0 &&
            rawCommandInput.length === 0 &&
            normalizeChineseLatex(field.value).trim().length === 0 &&
            currentLine.latex.trim().length === 0,
        );

        // Backspace on a truly empty row restores the multiline editor's
        // previous-row behavior. This check must happen before the raw-LaTeX
        // mode guard because MathLive can remain in `latex` mode after the
        // final raw command character has already been deleted.
        if (
          event.key === "Backspace" &&
          trulyEmpty &&
          field.selectionIsCollapsed &&
          !event.altKey &&
          !event.ctrlKey &&
          !event.metaKey &&
          !event.shiftKey
        ) {
          event.preventDefault();
          event.stopImmediatePropagation();
          removeEmptyLine(index);
          return;
        }

        // While MathLive is collecting a non-empty raw LaTeX command such as
        // `\\mat`, its public formula value is intentionally still empty. Let
        // MathLive consume Backspace/Delete natively so one physical key
        // removes one raw command character instead of deleting the row.
        if (rawCommandInput || (field.mode === "latex" && !trulyEmpty)) return;

        // Preserve MathLive's native word/line deletion shortcuts such as
        // Option+Backspace and Command+Backspace on macOS.
        if (event.altKey || event.ctrlKey || event.metaKey || event.shiftKey) {
          return;
        }

        if (
          event.key === "Backspace" &&
          field.selectionIsCollapsed &&
          field.position === 0
        ) {
          event.preventDefault();
          event.stopImmediatePropagation();
          mergeLineWithPrevious(index, lineId, field);
          return;
        }

        event.preventDefault();
        event.stopImmediatePropagation();

        if (!currentLine) return;
        const before = captureFieldSnapshot(field);
        const beforePosition = field.position;
        const command =
          event.key === "Backspace" ? "deleteBackward" : "deleteForward";

        const trailingStructuredLatex =
          event.key === "Backspace"
            ? field.getElementInfo(beforePosition)?.latex?.trim() ?? ""
            : "";
        suppressedHistoryLineIdRef.current = lineId;
        try {
          field.executeCommand(command);
          if (
            event.key === "Backspace" &&
            field.value === before.latex &&
            scriptContainerPattern.test(trailingStructuredLatex)
          ) {
            // MathLive first moves into a terminal super/subscript container
            // without deleting anything. Complete the same Backspace action by
            // deleting its final atom so the editor cannot become stuck there.
            field.executeCommand("deleteBackward");
          }
        } finally {
          suppressedHistoryLineIdRef.current = null;
        }

        if (event.key === "Backspace" && field.selectionIsCollapsed) {
          keepCaretAfterBareStructuredOperator(field, beforePosition);
        }

        const after = captureFieldSnapshot(field);
        if (before.latex === after.latex) {
          field.focus();
          return;
        }

        state.replaceFormulaLine(lineId, after.latex);
        state.setActiveLineId(lineId);
        linesRef.current = useEditorStore.getState().lines;
        field.resetUndo();
        historyManager.recordFormulaEdit({
          lineId,
          beforeLatex: currentLine.latex,
          afterLatex: after.latex,
          beforeSelection: before.selection,
          afterSelection: after.selection,
          beforeActiveLineId: state.activeLineId,
          afterActiveLineId: lineId,
          editKind:
            event.key === "Backspace"
              ? "delete-backward"
              : "delete-forward",
          source: "keyboard",
        });
        return;
      }

      if (
        (event.key === "ArrowUp" || event.key === "ArrowDown") &&
        !event.altKey &&
        !event.ctrlKey &&
        !event.metaKey &&
        !event.shiftKey
      ) {
        const scriptRegion = getScriptCaretRegion(field);
        const requestedRegion = event.key === "ArrowUp" ? "upper" : "lower";
        if (scriptRegion) {
          event.preventDefault();
          event.stopImmediatePropagation();
          if (scriptRegion !== requestedRegion) {
            field.executeCommand("moveToOpposite");
          }
          return;
        }

        // Chromium can report a successful vertical MathLive movement even for
        // a flat formula such as \\alpha, which traps ArrowUp/ArrowDown on the
        // current row. WebKit returns false in that case. Restrict native
        // vertical navigation to formulas that actually have vertical
        // structure so Windows matches the verified macOS row behavior.
        if (tallFormulaPattern.test(field.value)) {
          const beforeSelection = captureSelection(field);
          const movedInsideFormula = field.executeCommand(
            event.key === "ArrowUp" ? "moveUp" : "moveDown",
          );
          const afterSelection = captureSelection(field);
          if (
            movedInsideFormula &&
            JSON.stringify(beforeSelection) !== JSON.stringify(afterSelection)
          ) {
            event.preventDefault();
            event.stopImmediatePropagation();
            return;
          }
        }

        const direction = event.key === "ArrowUp" ? -1 : 1;
        const targetIndex = index + direction;
        const targetLine = linesRef.current[targetIndex];
        if (targetLine) {
          event.preventDefault();
          event.stopImmediatePropagation();
          historyManager.commitPendingTransaction();
          queryRef.current = "";
          setQuery("");

          const targetField = fieldRefs.current.get(targetLine.id);
          const targetPosition = Math.max(
            0,
            Math.min(
              field.position,
              targetField?.lastOffset ?? targetLine.latex.length,
            ),
          );
          const targetSelection: MathSelectionSnapshot = {
            ranges: [[targetPosition, targetPosition]],
            direction: "none",
          };
          setActiveLine(targetLine.id);
          if (targetField?.isConnected) {
            const applyTargetFocus = () => {
              setActiveLine(targetLine.id);
              targetField.focus();
              targetField.shadowRoot
                ?.querySelector<HTMLElement>('[part="keyboard-sink"]')
                ?.focus({ preventScroll: true });
              targetField.selection = targetSelection;
              targetField.position = targetPosition;
            };
            applyTargetFocus();
            window.requestAnimationFrame(applyTargetFocus);
            window.setTimeout(applyTargetFocus, 0);
            window.setTimeout(applyTargetFocus, 80);
          } else {
            focusLine(targetLine.id, {
              latex: targetLine.latex,
              selection: targetSelection,
            });
          }
          return;
        }
      }

      if (
        event.key.startsWith("Arrow") ||
        event.key === "Home" ||
        event.key === "End"
      ) {
        historyManager.commitPendingTransaction();
      }
    };

    const normalizeInsertedFormulaLines = (latex: string) => {
      const normalized = latex.replace(/\r\n?/g, "\n");
      const trimmed = normalized.trim();
      if (isSingleCompleteLatexEnvironment(trimmed)) {
        return [normalizeChineseLatex(trimmed)];
      }
      return normalized
        .split("\n")
        .map((line) => normalizeChineseLatex(line.trim()))
        .filter(Boolean);
    };

    const normalizeInsertedLatex = (latex: string) =>
      normalizeInsertedFormulaLines(latex).join("\\quad ");

    const getSelectionMap = (): Record<string, MathSelectionSnapshot> =>
      Object.fromEntries(
        linesRef.current.flatMap((line) => {
          const field = fieldRefs.current.get(line.id);
          return field?.isConnected
            ? [[line.id, captureSelection(field)] as const]
            : [];
        }),
      );

    const captureInsertionTarget = (): MathEditorInsertionTarget | null => {
      const target = resolveTargetField();
      if (!target) return null;
      const selection = captureSelection(target.field);
      return {
        lineId: target.lineId,
        ranges: selection.ranges,
        direction: selection.direction,
      };
    };

    const captureSelectionTarget = (): MathEditorSelectionTarget | null => {
      const selections = linesRef.current.flatMap((line) => {
        const field = fieldRefs.current.get(line.id);
        if (!field?.isConnected) return [];
        const selection = captureSelection(field);
        if (!selectionHasContent(selection)) return [];
        return [
          {
            lineId: line.id,
            ranges: selection.ranges,
            direction: selection.direction,
          } satisfies MathEditorInsertionTarget,
        ];
      });
      if (selections.length) {
        const target = { selections };
        lastSelectionTargetRef.current = target;
        return target;
      }
      lastSelectionTargetRef.current = null;
      return null;
    };

    const applySelectionStyle = (
      style: MathEditorSelectionStyle,
      target: MathEditorSelectionTarget | null = captureSelectionTarget(),
    ) => {
      if (interactionReadOnly || !target?.selections.length) return false;
      if (
        (style.kind === "color" || style.kind === "backgroundColor") &&
        !isSafeFormulaStyleColor(style.value)
      ) {
        return false;
      }
      const resolved = target.selections.flatMap((selectionTarget) => {
        const field = fieldRefs.current.get(selectionTarget.lineId);
        if (!field?.isConnected) return [];
        const selection = clampSelection(
          {
            ranges: selectionTarget.ranges,
            direction: selectionTarget.direction,
          },
          field.lastOffset,
        );
        if (!selectionHasContent(selection)) return [];
        field.selection = selection;
        return [{ lineId: selectionTarget.lineId, field, selection }];
      });
      if (!resolved.length) return false;

      historyManager.commitPendingTransaction();
      for (const entry of resolved) {
        const { field, lineId } = entry;
        field.selection = entry.selection;
        if (style.kind === "bold" || style.kind === "italic") {
          const original = captureFieldSnapshot(field);
          const toggled = applyDiscreteFormulaMutation(
            lineId,
            field,
            "toolbar",
            () => {
              const nextRanges: Array<[number, number]> = [];
              let changed = false;
              const ranges = [...entry.selection.ranges]
                .map(([start, end]) => [Math.min(start, end), Math.max(start, end)] as [number, number])
                .sort((left, right) => right[0] - left[0]);
              for (const [start, end] of ranges) {
                const singleSelection: MathSelectionSnapshot = {
                  ranges: [[start, end]],
                  direction: "forward",
                };
                field.selection = singleSelection;
                const selectedLatex = field.getValue(singleSelection, "latex").trim();
                if (!selectedLatex) continue;
                const replacement = toggleFormulaSelectionLatex(
                  selectedLatex,
                  style.kind satisfies FormulaSelectionToggleKind,
                  {
                    allBold:
                      field.queryStyle({ variantStyle: "bold" }) === "all",
                    allBoldItalic:
                      field.queryStyle({ variantStyle: "bolditalic" }) === "all",
                    allItalic:
                      field.queryStyle({ variantStyle: "italic" }) === "all",
                    allUpright:
                      field.queryStyle({ variantStyle: "up" }) === "all",
                  },
                );
                if (!replacement || replacement === selectedLatex) {
                  nextRanges.push([start, end]);
                  continue;
                }
                const inserted = field.insert(replacement, {
                  mode: "math",
                  format: "latex",
                  insertionMode: "replaceSelection",
                  selectionMode: "after",
                  style: {
                    variant: "normal",
                    variantStyle: undefined,
                  },
                  focus: true,
                  scrollIntoView: false,
                });
                if (!inserted) {
                  field.setValue(original.latex, {
                    mode: "math",
                    format: "latex",
                    insertionMode: "replaceAll",
                    selectionMode: "after",
                    silenceNotifications: true,
                  });
                  field.selection = original.selection;
                  return false;
                }
                const nextEnd = field.position;
                const delta = nextEnd - end;
                for (const range of nextRanges) {
                  if (range[0] >= end) {
                    range[0] += delta;
                    range[1] += delta;
                  }
                }
                nextRanges.push([start, nextEnd]);
                changed = true;
              }
              const nextSelection = clampSelection(
                {
                  ranges: nextRanges.sort((left, right) => left[0] - right[0]),
                  direction: entry.selection.direction,
                },
                field.lastOffset,
              );
              field.selection = nextSelection;
              return changed;
            },
          );
          if (!toggled) field.selection = entry.selection;
          entry.selection = captureSelection(field);
          continue;
        }

        let mathLiveStyle: Pick<
          Style,
          "variant" | "variantStyle" | "color" | "backgroundColor"
        >;
        if (style.kind === "color") {
          mathLiveStyle = { color: style.value };
        } else {
          mathLiveStyle = { backgroundColor: style.value };
        }
        for (const [start, end] of entry.selection.ranges) {
          const range: [number, number] = [
            Math.min(start, end),
            Math.max(start, end),
          ];
          if (range[0] === range[1]) continue;
          field.applyStyle(mathLiveStyle, {
            range,
            operation: "set",
          });
        }
        // MathLive normally derives the implicit style for future input from
        // the atom immediately before the caret. If the formatted selection
        // includes the last atom, typing at the end would otherwise inherit
        // its color/background even though these controls are selection-only.
        const resetPosition = Math.max(
          ...entry.selection.ranges.flatMap(([start, end]) => [start, end]),
        );
        field.selection = {
          ranges: [[resetPosition, resetPosition]],
          direction: "none",
        };
        field.applyStyle(
          style.kind === "color"
            ? { color: "none" }
            : { backgroundColor: "none" },
          { operation: "set" },
        );
        field.selection = entry.selection;
      }
      historyManager.commitPendingTransaction();

      const activeSelection =
        resolved.find(({ lineId }) => lineId === activeLineIdRef.current) ??
        resolved.at(-1);
      if (activeSelection) {
        setActiveLine(activeSelection.lineId);
        activeSelection.field.focus();
        activeSelection.field.selection = activeSelection.selection;
        activeSelection.field.shadowRoot
          ?.querySelector<HTMLElement>('[part="keyboard-sink"]')
          ?.focus({ preventScroll: true });
      }
      lastSelectionTargetRef.current = null;
      return true;
    };

    const restoreSelection = (
      lineId: string,
      latex: string,
      selection: MathSelectionSnapshot | null,
    ): Promise<boolean> =>
      new Promise((resolve) => {
        const index = linesRef.current.findIndex((line) => line.id === lineId);
        if (index < 0) {
          resolve(false);
          return;
        }
        historyManager.commitPendingTransaction();
        const requestId = ++focusRequestRef.current;
        activeIndexRef.current = index;
        activeLineIdRef.current = lineId;
        setActiveIndex(index);
        useEditorStore.getState().setActiveLineId(lineId);
        pendingFocusRef.current = {
          lineId,
          latex,
          selection,
          moveToEnd: !selection,
          deferredRepair: true,
        };

        let attempts = 12;
        const attempt = () => {
          const applied = applyFocusState(
            lineId,
            latex,
            selection,
            !selection,
            requestId,
          );
          if (applied) {
            pendingFocusRef.current = null;
            window.requestAnimationFrame(() => {
              applyFocusState(lineId, latex, selection, !selection, requestId);
              window.setTimeout(
                () =>
                  applyFocusState(
                    lineId,
                    latex,
                    selection,
                    !selection,
                    requestId,
                  ),
                80,
              );
            });
            resolve(true);
            return;
          }
          attempts -= 1;
          if (attempts <= 0) {
            resolve(false);
            return;
          }
          window.requestAnimationFrame(() => window.setTimeout(attempt, 16));
        };
        attempt();
      });

    const insertMultipleLatexRowsAt = (
      target: MathEditorInsertionTarget,
      values: readonly string[],
      source: FormulaEditSource,
    ): boolean => {
      if (values.length < 2) return false;
      const targetIndex = linesRef.current.findIndex(
        (line) => line.id === target.lineId,
      );
      if (targetIndex < 0) return false;
      const field = fieldRefs.current.get(target.lineId);
      if (!field?.isConnected) return false;

      const selection = clampSelection(
        {
          ranges: target.ranges.length
            ? target.ranges
            : [[field.lastOffset, field.lastOffset]],
          direction: target.direction,
        },
        field.lastOffset,
      );
      historyManager.commitPendingTransaction();
      const before = getEditorDocumentSnapshot(getSelectionMap());
      setActiveLine(target.lineId);
      field.focus();

      suppressedHistoryLineIdRef.current = target.lineId;
      let inserted = false;
      try {
        field.selection = selection;
        inserted = Boolean(
          field.insert(values[0], {
            mode: "math",
            format: "latex",
            insertionMode: "replaceSelection",
            selectionMode: "after",
            focus: true,
            scrollIntoView: false,
          }),
        );
        if (!inserted) return false;
        const normalized = normalizeChineseLatex(field.value);
        if (normalized !== field.value) {
          field.setValue(normalized, { silenceNotifications: true });
        }
      } finally {
        suppressedHistoryLineIdRef.current = null;
      }
      if (!inserted) return false;

      const firstLatex = normalizeChineseLatex(field.value);
      const firstSelection = captureSelection(field);
      const currentLines = useEditorStore.getState().lines;
      const currentTargetIndex = currentLines.findIndex(
        (line) => line.id === target.lineId,
      );
      if (currentTargetIndex < 0) return false;
      const additionalLines = values.slice(1).map((value) => createFormulaLine(value));
      const nextLines = currentLines.map((line) =>
        line.id === target.lineId ? { ...line, latex: firstLatex } : { ...line },
      );
      nextLines.splice(currentTargetIndex + 1, 0, ...additionalLines);
      const lastLine = additionalLines[additionalLines.length - 1];
      const lastSelection: MathSelectionSnapshot = {
        ranges: [[Number.MAX_SAFE_INTEGER, Number.MAX_SAFE_INTEGER]],
        direction: "none",
      };
      const after: ReplaceDocumentEntry["after"] = {
        title: before.title,
        lines: nextLines,
        activeLineId: lastLine.id,
        formulaAlignment: before.formulaAlignment,
        selectionByLineId: {
          ...before.selectionByLineId,
          [target.lineId]: firstSelection,
          [lastLine.id]: lastSelection,
        },
      };

      flushSync(() => useEditorStore.getState().replaceDocumentState(after));
      linesRef.current = useEditorStore.getState().lines;
      field.resetUndo();
      historyManager.push({
        type: "replace-document",
        before,
        after,
        source: source === "paste" ? "paste-multi-line" : "ocr",
        timestamp: Date.now(),
      });
      setQuery("");
      selectSuggestionIndex(0);
      focusLine(lastLine.id, {
        latex: lastLine.latex,
        moveToEnd: true,
      });
      return true;
    };

    const prepareOcrAlignmentFormat = (
      values: readonly string[],
      source: FormulaEditSource,
    ) => {
      if (
        source === "ocr" &&
        values.some((value) => hasVisualTexAlignmentMarker(value))
      ) {
        useEditorStore.getState().setLatexCodeFormat("aligned");
      }
    };

    const insertLatex = (
      latex: string,
      source: FormulaEditSource = "ocr",
    ) => {
      const values = normalizeInsertedFormulaLines(latex);
      if (!values.length) return;
      prepareOcrAlignmentFormat(values, source);
      const target = resolveTargetField();
      if (!target) return;
      if (values.length > 1) {
        const selection = captureSelection(target.field);
        insertMultipleLatexRowsAt(
          {
            lineId: target.lineId,
            ranges: selection.ranges,
            direction: selection.direction,
          },
          values,
          source,
        );
        return;
      }

      const value = values[0];
      const { lineId, field } = target;
      setActiveLine(lineId);
      field.focus();
      const inserted = applyDiscreteFormulaMutation(
        lineId,
        field,
        source,
        () =>
          field.insert(value, {
            mode: "math",
            format: "latex",
            insertionMode: "replaceSelection",
            selectionMode: "after",
            focus: true,
            scrollIntoView: false,
          }),
      );
      if (!inserted) return;
      setQuery("");
      selectSuggestionIndex(0);
      focusLine(lineId, {
        latex: normalizeChineseLatex(field.value),
        selection: captureSelection(field),
      });
    };

    const insertLatexAt = (
      target: MathEditorInsertionTarget,
      latex: string,
      source: FormulaEditSource = "ocr",
    ): boolean => {
      const values = normalizeInsertedFormulaLines(latex);
      if (!values.length) return false;
      prepareOcrAlignmentFormat(values, source);
      if (values.length > 1) {
        return insertMultipleLatexRowsAt(target, values, source);
      }
      const value = values[0];
      if (!linesRef.current.some((line) => line.id === target.lineId)) {
        return false;
      }
      const field = fieldRefs.current.get(target.lineId);
      if (!field?.isConnected) return false;

      const selection = clampSelection(
        {
          ranges: target.ranges.length
            ? target.ranges
            : [[field.lastOffset, field.lastOffset]],
          direction: target.direction,
        },
        field.lastOffset,
      );
      setActiveLine(target.lineId);
      field.focus();
      const inserted = applyDiscreteFormulaMutation(
        target.lineId,
        field,
        source,
        () => {
          field.selection = selection;
          return field.insert(value, {
            mode: "math",
            format: "latex",
            insertionMode: "replaceSelection",
            selectionMode: "after",
            focus: true,
            scrollIntoView: false,
          });
        },
      );
      if (!inserted) return false;
      setQuery("");
      selectSuggestionIndex(0);
      focusLine(target.lineId, {
        latex: normalizeChineseLatex(field.value),
        selection: captureSelection(field),
      });
      return true;
    };

    const appendLatex = (
      latex: string,
      source: FormulaEditSource = "ocr",
    ) => {
      const values = latex
        .replace(/\r\n?/g, "\n")
        .split("\n")
        .map((line) => normalizeChineseLatex(line.trim()))
        .filter(Boolean);
      if (!values.length) return;
      prepareOcrAlignmentFormat(values, source);

      historyManager.commitPendingTransaction();
      const before = getEditorDocumentSnapshot(getSelectionMap());
      const currentLines = useEditorStore.getState().lines;
      const replacesOnlyBlankLine =
        currentLines.length === 1 && !currentLines[0].latex.trim();
      const nextLines = replacesOnlyBlankLine
        ? values.map((value, index) =>
            index === 0
              ? { ...currentLines[0], latex: value }
              : createFormulaLine(value),
          )
        : [...currentLines, ...values.map((value) => createFormulaLine(value))];
      const lastLine = nextLines[nextLines.length - 1];
      const afterSelection: MathSelectionSnapshot = {
        ranges: [[Number.MAX_SAFE_INTEGER, Number.MAX_SAFE_INTEGER]],
        direction: "none",
      };
      const after: ReplaceDocumentEntry["after"] = {
        title: before.title,
        lines: nextLines.map((line) => ({ ...line })),
        activeLineId: lastLine.id,
        formulaAlignment: before.formulaAlignment,
        selectionByLineId: {
          ...before.selectionByLineId,
          [lastLine.id]: afterSelection,
        },
      };

      flushSync(() => useEditorStore.getState().replaceDocumentState(after));
      linesRef.current = useEditorStore.getState().lines;
      const entry: ReplaceDocumentEntry = {
        type: "replace-document",
        before,
        after,
        source: "ocr",
        timestamp: Date.now(),
      };
      historyManager.push(entry);
      setQuery("");
      focusLine(lastLine.id, {
        latex: lastLine.latex,
        moveToEnd: true,
      });
    };

    useImperativeHandle(ref, () => ({
      insertCommand,
      insertLatex,
      insertLatexAt,
      appendLatex,
      focus: (options = {}) => {
        const target = options.target ?? "active";
        const lineId =
          target === "first"
            ? linesRef.current[0]?.id
            : target === "last"
              ? linesRef.current.at(-1)?.id
              : activeLineIdRef.current ?? linesRef.current[0]?.id;
        if (lineId) {
          focusLine(lineId, {
            moveToEnd: options.moveToEnd ?? false,
          });
        }
      },
      addLine: () => addLineAfter(linesRef.current.length - 1),
      commitPendingTransaction: () => historyManager.commitPendingTransaction(),
      getSelectionMap,
      restoreSelection,
      captureSelectionTarget,
      captureInsertionTarget,
      applySelectionStyle,
      refreshLayout: () => {
        flushSync(() => {
          setFieldRenderEpoch((epoch) => epoch + 1);
        });
        window.dispatchEvent(new Event(EDITOR_LAYOUT_REFRESH_EVENT));
      },
    }));

    useEffect(() => {
      selectedIndexRef.current = selectedIndex;
      // A caret/selection refresh can briefly hide the candidate list before
      // restoring the same query. Do not reset the highlighted row during that
      // transient empty state; a genuinely new query is reset explicitly in
      // refreshSuggestionQuery().
      if (
        suggestions.length > 0 &&
        selectedIndex >= suggestions.length
      ) {
        selectSuggestionIndex(suggestions.length - 1);
      }
    }, [suggestions.length, selectedIndex]);

    useEffect(() => {
      if (!suggestions.length) return;
      const lineId = activeLineIdRef.current;
      const field = lineId ? fieldRefs.current.get(lineId) : null;
      if (!field?.isConnected) return;

      const reposition = () => {
        if (field.isConnected) updatePopupPosition(field);
      };
      const editorScroll =
        surfaceRef.current?.closest<HTMLElement>(".editor-pane-scroll") ?? null;
      const resizeObserver = new ResizeObserver(reposition);
      if (surfaceRef.current) resizeObserver.observe(surfaceRef.current);
      window.addEventListener("resize", reposition);
      editorScroll?.addEventListener("scroll", reposition, { passive: true });
      reposition();

      return () => {
        resizeObserver.disconnect();
        window.removeEventListener("resize", reposition);
        editorScroll?.removeEventListener("scroll", reposition);
      };
    }, [activeLineId, suggestions.length]);

    useEffect(() => {
      queryRef.current = query;
    }, [query]);

    useEffect(() => {
      const surface = surfaceRef.current;
      if (!surface) return;

      const handleSurfacePointerDown = (event: PointerEvent) => {
        if (event.button !== 0 || !event.isPrimary || event.shiftKey) return;
        lastSelectionTargetRef.current = null;
        const path = event.composedPath();
        const entry = Array.from(fieldRefs.current.entries()).find(
          ([, field]) =>
            path.includes(field) ||
            Boolean(field.parentElement && path.includes(field.parentElement)),
        );
        if (!entry) return;

        if (previewOnlyRef.current) {
          event.preventDefault();
          event.stopImmediatePropagation();
          if (!onPreviewActivate) {
            document
              .querySelector<HTMLElement>(".source-panel .cm-content")
              ?.focus({ preventScroll: true });
            return;
          }
          previewOnlyRef.current = false;
          for (const field of fieldRefs.current.values()) {
            if (!field.isConnected) continue;
            field.classList.remove(visualTexSourcePreviewClass);
            field.readOnly = readOnly;
          }
          onPreviewActivate?.();

          const [lineId, field] = entry;
          const offset = Math.max(
            0,
            Math.min(
              field.getOffsetFromPoint(event.clientX, event.clientY, { bias: 0 }),
              field.lastOffset,
            ),
          );
          field.focus();
          field.position = offset;
          field.shadowRoot
            ?.querySelector<HTMLElement>('[part="keyboard-sink"]')
            ?.focus({ preventScroll: true });
          setActiveLine(lineId);
          return;
        }

        clearMultiLineSelection();
        const contentBounds = entry[1].shadowRoot
          ?.querySelector<HTMLElement>('[part="content"]')
          ?.getBoundingClientRect();
        const startedOutsideFormula = Boolean(
          contentBounds &&
            (event.clientX < contentBounds.left - 6 ||
              event.clientX > contentBounds.right + 6),
        );
        const anchor = resolveMultiLineSelectionPoint(
          event.clientX,
          event.clientY,
          entry[0],
        );
        if (!anchor) return;
        pointerSelectionSessionRef.current = {
          pointerId: event.pointerId,
          startX: event.clientX,
          startY: event.clientY,
          anchor,
          allowSameLine: startedOutsideFormula,
          active: false,
        };
      };

      const handleWindowPointerMove = (event: PointerEvent) => {
        const session = pointerSelectionSessionRef.current;
        if (!session) {
          if (multiLineSelectionRef.current && event.buttons === 0) {
            event.stopImmediatePropagation();
          }
          return;
        }
        if (event.pointerId !== session.pointerId) return;
        const distance = Math.hypot(
          event.clientX - session.startX,
          event.clientY - session.startY,
        );
        if (!session.active && distance < 5) return;

        const focus = resolveMultiLineSelectionPoint(
          event.clientX,
          event.clientY,
        );
        if (!focus) return;
        if (
          !session.active &&
          focus.lineId === session.anchor.lineId &&
          !session.allowSameLine
        ) {
          return;
        }
        session.active = true;
        event.preventDefault();
        event.stopImmediatePropagation();
        applyMultiLineSelection(session.anchor, focus);
      };

      const handleWindowPointerEnd = (event: PointerEvent) => {
        const session = pointerSelectionSessionRef.current;
        if (!session || event.pointerId !== session.pointerId) return;
        pointerSelectionSessionRef.current = null;
        if (!session.active) return;

        // Do not prevent or stop this pointerup. MathLive owns pointer capture
        // on the active mathfield and must finish its own drag tracker first.
        // Reapply the cross-line ranges in the next task, after MathLive's
        // target-phase pointerup handlers have completed, so later free mouse
        // movement cannot collapse the final line again.
        for (const field of fieldRefs.current.values()) {
          visualTexPointerSelectingFields.delete(field);
          field.classList.remove(visualTexPointerSelectingClass);
          removePointerPlaceholderSnapshotStyle(field);
          markVisualTexStructuralPlaceholders(field);
        }
        const selection = multiLineSelectionRef.current;
        if (!selection) return;
        window.setTimeout(() => {
          const currentSelection = multiLineSelectionRef.current;
          if (!currentSelection) return;
          applyMultiLineSelection(
            currentSelection.anchor,
            currentSelection.focus,
          );
          setActiveLine(currentSelection.focus.lineId);
        }, 0);
      };

      const handleWindowMouseMove = (event: MouseEvent) => {
        if (
          !pointerSelectionSessionRef.current &&
          multiLineSelectionRef.current &&
          event.buttons === 0
        ) {
          event.stopImmediatePropagation();
        }
      };

      const handleWindowPointerCancel = (event: PointerEvent) => {
        const session = pointerSelectionSessionRef.current;
        if (!session || event.pointerId !== session.pointerId) return;
        pointerSelectionSessionRef.current = null;
        for (const field of fieldRefs.current.values()) {
          visualTexPointerSelectingFields.delete(field);
          field.classList.remove(visualTexPointerSelectingClass);
          removePointerPlaceholderSnapshotStyle(field);
          markVisualTexStructuralPlaceholders(field);
        }
        clearMultiLineSelection();
      };

      const handleMultiLineCopy = (event: ClipboardEvent) => {
        const selection = multiLineSelectionRef.current;
        if (!selection || !event.clipboardData) return;
        const selectedLines = linesRef.current.flatMap((line) => {
          if (!multiLineSelectedIdsRef.current.has(line.id)) return [];
          const field = fieldRefs.current.get(line.id);
          if (!field?.isConnected) return [];
          const fieldSelection = captureSelection(field);
          const latex = fieldSelection.ranges
            .map(([start, end]) =>
              field.getValue(
                Math.min(start, end),
                Math.max(start, end),
                "latex-expanded",
              ),
            )
            .join("");
          return [normalizeChineseLatex(latex)];
        });
        if (selectedLines.length <= 1) return;

        const latex = selectedLines.join("\n");
        event.clipboardData.setData(
          VISUALTEX_MULTILINE_LATEX_CLIPBOARD_TYPE,
          JSON.stringify({ version: 1, lines: selectedLines }),
        );
        event.clipboardData.setData("application/x-latex", latex);
        event.clipboardData.setData("text/plain", latex);
        event.preventDefault();
        event.stopImmediatePropagation();
      };

      surface.addEventListener("pointerdown", handleSurfacePointerDown, true);
      surface.addEventListener("copy", handleMultiLineCopy, true);
      window.addEventListener("pointermove", handleWindowPointerMove, true);
      window.addEventListener("mousemove", handleWindowMouseMove, true);
      window.addEventListener("pointerup", handleWindowPointerEnd, true);
      window.addEventListener("pointercancel", handleWindowPointerCancel, true);
      return () => {
        surface.removeEventListener("pointerdown", handleSurfacePointerDown, true);
        surface.removeEventListener("copy", handleMultiLineCopy, true);
        window.removeEventListener("pointermove", handleWindowPointerMove, true);
        window.removeEventListener("mousemove", handleWindowMouseMove, true);
        window.removeEventListener("pointerup", handleWindowPointerEnd, true);
        window.removeEventListener("pointercancel", handleWindowPointerCancel, true);
      };
    });

    useEffect(() => {
      const lineId =
        lines.find((line) => line.id === activeLineId)?.id ??
        lines[0]?.id ??
        null;
      const index = lineId
        ? Math.max(0, lines.findIndex((line) => line.id === lineId))
        : 0;
      activeLineIdRef.current = lineId;
      activeIndexRef.current = index;
      setActiveIndex(index);
    }, [lines, activeLineId]);

    useEffect(() => {
      if (!contextMenu) return;
      const close = () => setContextMenu(null);
      const handleKeyDown = (event: KeyboardEvent) => {
        if (event.key === "Escape") close();
      };
      window.addEventListener("pointerdown", close);
      window.addEventListener("blur", close);
      window.addEventListener("keydown", handleKeyDown);
      return () => {
        window.removeEventListener("pointerdown", close);
        window.removeEventListener("blur", close);
        window.removeEventListener("keydown", handleKeyDown);
      };
    }, [contextMenu]);

    useEffect(() => {
      if (previewOnly) setContextMenu(null);
    }, [previewOnly]);

    const openContextMenu = (clientX: number, clientY: number) => {
      if (previewOnly) return;
      const menuWidth = 188;
      const menuHeight = 42;
      setContextMenu({
        left: Math.max(8, Math.min(clientX, window.innerWidth - menuWidth - 8)),
        top: Math.max(8, Math.min(clientY, window.innerHeight - menuHeight - 8)),
      });
    };

    const copyPngFromContextMenu = async () => {
      if (contextMenuBusy) return;
      setContextMenuBusy(true);
      setContextMenu(null);
      try {
        if (onCopyPng) {
          await onCopyPng();
        } else {
          await copyFormulaDocumentPngToClipboard(
            linesRef.current.map((line) => line.latex),
            {
              background: pngExportBackground,
              formulaLetterFont,
              formulaChineseFont,
            },
          );
        }
      } catch (error) {
        console.error("Unable to copy formula PNG from the context menu", error);
      } finally {
        setContextMenuBusy(false);
      }
    };

    return (
      <div
        ref={surfaceRef}
        className={
          "editor-surface multi-line-editor" +
          (showLineNumbers ? " has-line-numbers" : "") +
          (latexCodeFormat === "mixed-inline-display" && !interactionReadOnly
            ? " has-mixed-line-modes"
            : "") +
          (interactionReadOnly ? " is-read-only-preview" : "") +
          (previewOnly ? " is-source-preview-only" : "")
        }
        style={
          {
            "--formula-area-inset-left": `${formulaInsetLeft}px`,
            "--formula-area-inset-right": `${formulaInsetRight}px`,
            "--formula-row-vertical-inset": `${formulaRowVerticalInset}px`,
          } as CSSProperties
        }
        data-command-query={previewOnly ? "" : query}
        data-source-draft-error={draftError}
        data-active-line-id={activeLineIdRef.current ?? ""}
        data-formula-alignment={formulaAlignment}
      >
        {overlay}
        <div className="mathfield-stack">
          {lines.map((line, index) => {
            const lineId = line.id;
            return (
              <div
                className={
                  "formula-line " +
                  (lineId === activeLineIdRef.current ? "is-active " : "") +
                  (multiLineSelectedIdsRef.current.has(lineId)
                    ? "is-multi-line-selected"
                    : "")
                }
                data-line-id={lineId}
                key={reuseLineSlots ? `resident-line-slot-${index}` : lineId}
              >
                {showLineNumbers ? (
                  <span className="formula-line-number">
                    {String(index + 1).padStart(2, "0")}
                  </span>
                ) : null}
                {latexCodeFormat === "mixed-inline-display" &&
                !interactionReadOnly ? (
                  <div
                    className="formula-line-mode-toggle"
                    role="group"
                    aria-label={
                      language === "en" ? "Formula row mode" : "公式行模式"
                    }
                  >
                    <button
                      type="button"
                      className={line.mode === "inline" ? "is-active" : ""}
                      title={
                        language === "en"
                          ? "Inline · Shift+Enter for new row"
                          : "行内 · 新建时 Shift+回车"
                      }
                      onPointerDown={(event) => event.preventDefault()}
                      onClick={() => setFormulaLineMode(lineId, "inline")}
                    >
                      {language === "en" ? "Inline" : "行内"}
                    </button>
                    <button
                      type="button"
                      className={line.mode !== "inline" ? "is-active" : ""}
                      title={
                        language === "en"
                          ? "Display · Alt+Enter for new row"
                          : "行间 · 新建时 Alt+回车"
                      }
                      onPointerDown={(event) => event.preventDefault()}
                      onClick={() => setFormulaLineMode(lineId, "display")}
                    >
                      {language === "en" ? "Display" : "行间"}
                    </button>
                  </div>
                ) : null}
                <FormulaField
                  key={`formula-field-${reuseLineSlots ? index : lineId}-${fieldRenderEpoch}`}
                  lineId={lineId}
                  index={index}
                  latex={line.latex}
                  zoom={zoom}
                  formulaRowVerticalInset={formulaRowVerticalInset}
                  language={language}
                  formulaLetterFont={formulaLetterFont}
                  formulaChineseFont={formulaChineseFont}
                  autoPairDelimiters={autoPairDelimiters}
                  inputBehavior={inputBehavior}
                  readOnly={interactionReadOnly}
                  freshExternalSync={previewOnly}
                  register={registerField}
                  onEdit={handleFieldEdit}
                  onInputActivity={(field) =>
                    refreshSuggestionQuery(
                      lineId,
                      field,
                      normalizeChineseLatex(field.value),
                    )
                  }
                  onSelectionChange={rememberSelectionTarget}
                  onCommitPending={() => historyManager.commitPendingTransaction()}
                  onFocus={(_lineIndex, field) => {
                    setActiveLine(lineId);
                    const normalizedValue = normalizeChineseLatex(field.value);
                    suppressedSuggestionRef.current = {
                      lineId,
                      value: normalizedValue,
                    };
                    queryRef.current = "";
                    setQuery("");
                  }}
                  onKeyDown={(lineIndex, event, field) =>
                    handleKeyDown(lineIndex, lineId, event, field)
                  }
                  onPasteImage={onPasteImage}
                  onContextMenu={openContextMenu}
                  onPasteLatexLines={pasteLatexLines}
                />
              </div>
            );
          })}
        </div>
        {contextMenu && (
          <div
            className="formula-editor-context-menu"
            role="menu"
            aria-label={language === "en" ? "Formula actions" : "公式操作"}
            style={{ left: contextMenu.left, top: contextMenu.top }}
            onPointerDown={(event) => event.stopPropagation()}
            onContextMenu={(event) => event.preventDefault()}
          >
            <button
              type="button"
              role="menuitem"
              disabled={contextMenuBusy}
              onClick={() => void copyPngFromContextMenu()}
            >
              <ClipboardCopy size={15} />
              <span>
                {language === "en"
                  ? "Copy PNG to Clipboard"
                  : "复制 PNG 到剪贴板"}
              </span>
            </button>
          </div>
        )}
        <CommandSuggestionPopup
          suggestions={previewOnly ? [] : suggestions}
          selectedIndex={selectedIndex}
          position={popupPosition}
          usage={usage}
          onHighlight={selectSuggestionIndex}
          onCommit={(command) =>
            insertCommand(command, "candidate", queryRef.current)
          }
        />
      </div>
    );
  },
);
