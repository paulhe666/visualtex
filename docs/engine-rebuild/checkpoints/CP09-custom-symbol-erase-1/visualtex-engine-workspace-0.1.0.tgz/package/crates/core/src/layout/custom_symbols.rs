//! Asset metrics and math roles participate in the same box/limit machinery as
//! built-in symbols. Artwork is never put into the font glyph resource table.
use crate::{EngineResult,custom_symbols::{SymbolAsset,SymbolLimits},model::AtomClass,operators::{LimitMode,OperatorPart},session::NodeId};
use super::{MathStyle,boxes::{Builder,Fragment}};
impl Builder<'_>{
    pub(super) fn custom_symbol(&mut self,id:NodeId,asset:&SymbolAsset,parts:&[OperatorPart],style:MathStyle,cramped:bool,depth:usize)->EngineResult<Fragment>{
        asset.ensure_supported()?;
        let m=asset.metrics();let scale=style.scale(self.math);let mut f=Fragment::new(id,"customSymbol");
        f.advance=m.width_em*scale;f.ascent=m.ascent_em*scale;f.descent=m.descent_em*scale;
        for i in 0..asset.geometry().len(){f.artwork(asset,i,scale);}
        if asset.role()!=AtomClass::Operator{return Ok(f);}
        let stacked=match crate::operators::effective_mode(parts){
            LimitMode::Limits=>true,LimitMode::NoLimits=>false,LimitMode::DisplayLimits=>style==MathStyle::Display,
            LimitMode::Auto=>match asset.limits(){SymbolLimits::Auto=>style==MathStyle::Display,SymbolLimits::Limits=>true,SymbolLimits::Nolimits=>false},
        };
        self.operator_limits(f,parts,style,cramped,depth,stacked)
    }
}
