import {
  forwardRef,
  useEffect,
  useImperativeHandle,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from "react";
import { EngineEditorHost } from "../../../../engine/web/host/editor-host.ts";
import { EngineEditorSessionOwner } from "../../../../engine/web/host/editor-session.ts";
import type { OcrInsertionTicket } from "../../../../engine/web/host/editor-session.ts";
import type { EditorSnapshot } from "../../../../engine/web/host/editing.ts";
import type { LayoutOptions } from "../../../../engine/web/host/layout.ts";
import {
  buildCoreProductCommandDescriptors,
  coreCommandUsage,
  coreEditCommandForProductCommand,
  coreInlineShortcuts,
} from "../engine/coreCommandAdapter";
import {
  getCoreEngineRuntime,
  resolveCoreLayoutForPreferences,
  tryCreateLockedCoreFormulaSession,
} from "../engine/coreEngineRuntime";
import {
  createFormulaLine,
  useEditorStore,
} from "../stores/editorStore";
import { getRuntimeCommandRegistry } from "../autocomplete/runtimeCommandRegistry";
import { readCustomSymbolLibrary } from "../math/customSymbolRegistry";
import type { FormulaAlignment, FormulaLine, LatexCodeFormat } from "../types/formula";
import type {
  CoreMathSelectionSnapshot,
  FormulaEditSource,
  MathSelectionSnapshot,
} from "../history/historyTypes";
import type {
  MathEditorFocusOptions,
  MathEditorHandle,
  MathEditorHistoryState,
  MathEditorInsertionTarget,
  MathEditorSelectionStyle,
  MathEditorSelectionTarget,
} from "./MathEditor";
import "./coreMathEditor.css";

interface Props {
  lines: FormulaLine[];
  activeLineId: string | null;
  formulaAlignment: FormulaAlignment;
  latexCodeFormat: LatexCodeFormat;
  zoom: number;
  readOnly?: boolean;
  previewOnly?: boolean;
  onPreviewActivate?: () => void;
  draftError?: string;
  onPasteImage?: (file: File, target: MathEditorInsertionTarget) => void;
  onCopyPng?: () => Promise<void>;
  onHistoryBusyChange?: (busy: boolean) => void;
  overlay?: ReactNode;
  onInitialReject: (reason: string) => void;
  onCoreHistoryStateChange?: (state: MathEditorHistoryState | null) => void;
}

type HostRecord = {
  owner: EngineEditorSessionOwner;
  host: EngineEditorHost;
  mount: HTMLDivElement;
};

export interface CoreEditorProbeResult {
  eligible: boolean;
  reason?: string;
}

export async function probeCoreEditorSession(
  lines: readonly FormulaLine[],
): Promise<CoreEditorProbeResult> {
  if (lines.length !== 1) {
    return {
      eligible: false,
      reason: "The first core-editor integration slice requires one formula line.",
    };
  }
  const line = lines[0];
  const settings = useEditorStore.getState();
  const symbols = structuredClone(readCustomSymbolLibrary().symbols);
  try {
    const context = await getCoreEngineRuntime();
    const layout = await resolveCoreLayoutForPreferences(
      context,
      settings.formulaLetterFont,
      settings.formulaChineseFont,
      line.mode === "inline" ? "text" : "display",
    );
    if (!layout) {
      return {
        eligible: false,
        reason: "The selected formula font preferences cannot be resolved to verified core font resources.",
      };
    }
    const prepared = await tryCreateLockedCoreFormulaSession(
      `desktop-core-preflight:${line.id}`,
      line.latex,
      line.mode === "inline" ? "text" : "display",
      symbols,
      layout,
    );
    if (!prepared) {
      return {
        eligible: false,
        reason: "The formula needs syntax or verified font resources not enabled in this P10 slice.",
      };
    }
    prepared.owner.destroy();
    return { eligible: true };
  } catch (error) {
    return {
      eligible: false,
      reason: error instanceof Error ? error.message : String(error),
    };
  }
}

function hexColor(value: string) {
  const match = /^#([0-9a-f]{6})$/iu.exec(value.trim());
  if (!match) return null;
  const number = Number.parseInt(match[1], 16);
  return {
    r: (number >>> 16) & 0xff,
    g: (number >>> 8) & 0xff,
    b: number & 0xff,
  };
}

export const CoreMathEditor = forwardRef<MathEditorHandle, Props>(
  function CoreMathEditor(
    {
      lines,
      activeLineId,
      formulaAlignment,
      zoom,
      readOnly = false,
      previewOnly = false,
      onPreviewActivate,
      onPasteImage,
      overlay,
      onInitialReject,
      onCoreHistoryStateChange,
    },
    ref,
  ) {
    const inputBehavior = useEditorStore((state) => state.inputBehavior);
    const personalize = useEditorStore((state) => state.personalize);
    const suggestionCount = useEditorStore((state) => state.suggestionCount);
    const usage = useEditorStore((state) => state.usage);
    const language = useEditorStore((state) => state.language);
    const autoPairDelimiters = useEditorStore((state) => state.autoPairDelimiters);
    const formulaLetterFont = useEditorStore((state) => state.formulaLetterFont);
    const formulaChineseFont = useEditorStore((state) => state.formulaChineseFont);
    const recordCommand = useEditorStore((state) => state.recordCommand);
    const [frozenSymbols] = useState(() => structuredClone(readCustomSymbolLibrary().symbols));
    const [frozenRegistry] = useState(() => structuredClone(getRuntimeCommandRegistry()));
    const commandDescriptors = useMemo(
      () => buildCoreProductCommandDescriptors(inputBehavior, language, frozenRegistry),
      [inputBehavior, language, frozenRegistry],
    );
    const commandUsage = useMemo(
      () => coreCommandUsage(usage, personalize),
      [usage, personalize],
    );
    const inlineShortcuts = useMemo(
      () => coreInlineShortcuts(inputBehavior.autoEscapeShortcuts),
      [inputBehavior.autoEscapeShortcuts],
    );
    const [accepted, setAccepted] = useState(false);
    const [probeError, setProbeError] = useState<string | null>(null);
    const [layoutNotice, setLayoutNotice] = useState<string | null>(null);
    const hostRecords = useRef(new Map<string, HostRecord>());
    const mountRefs = useRef(new Map<string, HTMLDivElement>());
    const initialLinesRef = useRef(lines.map((line) => ({ ...line })));
    const initialFontPreferencesRef = useRef({
      formulaLetterFont,
      formulaChineseFont,
    });
    const initialLayoutRef = useRef<LayoutOptions | null>(null);
    const rejectedRef = useRef(false);
    const onInitialRejectRef = useRef(onInitialReject);
    onInitialRejectRef.current = onInitialReject;

    const activeRecord = () => {
      const id = useEditorStore.getState().activeLineId ?? activeLineId;
      if (id) {
        const record = hostRecords.current.get(id);
        if (record) return record;
      }
      return hostRecords.current.values().next().value as HostRecord | undefined;
    };

    useEffect(() => {
      let cancelled = false;
      const probe = async () => {
        // First P10 production slice is deliberately document-level and single
        // formula. Multi-line documents remain locked to the legacy editor from
        // mount; there is no mid-edit fallback.
        if (initialLinesRef.current.length !== 1) {
          throw new Error("The first core-editor integration slice requires one formula line.");
        }
        const line = initialLinesRef.current[0];
        const context = await getCoreEngineRuntime();
        const layout = await resolveCoreLayoutForPreferences(
          context,
          initialFontPreferencesRef.current.formulaLetterFont,
          initialFontPreferencesRef.current.formulaChineseFont,
          line.mode === "inline" ? "text" : "display",
        );
        if (!layout) {
          throw new Error("The selected formula font preferences cannot be resolved to verified core font resources.");
        }
        initialLayoutRef.current = structuredClone(layout);
        const prepared = await tryCreateLockedCoreFormulaSession(
          `desktop-core-probe:${line.id}`,
          line.latex,
          line.mode === "inline" ? "text" : "display",
          frozenSymbols,
          layout,
        );
        if (!prepared) {
          throw new Error("The formula needs syntax or verified font resources not enabled in this P10 slice.");
        }
        prepared.owner.destroy();
        if (!cancelled) setAccepted(true);
      };
      probe().catch((error) => {
        if (cancelled || rejectedRef.current) return;
        rejectedRef.current = true;
        const reason = error instanceof Error ? error.message : String(error);
        setProbeError(reason);
        onInitialRejectRef.current(reason);
      });
      return () => {
        cancelled = true;
      };
    }, []);

    useEffect(() => {
      if (!accepted) return;
      let cancelled = false;
      const createHosts = async () => {
        const context = await getCoreEngineRuntime();
        if (cancelled) return;
        for (const line of lines) {
          if (hostRecords.current.has(line.id)) continue;
          const mount = mountRefs.current.get(line.id);
          if (!mount) continue;
          const layout = initialLayoutRef.current
            ? { ...structuredClone(initialLayoutRef.current), style: line.mode === "inline" ? ("text" as const) : ("display" as const) }
            : await resolveCoreLayoutForPreferences(
                context,
                initialFontPreferencesRef.current.formulaLetterFont,
                initialFontPreferencesRef.current.formulaChineseFont,
                line.mode === "inline" ? "text" : "display",
              );
          if (!layout) throw new Error("The initial verified core layout is unavailable.");
          const owner = new EngineEditorSessionOwner(
            context.runtime,
            `desktop-core:${line.id}`,
            line.latex,
            frozenSymbols,
          );
          const host = new EngineEditorHost(
            context.runtime,
            mount,
            {
              documentId: owner.documentId,
              layout,
              commands: commandDescriptors,
              commandUsage,
              commandLimit: suggestionCount,
              inlineShortcuts,
              inputBehavior: {
                autoPairDelimiters,
                autoExitSuperscript: inputBehavior.autoExitSuperscript,
                autoExitSubscript: inputBehavior.autoExitSubscript,
                autoExitAccent: inputBehavior.autoExitAccent,
                autoExitWrapperCommand: inputBehavior.autoExitWrapperCommand,
              },
              onCommandAccepted: (id, query) => recordCommand(id, query, "candidate"),
              onChange: (snapshot) => {
                onCoreHistoryStateChange?.({
                  engine: "core",
                  canUndo: snapshot.undoDepth > 0,
                  canRedo: snapshot.redoDepth > 0,
                });
                const state = useEditorStore.getState();
                const current = state.lines.find((item) => item.id === line.id);
                if (current && current.latex !== snapshot.document.source) {
                  state.replaceFormulaLineExact(line.id, snapshot.document.source);
                }
              },
              onError: (error) => {
                console.error("VisualTeX core editor:", error);
              },
            },
            owner,
          );
          host.setZoom(zoom);
          const focus = () => useEditorStore.getState().setActiveLineId(line.id);
          mount.addEventListener("focusin", focus);
          const record: HostRecord = { owner, host, mount };
          hostRecords.current.set(line.id, record);
        }
      };
      createHosts().catch((error) => {
        if (cancelled || rejectedRef.current) return;
        rejectedRef.current = true;
        onInitialRejectRef.current(error instanceof Error ? error.message : String(error));
      });
      return () => {
        cancelled = true;
      };
    }, [accepted, lines, zoom]);

    useEffect(() => {
      if (!accepted) return;
      let cancelled = false;
      const updateFonts = async () => {
        const context = await getCoreEngineRuntime();
        let unresolved = false;
        for (const [lineId, record] of hostRecords.current) {
          const line = lines.find((item) => item.id === lineId);
          if (!line) continue;
          const layout = await resolveCoreLayoutForPreferences(
            context,
            formulaLetterFont,
            formulaChineseFont,
            line.mode === "inline" ? "text" : "display",
          );
          if (cancelled) return;
          if (!layout) {
            unresolved = true;
            continue;
          }
          try {
            record.host.setLayoutOptions(layout);
          } catch (error) {
            unresolved = true;
            console.warn("VisualTeX core kept the previous verified font layout:", error);
          }
        }
        if (!cancelled) {
          setLayoutNotice(
            unresolved
              ? "当前字体偏好无法解析为已验证字体资源；本公式会话继续使用上一个已验证布局。"
              : null,
          );
        }
      };
      void updateFonts();
      return () => {
        cancelled = true;
      };
    }, [accepted, formulaChineseFont, formulaLetterFont, lines]);

    useEffect(() => {
      if (!accepted) return;
      for (const record of hostRecords.current.values()) {
        record.host.setInlineShortcuts(inlineShortcuts);
        record.host.setInputBehavior({
          autoPairDelimiters,
          autoExitSuperscript: inputBehavior.autoExitSuperscript,
          autoExitSubscript: inputBehavior.autoExitSubscript,
          autoExitAccent: inputBehavior.autoExitAccent,
          autoExitWrapperCommand: inputBehavior.autoExitWrapperCommand,
        });
        record.host.setCommandConfiguration(commandDescriptors, commandUsage, suggestionCount);
      }
    }, [
      accepted,
      autoPairDelimiters,
      commandDescriptors,
      commandUsage,
      inputBehavior.autoExitAccent,
      inputBehavior.autoExitSubscript,
      inputBehavior.autoExitSuperscript,
      inputBehavior.autoExitWrapperCommand,
      inlineShortcuts,
      suggestionCount,
    ]);

    useEffect(() => {
      if (!accepted) return;
      for (const [lineId, record] of hostRecords.current) {
        const line = lines.find((item) => item.id === lineId);
        if (!line) {
          record.host.dispose();
          record.owner.destroy();
          hostRecords.current.delete(lineId);
          continue;
        }
        record.host.setZoom(zoom);
      }
    }, [accepted, lines, zoom]);

    useEffect(
      () => () => {
        onCoreHistoryStateChange?.(null);
        for (const record of hostRecords.current.values()) {
          record.host.dispose();
          if (!record.owner.isDestroyed) record.owner.destroy();
        }
        hostRecords.current.clear();
      },
      [],
    );

    useImperativeHandle(ref, () => ({
      insertCommand: (command) => {
        activeRecord()?.host.applyEditCommand(coreEditCommandForProductCommand(command));
      },
      insertLatex: (latex) => {
        activeRecord()?.host.applyEditCommand({ kind: "pasteLatex", latex });
      },
      insertLatexAt: (target, latex) => {
        if (target.engine !== "core" || !target.coreRequest) return false;
        const record = hostRecords.current.get(target.lineId);
        if (!record) return false;
        const result = record.host.applyOcrResult(
          target.coreRequest as OcrInsertionTicket,
          latex,
        );
        return result.status === "applied";
      },
      appendLatex: (latex) => {
        const record = activeRecord();
        if (!record) return;
        record.host.applyEditCommand({ kind: "pasteLatex", latex });
      },
      focus: (options?: MathEditorFocusOptions) => {
        const line =
          options?.target === "first"
            ? lines[0]
            : options?.target === "last"
              ? lines.at(-1)
              : lines.find((item) => item.id === activeLineId) ?? lines[0];
        if (line) hostRecords.current.get(line.id)?.host.focus();
      },
      addLine: () => {
        // Multi-line ownership will be expanded before the core editor becomes
        // a default path. Do not silently create a legacy-owned second line.
      },
      commitPendingTransaction: () => {
        // BrowserInputBridge owns composition; there is no second pending
        // MathLive/history transaction to flush in the core path.
      },
      getSelectionMap: () => ({}),
      getCoreSelectionMap: () =>
        Object.fromEntries(
          [...hostRecords.current.entries()].map(([lineId, record]) => [
            lineId,
            record.host.captureSelectionToken() as CoreMathSelectionSnapshot,
          ]),
        ),
      restoreSelection: async (lineId, latex, _selection: MathSelectionSnapshot | null) => {
        const record = hostRecords.current.get(lineId);
        if (!record) return false;
        if (record.host.inspect().document.source !== latex) record.host.replaceSource(latex);
        record.host.focus();
        return true;
      },
      restoreCoreSelection: async (
        lineId,
        latex,
        selection: CoreMathSelectionSnapshot | null,
      ) => {
        const record = hostRecords.current.get(lineId);
        if (!record) return false;
        if (record.host.inspect().document.source !== latex) return false;
        if (!selection) {
          record.host.focus();
          return true;
        }
        return record.host.restoreSelectionToken(selection);
      },
      captureSelectionTarget: (): MathEditorSelectionTarget | null => {
        const lineId = useEditorStore.getState().activeLineId ?? activeLineId;
        return lineId && hostRecords.current.has(lineId)
          ? { engine: "core", coreLineId: lineId, selections: [] }
          : null;
      },
      captureInsertionTarget: (): MathEditorInsertionTarget | null => {
        const lineId = useEditorStore.getState().activeLineId ?? activeLineId;
        if (!lineId) return null;
        const record = hostRecords.current.get(lineId);
        if (!record) return null;
        return {
          engine: "core",
          lineId,
          ranges: [],
          direction: "none",
          coreRequest: record.host.beginOcrInsertion() as object,
        };
      },
      applySelectionStyle: (
        style: MathEditorSelectionStyle,
        target?: MathEditorSelectionTarget | null,
      ) => {
        const lineId = target?.engine === "core" ? target.coreLineId : activeLineId;
        const host = lineId ? hostRecords.current.get(lineId)?.host : activeRecord()?.host;
        if (!host) return false;
        if (style.kind === "bold") host.applyStyle("\\mathbf");
        else if (style.kind === "italic") host.applyStyle("\\mathit");
        else if (style.kind === "color") {
          const color = hexColor(style.value);
          if (!color) return false;
          host.applyColor(color);
        } else {
          // Background-color wrappers are not yet a core P10 capability.
          return false;
        }
        return true;
      },
      refreshLayout: () => {
        for (const record of hostRecords.current.values()) record.host.setZoom(zoom);
      },
      replaceLineSource: (lineId, latex) => {
        const record = hostRecords.current.get(lineId);
        if (!record) return false;
        if (record.host.inspect().document.source !== latex) record.host.replaceSource(latex);
        return true;
      },
      history: (redo) => {
        const record = activeRecord();
        if (!record) return false;
        record.host.history(redo);
        return true;
      },
    }));

    const interceptImagePaste = (event: React.ClipboardEvent<HTMLDivElement>) => {
      if (!onPasteImage) return;
      const file = Array.from(event.clipboardData.files).find((item) =>
        item.type.startsWith("image/"),
      );
      if (!file) return;
      const lineId = useEditorStore.getState().activeLineId ?? activeLineId;
      const record = lineId ? hostRecords.current.get(lineId) : undefined;
      if (!lineId || !record) return;
      const target: MathEditorInsertionTarget = {
        engine: "core",
        lineId,
        ranges: [],
        direction: "none",
        coreRequest: record.host.beginOcrInsertion() as object,
      };
      event.preventDefault();
      onPasteImage(file, target);
    };

    if (!accepted) {
      return (
        <section className="core-math-editor is-probing" aria-live="polite">
          {probeError ?? "Initializing VisualTeX core editor…"}
        </section>
      );
    }

    return (
      <section
        className={`core-math-editor${previewOnly || readOnly ? " is-preview-only" : ""}`}
        data-engine="visualtex-core"
        data-formula-alignment={formulaAlignment}
        onPasteCapture={interceptImagePaste}
      >
        {layoutNotice ? (
          <div className="core-math-editor-notice" role="status">
            {layoutNotice}
          </div>
        ) : null}
        {lines.map((line) => (
          <div
            key={line.id}
            className={`core-formula-line is-${line.mode === "inline" ? "inline" : "display"}`}
            data-line-id={line.id}
            ref={(node) => {
              if (node) mountRefs.current.set(line.id, node);
              else mountRefs.current.delete(line.id);
            }}
          />
        ))}
        {(previewOnly || readOnly) && (
          <button
            type="button"
            className="core-math-editor-preview-shield"
            aria-label="Activate formula editor"
            onClick={() => onPreviewActivate?.()}
          />
        )}
        {overlay}
      </section>
    );
  },
);
