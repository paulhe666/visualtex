import { useEffect, useRef, useState } from "react";
import { EditorState } from "@codemirror/state";
import {
  foldGutter,
  foldKeymap,
  HighlightStyle,
  syntaxHighlighting,
} from "@codemirror/language";
import {
  EditorView,
  highlightActiveLine,
  highlightActiveLineGutter,
  highlightSpecialChars,
  keymap,
  lineNumbers,
} from "@codemirror/view";
import { tags } from "@lezer/highlight";
import {
  defaultKeymap,
  history,
  historyKeymap,
  indentWithTab,
} from "@codemirror/commands";
import { latex as latexLanguageSupport } from "codemirror-lang-latex";
import {
  AlertTriangle,
  Code2,
  Copy,
  PanelBottomClose,
  RotateCcw,
} from "lucide-react";
import { useEditorStore } from "../stores/editorStore";
import type { LatexSourceDraftResult } from "../clipboard/LatexCopyService";
import type { LatexCodeFormat, Theme } from "../types/formula";
import { visualTeXLatexEditingExtensions } from "./latexSourceEditorSupport";

const visualTeXLatexHighlightStyle = HighlightStyle.define([
  {
    tag: [
      tags.keyword,
      tags.definitionKeyword,
      tags.macroName,
      tags.labelName,
      tags.heading,
    ],
    color: "var(--syntax-command)",
  },
  {
    tag: [tags.className, tags.typeName, tags.namespace],
    color: "var(--syntax-function)",
    fontWeight: "650",
  },
  {
    tag: [tags.strong, tags.emphasis, tags.monospace],
    color: "var(--syntax-command)",
    fontWeight: "600",
  },
  {
    tag: [tags.operator, tags.processingInstruction],
    color: "var(--syntax-operator)",
  },
  { tag: tags.number, color: "var(--syntax-number)" },
  { tag: tags.bracket, color: "var(--syntax-bracket)" },
  { tag: [tags.string, tags.quote, tags.meta], color: "var(--syntax-string)" },
  { tag: tags.comment, color: "var(--syntax-comment)", fontStyle: "italic" },
  { tag: [tags.variableName, tags.content], color: "var(--syntax-variable)" },
  { tag: tags.invalid, color: "var(--syntax-error)", textDecoration: "underline" },
]);

interface Props {
  latex: string;
  theme: Theme;
  format: LatexCodeFormat;
  onCollapse: () => void;
  showCollapseAction?: boolean;
  showCopyAction?: boolean;
  compact?: boolean;
  onLiveChange: (
    latex: string,
    sourceFormat: LatexCodeFormat,
  ) => LatexSourceDraftResult;
  onFocusChange?: (focused: boolean) => void;
  onCopy: () => void;
  externalHistoryOwner?: boolean;
  onExternalHistory?: (redo: boolean) => void;
}

export function LatexSourceEditor({
  latex,
  theme,
  format,
  onCollapse,
  showCollapseAction = true,
  showCopyAction = true,
  compact = false,
  onLiveChange,
  onFocusChange,
  onCopy,
  externalHistoryOwner = false,
  onExternalHistory,
}: Props) {
  const hostRef = useRef<HTMLDivElement>(null);
  const viewRef = useRef<EditorView | null>(null);
  const draftRef = useRef(latex);
  const sourceRef = useRef(latex);
  const latestLatexRef = useRef(latex);
  const dirtyRef = useRef(false);
  const sourceFocusedRef = useRef(false);
  const syncErrorRef = useRef<string | null>(null);
  const suppressChangeRef = useRef(false);
  const formatRef = useRef(format);
  const onLiveChangeRef = useRef(onLiveChange);
  const onFocusChangeRef = useRef(onFocusChange);
  const onExternalHistoryRef = useRef(onExternalHistory);
  const formatRefreshFrameRef = useRef<number | null>(null);
  const focusReleaseFrameRef = useRef<number | null>(null);
  const [dirty, setDirty] = useState(false);
  const [syncError, setSyncError] = useState<string | null>(null);
  const [hasLivePreview, setHasLivePreview] = useState(true);
  const hasLivePreviewRef = useRef(true);
  const language = useEditorStore((state) => state.language);
  const isEn = language === "en";
  onLiveChangeRef.current = onLiveChange;
  onFocusChangeRef.current = onFocusChange;
  onExternalHistoryRef.current = onExternalHistory;

  const updateDirty = (value: boolean) => {
    dirtyRef.current = value;
    setDirty(value);
  };

  const updateSyncError = (value: string | null) => {
    syncErrorRef.current = value;
    setSyncError(value);
  };

  useEffect(() => {
    sourceRef.current = latex;
    latestLatexRef.current = latex;
  }, [latex]);

  useEffect(() => {
    if (!hostRef.current) return;

    const editorTheme = EditorView.theme({
      "&": {
        backgroundColor: "transparent",
        color: "var(--text)",
      },
      ".cm-content": {
        caretColor: "var(--accent)",
        fontFamily: "'SFMono-Regular', Menlo, Consolas, monospace",
        fontSize: "12px",
        lineHeight: "1.62",
        padding: "10px 0 18px",
      },
      ".cm-line": {
        paddingInline: "4px 10px",
      },
      ".cm-gutters": {
        backgroundColor: "transparent",
        color: "var(--text-faint)",
        border: "none",
      },
      ".cm-lineNumbers .cm-gutterElement": {
        minWidth: "32px",
        paddingInline: "6px 7px",
      },
      ".cm-foldGutter .cm-gutterElement": {
        width: "18px",
        paddingInline: "1px",
        color: "var(--text-faint)",
        cursor: "pointer",
      },
      ".cm-activeLineGutter": {
        backgroundColor: "color-mix(in srgb, var(--accent-soft) 45%, transparent)",
        color: "var(--text-muted)",
      },
      ".cm-activeLine": {
        backgroundColor: "color-mix(in srgb, var(--accent-soft) 32%, transparent)",
      },
      ".cm-focused": { outline: "none" },
      ".cm-selectionBackground, ::selection": {
        backgroundColor:
          "color-mix(in srgb, var(--accent) 22%, transparent) !important",
      },
      ".cm-matchingBracket": {
        backgroundColor: "color-mix(in srgb, var(--syntax-bracket) 18%, transparent)",
        outline: "1px solid color-mix(in srgb, var(--syntax-bracket) 55%, transparent)",
        borderRadius: "2px",
      },
      ".cm-vt-indent-guide": {
        backgroundImage:
          "linear-gradient(to right, transparent calc(2ch - 1px), color-mix(in srgb, var(--border-strong) 58%, transparent) calc(2ch - 1px), color-mix(in srgb, var(--border-strong) 58%, transparent) 2ch)",
        backgroundSize: "2ch 100%",
      },
      ".cm-vt-command-default, .cm-vt-command-structure, .cm-vt-command-calculus, .cm-vt-command-matrix, .cm-vt-command-greek, .cm-vt-command-relation, .cm-vt-command-set, .cm-vt-command-arrow, .cm-vt-command-physics": {
        fontWeight: "600",
      },
      ".cm-vt-command-default, .cm-vt-command-structure": {
        color: "var(--syntax-command)",
      },
      ".cm-vt-command-calculus": { color: "var(--syntax-number)" },
      ".cm-vt-command-matrix": { color: "var(--syntax-function)" },
      ".cm-vt-command-greek": { color: "var(--syntax-string)" },
      ".cm-vt-command-relation": { color: "var(--syntax-error)" },
      ".cm-vt-command-set": { color: "var(--syntax-bracket)" },
      ".cm-vt-command-arrow": {
        color:
          "color-mix(in srgb, var(--syntax-command) 45%, var(--syntax-function))",
      },
      ".cm-vt-command-physics": {
        color:
          "color-mix(in srgb, var(--syntax-bracket) 55%, var(--syntax-string))",
      },
      ".cm-tooltip-autocomplete": {
        border: "1px solid var(--border-strong)",
        borderRadius: "7px",
        backgroundColor: "var(--bg-elevated)",
        boxShadow: "var(--shadow-md)",
        overflow: "hidden",
      },
      ".cm-tooltip-autocomplete > ul > li[aria-selected]": {
        backgroundColor: "var(--accent-soft)",
        color: "var(--text)",
      },
    });

    const editorHistoryExtensions = externalHistoryOwner
      ? [
          keymap.of([
            {
              key: "Mod-z",
              run: () => {
                onExternalHistoryRef.current?.(false);
                return true;
              },
            },
            {
              key: "Mod-Shift-z",
              run: () => {
                onExternalHistoryRef.current?.(true);
                return true;
              },
            },
            {
              key: "Mod-y",
              run: () => {
                onExternalHistoryRef.current?.(true);
                return true;
              },
            },
            indentWithTab,
            ...foldKeymap,
            ...defaultKeymap,
          ]),
        ]
      : [
          history(),
          keymap.of([
            indentWithTab,
            ...foldKeymap,
            ...defaultKeymap,
            ...historyKeymap,
          ]),
        ];

    const state = EditorState.create({
      doc: sourceRef.current,
      extensions: [
        lineNumbers(),
        foldGutter({ openText: "⌄", closedText: "›" }),
        highlightActiveLineGutter(),
        highlightActiveLine(),
        highlightSpecialChars(),
        ...editorHistoryExtensions,
        latexLanguageSupport({ enableLinting: false, enableTooltips: false }),
        visualTeXLatexEditingExtensions,
        syntaxHighlighting(visualTeXLatexHighlightStyle),
        EditorView.contentAttributes.of({
          spellcheck: "false",
          autocapitalize: "off",
          autocomplete: "off",
          "data-gramm": "false",
        }),
        editorTheme,
        EditorView.lineWrapping,
        EditorView.updateListener.of((update) => {
          if (update.focusChanged) {
            sourceFocusedRef.current = update.view.hasFocus;
            if (focusReleaseFrameRef.current !== null) {
              window.cancelAnimationFrame(focusReleaseFrameRef.current);
              focusReleaseFrameRef.current = null;
            }
            if (update.view.hasFocus) {
              onFocusChangeRef.current?.(true);
            } else {
              focusReleaseFrameRef.current = window.requestAnimationFrame(() => {
                focusReleaseFrameRef.current = null;
                const view = viewRef.current;
                if (!view || view.hasFocus) return;
                sourceFocusedRef.current = false;
                onFocusChangeRef.current?.(false);
                if (syncErrorRef.current || !hasLivePreviewRef.current) return;
                updateDirty(false);
                const canonical = latestLatexRef.current;
                const current = view.state.doc.toString();
                if (current !== canonical) {
                  suppressChangeRef.current = true;
                  view.dispatch({
                    changes: { from: 0, to: current.length, insert: canonical },
                  });
                }
                draftRef.current = canonical;
                updateDirty(false);
              });
            }
          }
          if (!update.docChanged) return;
          draftRef.current = update.state.doc.toString();
          if (suppressChangeRef.current) {
            suppressChangeRef.current = false;
            updateDirty(false);
            updateSyncError(null);
            return;
          }
          const result = onLiveChangeRef.current(
            draftRef.current,
            formatRef.current,
          );
          const acceptedLivePreview =
            result.valid ||
            result.values.length > 0 ||
            Boolean(result.previewValues?.length);
          hasLivePreviewRef.current = acceptedLivePreview;
          setHasLivePreview(acceptedLivePreview);
          updateSyncError(result.valid ? null : result.error ?? "invalid-latex");
          if (acceptedLivePreview) {
            sourceRef.current = draftRef.current;
            updateDirty(false);
          } else {
            updateDirty(draftRef.current !== sourceRef.current);
          }
        }),
      ],
    });

    const view = new EditorView({ state, parent: hostRef.current });
    viewRef.current = view;
    draftRef.current = sourceRef.current;
    updateDirty(false);

    return () => {
      if (formatRefreshFrameRef.current !== null) {
        window.cancelAnimationFrame(formatRefreshFrameRef.current);
        formatRefreshFrameRef.current = null;
      }
      if (focusReleaseFrameRef.current !== null) {
        window.cancelAnimationFrame(focusReleaseFrameRef.current);
        focusReleaseFrameRef.current = null;
      }
      if (sourceFocusedRef.current) {
        sourceFocusedRef.current = false;
        onFocusChangeRef.current?.(false);
      }
      view.destroy();
      viewRef.current = null;
    };
  }, [theme, externalHistoryOwner]);

  useEffect(() => {
    const view = viewRef.current;
    if (
      !view ||
      (!externalHistoryOwner && sourceFocusedRef.current) ||
      syncErrorRef.current
    )
      return;
    const current = view.state.doc.toString();
    if (current === latex) {
      updateDirty(false);
      return;
    }

    suppressChangeRef.current = true;
    view.dispatch({
      changes: { from: 0, to: current.length, insert: latex },
    });
    draftRef.current = latex;
    updateDirty(false);
  }, [latex]);

  useEffect(() => {
    const previousFormat = formatRef.current;
    if (previousFormat === format) return;
    formatRef.current = format;
    updateSyncError(null);

    if (formatRefreshFrameRef.current !== null) {
      window.cancelAnimationFrame(formatRefreshFrameRef.current);
    }
    formatRefreshFrameRef.current = window.requestAnimationFrame(() => {
      formatRefreshFrameRef.current = window.requestAnimationFrame(() => {
        const view = viewRef.current;
        if (!view) return;
        const nextSource = latestLatexRef.current;
        const current = view.state.doc.toString();
        if (current !== nextSource) {
          suppressChangeRef.current = true;
          view.dispatch({
            changes: { from: 0, to: current.length, insert: nextSource },
          });
        }
        draftRef.current = nextSource;
        updateDirty(false);
        formatRefreshFrameRef.current = null;
      });
    });
  }, [format]);

  const replaceDraft = (value: string) => {
    const view = viewRef.current;
    if (!view) return;
    const current = view.state.doc.toString();
    suppressChangeRef.current = true;
    view.dispatch({ changes: { from: 0, to: current.length, insert: value } });
    draftRef.current = value;
    const result = onLiveChangeRef.current(value, formatRef.current);
    const acceptedLivePreview =
      result.valid ||
      result.values.length > 0 ||
      Boolean(result.previewValues?.length);
    hasLivePreviewRef.current = acceptedLivePreview;
    setHasLivePreview(acceptedLivePreview);
    updateSyncError(result.valid ? null : result.error ?? "invalid-latex");
    if (acceptedLivePreview) sourceRef.current = value;
    updateDirty(false);
  };

  const showHeader = !compact || dirty || Boolean(syncError);

  return (
    <section
      className={
        "source-panel" +
        (compact ? " is-compact" : "") +
        (compact && (dirty || syncError) ? " has-dirty-actions" : "") +
        (syncError ? " has-source-error" : "")
      }
    >
      {showHeader && (
        <div className="source-panel-header">
          {!compact && (
            <div className="source-title">
              <Code2 size={16} />
              <span>{isEn ? "LaTeX source" : "LaTeX 源码"}</span>
              {syncError ? (
                <span className="source-error-chip">
                  <AlertTriangle size={12} />
                  {syncError === "incomplete-format-wrapper"
                    ? isEn
                      ? "Formula wrapper is incomplete"
                      : "公式环境包裹尚未完成"
                    : isEn
                      ? "Incomplete fragment is shown as LaTeX"
                      : "未完成片段按源码显示，其余保持渲染"}
                </span>
              ) : dirty ? (
                <span className="source-live-chip">
                  {isEn ? "Live synced" : "已实时同步"}
                </span>
              ) : null}
            </div>
          )}
          {compact && syncError && (
            <span className="source-error-chip source-error-chip-compact">
              <AlertTriangle size={12} />
              {syncError === "incomplete-format-wrapper"
                ? isEn
                  ? "Incomplete wrapper"
                  : "环境包裹未完成"
                : isEn
                  ? "Partial LaTeX preview"
                  : "局部源码预览"}
            </span>
          )}
          <div className="source-actions">
            {(dirty || (syncError && !hasLivePreview)) && (
              <button
                type="button"
                className="text-button"
                data-source-reset
                onClick={() => replaceDraft(latex)}
              >
                <RotateCcw size={14} /> {isEn ? "Reset" : "还原"}
              </button>
            )}
            {showCopyAction && (
              <button
                type="button"
                className="text-button source-copy-button"
                onClick={onCopy}
                aria-label={isEn ? "Copy LaTeX source" : "复制 LaTeX 源码"}
                title={isEn ? "Copy LaTeX source" : "复制 LaTeX 源码"}
              >
                <Copy size={14} />
              </button>
            )}
            {showCollapseAction && (
              <button
                type="button"
                className="text-button source-collapse-button"
                onClick={onCollapse}
                aria-label={isEn ? "Hide LaTeX source" : "收起 LaTeX 源码"}
                title={isEn ? "Hide LaTeX source" : "收起 LaTeX 源码"}
              >
                <PanelBottomClose size={14} />
              </button>
            )}
          </div>
        </div>
      )}
      <div ref={hostRef} className="codemirror-host" />
    </section>
  );
}
