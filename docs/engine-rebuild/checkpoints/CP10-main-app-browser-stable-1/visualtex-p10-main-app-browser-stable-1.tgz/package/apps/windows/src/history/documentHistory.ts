import type { FormulaLine } from "../types/formula";
import { createUuid } from "../runtime/browserCompatibility";
import {
  cloneFormulaLines,
  createFormulaLine,
  normalizeFormulaLines,
  useEditorStore,
} from "../stores/editorStore";
import type {
  CoreMathSelectionSnapshot,
  DocumentSnapshot,
  HistoryEntry,
  MathSelectionSnapshot,
  ReplayDirection,
} from "./historyTypes";

export interface FocusRestoreTarget {
  lineId: string;
  latex: string;
  selection: MathSelectionSnapshot | null;
  coreSelection?: CoreMathSelectionSnapshot | null;
}

export function cloneSelectionMap(
  selectionByLineId: Record<string, MathSelectionSnapshot>,
): Record<string, MathSelectionSnapshot> {
  return Object.fromEntries(
    Object.entries(selectionByLineId).map(([lineId, selection]) => [
      lineId,
      {
        ranges: selection.ranges.map(([start, end]) => [start, end]),
        direction: selection.direction,
      },
    ]),
  );
}

export function cloneCoreSelectionMap(
  selectionByLineId: Record<string, CoreMathSelectionSnapshot>,
): Record<string, CoreMathSelectionSnapshot> {
  return structuredClone(selectionByLineId);
}

export function getEditorDocumentSnapshot(
  selectionByLineId: Record<string, MathSelectionSnapshot> = {},
  coreSelectionByLineId: Record<string, CoreMathSelectionSnapshot> = {},
): DocumentSnapshot {
  const state = useEditorStore.getState();
  return {
    title: state.title,
    lines: cloneFormulaLines(state.lines),
    activeLineId: state.activeLineId,
    formulaAlignment: state.formulaAlignment,
    selectionByLineId: cloneSelectionMap(selectionByLineId),
    coreSelectionByLineId: cloneCoreSelectionMap(coreSelectionByLineId),
  };
}

export function documentSnapshotsEquivalent(
  left: DocumentSnapshot,
  right: DocumentSnapshot,
): boolean {
  return (
    left.title === right.title &&
    left.activeLineId === right.activeLineId &&
    (left.formulaAlignment ?? "left") ===
      (right.formulaAlignment ?? "left") &&
    left.lines.length === right.lines.length &&
    left.lines.every((line, index) => {
      const rightLine = right.lines[index];
      return (
        line.id === rightLine?.id &&
        line.latex === rightLine?.latex &&
        (line.mode === "inline" ? "inline" : "display") ===
          (rightLine?.mode === "inline" ? "inline" : "display")
      );
    })
  );
}

export function reconcileFormulaLines(
  values: readonly string[],
  currentLines: readonly FormulaLine[],
  modes?: readonly FormulaLine["mode"][],
): FormulaLine[] {
  const normalizedValues = values.length ? values : [""];
  return normalizedValues.map((latex, index) => ({
    id: currentLines[index]?.id ?? createUuid(),
    latex,
    mode:
      modes?.[index] === "inline"
        ? "inline"
        : modes?.[index] === "display"
          ? "display"
          : currentLines[index]?.mode ?? "display",
  }));
}

export function createBlankDocumentSnapshot(title: string): DocumentSnapshot {
  const line = createFormulaLine("");
  return {
    title,
    lines: [line],
    activeLineId: line.id,
    formulaAlignment: "left",
    selectionByLineId: {
      [line.id]: { ranges: [[0, 0]], direction: "none" },
    },
    coreSelectionByLineId: {},
  };
}

function targetFromSnapshot(snapshot: DocumentSnapshot): FocusRestoreTarget | null {
  const lineId = snapshot.activeLineId;
  if (!lineId) return null;
  const line = snapshot.lines.find((item) => item.id === lineId);
  if (!line) return null;
  return {
    lineId,
    latex: line.latex,
    selection: snapshot.selectionByLineId[lineId] ?? null,
    coreSelection: snapshot.coreSelectionByLineId?.[lineId] ?? null,
  };
}

export function applyHistoryEntryToEditor(
  entry: HistoryEntry,
  direction: ReplayDirection,
): FocusRestoreTarget | null {
  const undoing = direction === "undo";
  const store = useEditorStore.getState();

  switch (entry.type) {
    case "replace-formula": {
      const latex = undoing ? entry.beforeLatex : entry.afterLatex;
      const activeLineId = undoing
        ? entry.beforeActiveLineId
        : entry.afterActiveLineId;
      const selection = undoing
        ? entry.beforeSelection
        : entry.afterSelection;
      store.replaceFormulaLine(entry.lineId, latex);
      store.setActiveLineId(activeLineId ?? entry.lineId);
      return {
        lineId: activeLineId ?? entry.lineId,
        latex:
          useEditorStore
            .getState()
            .lines.find((line) => line.id === (activeLineId ?? entry.lineId))
            ?.latex ?? latex,
        selection,
      };
    }

    case "add-line": {
      if (undoing) {
        store.removeFormulaLine(entry.line.id);
        store.setActiveLineId(entry.beforeActiveLineId);
        const targetLineId =
          entry.beforeActiveLineId ?? useEditorStore.getState().lines[0]?.id;
        if (!targetLineId) return null;
        const line = useEditorStore
          .getState()
          .lines.find((item) => item.id === targetLineId);
        return line
          ? {
              lineId: targetLineId,
              latex: line.latex,
              selection: entry.beforeSelection,
            }
          : null;
      }

      store.insertFormulaLine(entry.line, entry.index);
      store.setActiveLineId(entry.afterActiveLineId ?? entry.line.id);
      return {
        lineId: entry.afterActiveLineId ?? entry.line.id,
        latex: entry.line.latex,
        selection: entry.afterSelection,
      };
    }

    case "remove-line": {
      if (undoing) {
        store.insertFormulaLine(entry.line, entry.index);
        store.setActiveLineId(entry.beforeActiveLineId ?? entry.line.id);
        return {
          lineId: entry.beforeActiveLineId ?? entry.line.id,
          latex:
            useEditorStore
              .getState()
              .lines.find(
                (line) => line.id === (entry.beforeActiveLineId ?? entry.line.id),
              )?.latex ?? entry.line.latex,
          selection: entry.beforeSelection,
        };
      }

      store.removeFormulaLine(entry.line.id);
      store.setActiveLineId(entry.afterActiveLineId);
      const targetLineId =
        entry.afterActiveLineId ?? useEditorStore.getState().lines[0]?.id;
      if (!targetLineId) return null;
      const line = useEditorStore
        .getState()
        .lines.find((item) => item.id === targetLineId);
      return line
        ? {
            lineId: targetLineId,
            latex: line.latex,
            selection: entry.afterSelection,
          }
        : null;
    }

    case "replace-document": {
      const snapshot = undoing ? entry.before : entry.after;
      store.replaceDocumentState(snapshot);
      return targetFromSnapshot(snapshot);
    }

    case "change-title":
      store.setTitle(undoing ? entry.beforeTitle : entry.afterTitle);
      return null;
  }
}
