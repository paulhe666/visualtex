import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import { fileURLToPath } from "node:url";
import { resolve } from "node:path";
import {
  mathLiveBrowserEntry,
  visualTexMathLiveContourIntegralCompatibility,
} from "./vite.mathliveIntegralCompatibility";

const host = process.env.TAURI_DEV_HOST;
const configRoot = fileURLToPath(new URL(".", import.meta.url));
const coreEditorEntry = resolve(
  configRoot,
  process.env.VITE_VISUALTEX_CORE_EDITOR === "1"
    ? "src/editor/CoreMathEditor.tsx"
    : "src/editor/CoreMathEditor.disabled.tsx",
);
const coreStaticPreviewEntry = resolve(
  configRoot,
  process.env.VITE_VISUALTEX_CORE_EDITOR === "1"
    ? "src/engine/coreStaticPreview.ts"
    : "src/engine/coreStaticPreview.disabled.ts",
);

export default defineConfig({
  plugins: [visualTexMathLiveContourIntegralCompatibility(), react()],
  resolve: {
    alias: [
      {
        find: /^\.\.\/editor\/CoreMathEditor$/,
        replacement: coreEditorEntry,
      },
      {
        find: /^\.\.\/engine\/coreStaticPreview$/,
        replacement: coreStaticPreviewEntry,
      },
      {
        find: /^mathlive$/,
        replacement: mathLiveBrowserEntry,
      },
    ],
  },
  optimizeDeps: {
    exclude: ["mathlive"],
  },
  clearScreen: false,
  server: {
    port: 1420,
    strictPort: true,
    host: host || false,
    hmr: host
      ? { protocol: "ws", host, port: 1421 }
      : undefined,
  },
  envPrefix: ["VITE_", "TAURI_ENV_*"],
  build: {
    target: process.env.TAURI_ENV_PLATFORM === "windows" ? "chrome105" : "safari13",
    minify: process.env.TAURI_ENV_DEBUG ? false : "esbuild",
    sourcemap: !!process.env.TAURI_ENV_DEBUG,
  },
});
