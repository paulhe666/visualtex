import { EngineEditorSessionOwner } from "../../../../engine/web/host/editor-session.ts";
import {
  getCoreEngineRuntime,
  resolveCoreLayoutForPreferences,
} from "./coreEngineRuntime";
import type {
  FormulaChineseFont,
  FormulaLetterFont,
} from "../editor/formulaFontPreferences";

export interface CoreStaticPreviewRequest {
  latex: string;
  style?: "display" | "text";
  formulaLetterFont: FormulaLetterFont;
  formulaChineseFont: FormulaChineseFont;
  customSymbolRevision: number;
  symbols: readonly unknown[];
}

const cache = new Map<string, Promise<string | null>>();
const CACHE_LIMIT = 512;
let nextPreviewOwner = 1;

function cacheKey(request: CoreStaticPreviewRequest) {
  return [
    request.formulaLetterFont,
    request.formulaChineseFont,
    request.style ?? "text",
    request.customSymbolRevision,
    request.latex,
  ].join("\u0000");
}

function remember(key: string, value: Promise<string | null>) {
  if (cache.size >= CACHE_LIMIT) {
    const oldest = cache.keys().next().value;
    if (typeof oldest === "string") cache.delete(oldest);
  }
  cache.set(key, value);
  return value;
}

/**
 * Pure static preview path: no BrowserInputBridge, command state or editor host
 * is created. A short-lived core document owner exists only for one cache miss,
 * exports validated SVG, and is destroyed immediately afterwards.
 */
export function renderCoreStaticPreview(
  request: CoreStaticPreviewRequest,
): Promise<string | null> {
  const latex = request.latex.trim();
  if (!latex || latex.length > 16_384 || latex.includes("\\placeholder")) {
    return Promise.resolve(null);
  }
  const key = cacheKey({ ...request, latex });
  const existing = cache.get(key);
  if (existing) return existing;
  return remember(
    key,
    (async () => {
      const context = await getCoreEngineRuntime();
      const layout = await resolveCoreLayoutForPreferences(
        context,
        request.formulaLetterFont,
        request.formulaChineseFont,
        request.style ?? "text",
      );
      if (!layout) return null;
      const activeBefore = context.runtime.activeSessions;
      const owner = new EngineEditorSessionOwner(
        context.runtime,
        `static-preview:${nextPreviewOwner++}`,
        latex,
        request.symbols,
      );
      try {
        const result = owner.layout(layout, true);
        return result.svg;
      } catch {
        return null;
      } finally {
        owner.destroy();
        if (context.runtime.activeSessions !== activeBefore) {
          throw new Error("Static preview leaked a core editor session.");
        }
      }
    })().catch(() => null),
  );
}

export function clearCoreStaticPreviewCache() {
  cache.clear();
}
