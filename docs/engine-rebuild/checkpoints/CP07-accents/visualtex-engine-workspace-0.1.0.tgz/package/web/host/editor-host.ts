import {SvgSceneView} from './svg-view.js';
import {BrowserInputBridge} from './input-bridge.js';
import type {ViewPointer} from './svg-view';
import type {EditorAction,EditorActionResult,EditorSnapshot,Position,Selection} from './editing';
import type {LayoutOptions,LayoutSnapshot,SceneQuery,SceneQueryResult} from './layout';
import type {EngineCommand,EngineReply,EngineResponse} from './protocol';

export interface EngineRuntimePort {dispatch(request:string):string}
export interface EditorHostOptions {
  documentId:string;
  initialSource?:string;
  layout:LayoutOptions;
  onChange?:(snapshot:EditorSnapshot)=>void;
  onError?:(error:Error)=>void;
  onEnter?:()=>void;
}
const caret=(p:Position):Selection=>({kind:'range',anchor:p,focus:p});
const roles:Record<string,string>={root:'公式',fraction:'分式',numerator:'分子',denominator:'分母',radical:'根式',degree:'根指数',radicand:'被开方项',fence:'定界符',fenceBody:'括号内部',
  accent:'重音或装饰',accentBody:'重音正文',annotation:'上下标注',annotationLabel:'标注内容',annotationBase:'标注正文',
  scripts:'上下标',base:'底数',subscript:'下标',superscript:'上标',text:'文本',symbol:'符号',group:'分组'};

/** A per-document owner bridge, not a second editable state store. All mutations
 * and history are core transactions. The cached snapshot is a read projection. */
export class EngineEditorHost {
  readonly view:SvgSceneView;
  readonly input:BrowserInputBridge;
  readonly status:HTMLDivElement;
  private state:EditorSnapshot;
  private scene:LayoutSnapshot|null=null;
  private sceneToken=0;
  private sequence=0;
  private typingGroup=1;
  private readonly handle:number;
  private dragAnchor:Position|null=null;
  private desiredX:number|null=null;
  private disposed=false;
  private readonly abort=new AbortController();
  private errors:string[]=[];
  constructor(private readonly runtime:EngineRuntimePort,parent:HTMLElement,private readonly options:EditorHostOptions){
    const created=this.send({op:'create',documentId:options.documentId,source:options.initialSource??''},'session');
    this.handle=created.handle;
    this.state=this.send({op:'inspectEditor',handle:this.handle},'editor').snapshot;
    this.view=new SvgSceneView(parent,{onPointer:event=>this.pointer(event)});
    this.status=document.createElement('div');this.status.className='vt-core-position';
    this.status.setAttribute('role','status');this.status.setAttribute('aria-live','polite');parent.append(this.status);
    this.input=new BrowserInputBridge(parent,{
      key:event=>this.key(event),
      insert:text=>{
        const mode=this.inputMode();
        if(mode==='math'&&(text==='^'||text==='_')) return this.commitAndRender({kind:'edit',command:{kind:'insertStructure',structure:text==='^'?'superscript':'subscript'}});
        if(mode==='math'&&['(',')','[',']','{','}'].includes(text)) {
          this.typingGroup++;
          return this.commitAndRender({kind:'edit',command:{kind:'typeDelimiter',text}});
        }
        return this.commitAndRender({kind:'edit',command:{kind:'insertText',text,mode},groupId:`typing-${this.typingGroup}-${mode}`});
      },
      remove:backward=>{this.typingGroup++;return this.commitAndRender({kind:'edit',command:{kind:backward?'deleteBackward':'deleteForward'}});},
      history:redo=>{this.typingGroup++;return this.commitAndRender({kind:redo?'redo':'undo'});},
      beginComposition:()=>{this.typingGroup++;const result=this.dispatch({kind:'beginComposition',mode:this.inputMode()});this.paintResult(result);return result.editor.composition?.id??null;},
      updateComposition:(id,preedit)=>this.commitAndRender({kind:'updateComposition',id,preedit}),
      commitComposition:(id,text)=>{this.typingGroup++;return this.commitAndRender({kind:'commitComposition',id,text});},
      cancelComposition:id=>{this.typingGroup++;return this.commitAndRender({kind:'cancelComposition',id});},
      copy:()=>this.send({op:'copySelection',handle:this.handle,expectedRevision:this.state.document.revision},'clipboard').fragment,
      cut:fragment=>{
        if(fragment.revision!==this.state.document.revision||fragment.selectionEpoch!==this.state.selectionEpoch)throw new Error('Clipboard target is stale');
        this.typingGroup++;return this.commitAndRender({kind:'edit',command:{kind:'deleteBackward'}});
      },
      paste:(text,latex)=>{this.typingGroup++;return this.inputMode()==='text'?this.commitAndRender({kind:'edit',command:{kind:'insertText',text,mode:'text'}}):this.commitAndRender({kind:'edit',command:{kind:'pasteLatex',latex:latex??text}});},
      focus:focused=>{if(!focused)this.typingGroup++;},error:error=>this.reportError(error),
    });
    const position=()=>{try{this.positionInput();}catch(error){this.reportError(error);}};
    window.addEventListener('resize',position,{signal:this.abort.signal});
    window.addEventListener('scroll',position,{signal:this.abort.signal,capture:true});
    // Unsupported or unfinished source remains a live, recoverable session.
    // Failure to draw must not destroy the user's source or its history.
    try{this.refresh(true);}catch(error){this.reportError(error);}
  }
  private send<K extends EngineReply['kind']>(command:EngineCommand,kind:K):Extract<EngineReply,{kind:K}>{
    const response=JSON.parse(this.runtime.dispatch(JSON.stringify({protocol:1,command}))) as EngineResponse;
    if(response.status==='error')throw new Error(`${response.error.code}: ${response.error.message}`);
    if(response.status!=='ok'||response.result.kind!==kind)throw new Error('Unexpected engine response');
    return response.result as Extract<EngineReply,{kind:K}>;
  }
  private reportError(reason:unknown){
    const error=reason instanceof Error?reason:new Error(String(reason));this.errors.push(error.message);
    if(this.errors.length>128)this.errors.shift();
    this.status.textContent=error.message;this.options.onError?.(error);
  }
  inspect():EditorSnapshot{return structuredClone(this.state);}
  get layoutSnapshot():LayoutSnapshot|null{return this.scene?structuredClone(this.scene):null;}
  get diagnostics(){return this.errors.slice();}
  private query(query:SceneQuery):SceneQueryResult{
    if(!this.scene||this.scene.revision!==this.state.document.revision)throw new Error('Current layout is unavailable');
    return this.send({op:'queryScene',handle:this.handle,expectedRevision:this.state.document.revision,sceneToken:this.sceneToken,query},'sceneQuery').result;
  }
  private rawAction(action:EditorAction):EditorActionResult{
    if(this.disposed)throw new Error('Editor host disposed');
    const result=this.send({op:'editorAction',handle:this.handle,expectedRevision:this.state.document.revision,eventSequence:++this.sequence,action},'editorAction').result;
    this.state=result.editor;return result;
  }
  private dispatch(action:EditorAction):EditorActionResult{
    const result=this.rawAction(action);
    if(result.verticalMove){
      const selection=result.verticalMove.selection;
      const queried=this.query({kind:'selection',selection});
      if(queried.kind!=='selection'||!queried.caret)return result;
      const target=this.query({kind:'vertical',from:queried.caret,down:result.verticalMove.direction==='down',desiredX:this.desiredX});
      if(target.kind!=='vertical')throw new Error('Invalid vertical navigation response');
      this.desiredX=target.desiredX;return this.rawAction({kind:'setSelection',selection:caret(target.position)});
    }
    if(action.kind!=='updateComposition')this.desiredX=null;
    return result;
  }
  private inputMode():'math'|'text'{return this.state.selection.kind==='range'&&this.state.selection.focus.kind==='text'?'text':'math';}
  private paintResult(result:EditorActionResult):void{
    // A rendering exception cannot uncommit an already accepted core action.
    try{this.refresh(result.contentChanged);}catch(error){this.reportError(error);}
  }
  private commitAndRender(action:EditorAction):boolean{const result=this.dispatch(action);this.paintResult(result);return true;}
  private key(event:KeyboardEvent):boolean{
    if((event.ctrlKey||event.metaKey)&&!event.altKey){
      const key=event.key.toLowerCase();
      if(key==='z'||key==='y'){this.typingGroup++;return this.commitAndRender({kind:key==='y'||event.shiftKey?'redo':'undo'});}
      if(key==='a'){
        const root=this.state.document.analysis.tree;if(root.kind!=='row')return false;this.typingGroup++;
        return this.commitAndRender({kind:'setSelection',selection:{kind:'range',anchor:{kind:'row',nodeId:root.id,offset:0,affinity:'after'},focus:{kind:'row',nodeId:root.id,offset:root.entries.length,affinity:'after'}}});
      }
      return false;
    }
    if(event.ctrlKey||event.metaKey||event.altKey)return false;
    if(event.key==='ArrowLeft'||event.key==='ArrowRight'){this.typingGroup++;return this.commitAndRender({kind:'moveHorizontal',direction:event.key==='ArrowLeft'?'left':'right',extend:event.shiftKey});}
    if(event.key==='ArrowUp'||event.key==='ArrowDown'){this.typingGroup++;return this.commitAndRender({kind:'moveVertical',direction:event.key==='ArrowUp'?'up':'down'});}
    if(event.key==='Backspace'||event.key==='Delete'){this.typingGroup++;return this.commitAndRender({kind:'edit',command:{kind:event.key==='Backspace'?'deleteBackward':'deleteForward'}});}
    if(event.key==='Enter'){this.typingGroup++;this.options.onEnter?.();return true;}
    return false;
  }
  private refresh(contentChanged:boolean){
    // Publish accepted core state even when its new source cannot be laid out.
    // The source pane and undo stack must never remain on a previous revision.
    this.options.onChange?.(this.inspect());
    try{
      if(contentChanged||!this.scene||this.scene.revision!==this.state.document.revision){
        const layout=this.send({op:'layout',handle:this.handle,expectedRevision:this.state.document.revision,
          options:this.options.layout,includeSvg:false},'layout');
        this.view.setSnapshot(layout.snapshot);this.sceneToken=layout.sceneToken;this.scene=layout.snapshot;
      }
      const overlay=this.query({kind:'selection',selection:this.state.selection});
      if(overlay.kind!=='selection')throw new Error('Invalid selection geometry response');
      this.view.container.hidden=false;this.view.container.removeAttribute('aria-disabled');
      this.input.setEnabled(true);
      this.view.setOverlay({...this.view.snapshotIdentity!,caret:overlay.caret,rectangles:overlay.rectangles});
      const d=overlay.description;
      const label=`${d.path.map(p=>roles[p]??p).join('，')}，位置 ${d.offset}/${d.length}${d.text?`，${d.text}`:''}`;
      this.status.textContent=label;this.input.textarea.setAttribute('aria-label',label);
      this.input.setPreedit(this.state.composition?.preedit??'');
      this.positionInput(overlay.caret);
    }catch(error){
      this.scene=null;this.sceneToken=0;this.dragAnchor=null;
      this.view.container.hidden=true;this.view.container.setAttribute('aria-disabled','true');
      this.input.setEnabled(false);
      this.status.textContent='当前源码尚不能排版；源码和撤销历史已保留，可在源码区修复。';
      throw error;
    }
  }
  private positionInput(position?:Position|null){
    if(!this.scene)return;
    if(position===undefined){const q=this.query({kind:'selection',selection:this.state.selection});position=q.kind==='selection'?q.caret:null;}
    const c=position?this.scene.carets.find(c=>{
      const a=c.position,b=position!;return a.kind===b.kind&&a.nodeId===b.nodeId&&(a.kind==='row'&&b.kind==='row'?a.offset===b.offset:a.kind==='text'&&b.kind==='text'&&a.grapheme===b.grapheme);
    }):this.scene.carets[0];
    if(!c)return;
    const top=this.view.layoutToClient(c.x,c.top),bottom=this.view.layoutToClient(c.x,c.bottom);
    this.input.setAnchor(top.x,top.y,Math.max(1,bottom.y-top.y));
  }
  private pointer(event:ViewPointer){
    if(this.disposed||this.input.hasUncommittedInput)return;
    if(!this.scene||event.documentId!==this.scene.documentId||event.revision!==this.scene.revision||event.sourceId!==this.scene.sourceId)return;
    try{
      const query=this.query({kind:'hitTest',xEm:event.xEm,yEm:event.yEm});if(query.kind!=='hitTest')return;
      if(event.phase==='down')this.dragAnchor=event.shiftKey&&this.state.selection.kind==='range'?this.state.selection.anchor:query.position;
      if(!this.dragAnchor)return;
      this.dispatch({kind:'setSelection',selection:{kind:'range',anchor:this.dragAnchor,focus:query.position}});this.refresh(false);
      if(event.phase==='up')this.dragAnchor=null;
      this.input.focus();
    }catch(error){this.reportError(error);}
  }
  applyStructure(structure:'fraction'|'superscript'|'subscript'|'text'|'squareRoot'|'indexedRoot'):void{
    if(this.input.hasUncommittedInput)throw new Error('Confirm, retry or cancel pending input before inserting a structure');
    const result=this.dispatch({kind:'edit',command:{kind:'insertStructure',structure}});this.refresh(result.contentChanged);this.input.focus();
  }
  applyFence(left:string,right:string):void{
    if(this.input.hasUncommittedInput)throw new Error('Confirm, retry or cancel pending input before inserting a fence');
    this.typingGroup++;
    const result=this.dispatch({kind:'edit',command:{kind:'insertFence',left,right}});this.refresh(result.contentChanged);this.input.focus();
  }
  applyAccent(command:string):void{
    if(this.input.hasUncommittedInput)throw new Error('Confirm, retry or cancel pending input before inserting an accent');
    this.typingGroup++;
    const result=this.dispatch({kind:'edit',command:{kind:'insertAccent',command}});this.refresh(result.contentChanged);this.input.focus();
  }
  applyAnnotation(command:string):void{
    if(this.input.hasUncommittedInput)throw new Error('Confirm, retry or cancel pending input before inserting an annotation');
    this.typingGroup++;
    const result=this.dispatch({kind:'edit',command:{kind:'insertAnnotation',command}});this.refresh(result.contentChanged);this.input.focus();
  }
  exitStructure():void{
    if(this.input.hasUncommittedInput)throw new Error('Confirm, retry or cancel pending input before leaving a structure');
    this.typingGroup++;
    const result=this.dispatch({kind:'edit',command:{kind:'exitStructure'}});this.refresh(result.contentChanged);this.input.focus();
  }
  replaceSource(source:string):void{
    if(this.input.hasUncommittedInput)throw new Error('Confirm, retry or cancel pending input before replacing source');
    this.send({op:'replaceSource',handle:this.handle,expectedRevision:this.state.document.revision,source},'document');
    this.state=this.send({op:'inspectEditor',handle:this.handle},'editor').snapshot;this.refresh(true);
  }
  history(redo:boolean):void{
    if(this.input.hasUncommittedInput)throw new Error('Confirm, retry or cancel pending input before changing history');
    this.typingGroup++;const result=this.dispatch({kind:redo?'redo':'undo'});this.refresh(result.contentChanged);
  }
  setZoom(zoom:number):void{this.view.setZoom(zoom);this.positionInput();}
  focus():void{this.input.focus();}
  exportSvg():string{
    if(this.input.hasUncommittedInput)throw new Error('Confirm, retry or cancel pending input before export');
    const result=this.send({op:'layout',handle:this.handle,expectedRevision:this.state.document.revision,options:this.options.layout,includeSvg:true},'layout');
    // Export also replaces the runtime's scene token; do not keep a stale hit map.
    this.sceneToken=result.sceneToken;this.scene=result.snapshot;
    if(result.svg===null)throw new Error('Missing requested vector export');return result.svg;
  }
  dispose():void{
    if(this.disposed)return;
    this.input?.dispose();this.abort.abort();
    try{this.send({op:'destroy',handle:this.handle,expectedRevision:this.state.document.revision},'destroyed');}
    finally{this.disposed=true;this.view?.dispose();this.status?.remove();}
  }
}
