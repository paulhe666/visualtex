//! Symmetric stretchable fences around a mathematical body, centered on MATH axis.
use crate::{delimiters,stretch};
use crate::error::{EngineError,EngineResult,ErrorCode};
use crate::model::Node;
use crate::session::NodeId;
use super::{MathStyle,boxes::{Builder,Fragment}};

impl Builder<'_> {
    pub fn fence(&mut self,id:NodeId,left:&str,body:&Node,right:&str,
        style:MathStyle,cramped:bool,depth:usize)->EngineResult<Fragment> {
        let body=self.node(body,style,cramped,depth+1)?;
        let scale=style.scale(self.math);let axis=self.math.axis*scale;
        let target=2.0*(body.ascent-axis).max(body.descent+axis).max(1e-6);
        let shape=|source:&str|->EngineResult<Option<stretch::StretchedGlyph>> {
            let glyph=delimiters::glyph(source).ok_or_else(||EngineError::new(ErrorCode::UnsupportedSyntax,"Unsupported fence delimiter"))?;
            glyph.map(|ch|stretch::vertical(self.math_font,self.math_font.glyph_id(ch)?,target/scale)).transpose()
        };
        let left=shape(left)?;let right=shape(right)?;
        let left_width=left.as_ref().map_or(0.0,|s|s.width*scale);
        let right_x=left_width+body.advance;
        let mut result=Fragment::new(id,"fence");
        result.italic=body.italic;
        result.child(body,left_width,0.0);
        for (glyph,x) in [(left,0.0),(right,right_x)] {
            if let Some(glyph)=glyph {
                let top=-axis-glyph.height*scale/2.0;
                result.advance=result.advance.max(x+glyph.width*scale);
                result.italic=glyph.italic_correction*scale;
                for piece in glyph.pieces { result.glyph(self.math_font,piece.shape,x,top+piece.y*scale,scale); }
            }
        }
        Ok(result)
    }
}
