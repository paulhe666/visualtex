//! Structure-aware vertical landing. Region preorder is emitted by flatten;
//! source lengths, glyph order and DOM rectangles are never used as anchors.
use std::collections::BTreeSet;
use crate::positions::Position;
use crate::scene::{CaretStop, LayoutSnapshot};
use crate::session::NodeId;

fn node_id(position: Position) -> NodeId {
    match position { Position::Row {node_id,..}|Position::Text {node_id,..}=>node_id }
}
fn subtree_end(scene: &LayoutSnapshot, start: usize) -> usize {
    let depth=scene.regions[start].depth;
    (start+1..scene.regions.len()).find(|i|scene.regions[*i].depth<=depth)
        .unwrap_or(scene.regions.len())
}

/// Prefer the corresponding fraction argument before considering unrelated
/// geometric neighbors. The outer root row crosses the fraction's horizontal
/// axis, but is not an intermediate editable line between its arguments.
pub(crate) fn fraction_target(scene:&LayoutSnapshot, from:Position, down:bool, desired_x:f64)->Option<Position> {
    let index=scene.regions.iter().position(|r|r.node_id==node_id(from))?;
    let mut ancestors=Vec::new();
    for i in 0..=index {
        let depth=scene.regions[i].depth;
        while ancestors.last().is_some_and(|j:&usize|scene.regions[*j].depth>=depth) {ancestors.pop();}
        ancestors.push(i);
    }
    for &parent in ancestors.iter().rev() {
        if scene.regions[parent].role!="fraction" {continue;}
        let end=subtree_end(scene,parent);
        let direct:Vec<_>=(parent+1..end).filter(|i|scene.regions[*i].depth==scene.regions[parent].depth+1).collect();
        if direct.len()!=2 {continue;}
        let (numerator,denominator)=(direct[0],direct[1]);
        let target=if down && index>=numerator && index<denominator {Some(denominator)}
            else if !down && index>=denominator && index<end {Some(numerator)} else {None};
        let Some(target)=target else {continue;};
        let target_end=subtree_end(scene,target);
        let ids:BTreeSet<_>=scene.regions[target..target_end].iter().map(|r|r.node_id).collect();
        let baseline=scene.carets.iter().find(|c|node_id(c.position)==scene.regions[target].node_id)?.baseline;
        let candidate=scene.carets.iter().filter(|c|ids.contains(&node_id(c.position)) && (c.baseline-baseline).abs()<1e-9)
            .min_by(|a,b| {
                let distance=|c:&CaretStop|(c.x-desired_x).abs();
                distance(a).total_cmp(&distance(b)).then(b.depth.cmp(&a.depth))
            });
        if let Some(candidate)=candidate {return Some(candidate.position);}
    }
    None
}
