use std::collections::BTreeMap;
use std::sync::Arc;
use unicode_segmentation::UnicodeSegmentation;
use crate::error::{EngineError, EngineResult, ErrorCode};
use crate::fonts::{FontAsset, GlyphShape, MathMetrics};
use crate::model::{AtomClass, Node, NodeKind, MAX_DEPTH, MAX_NODES};
use crate::positions::Position;
use crate::scene::{CaretStop, NodeRegion, Rect, Rule, SceneBuilder};
use crate::session::NodeId;
use super::{Cached, Key, MathStyle};

struct LocalGlyph {font_id:String,shape:Arc<GlyphShape>,x:f64,y:f64,scale:f64}
struct Child {fragment:Arc<Fragment>,x:f64,y:f64}
pub(super) struct Fragment {
    pub node_id:NodeId, role:&'static str,
    pub advance:f64,pub ascent:f64,pub descent:f64,pub italic:f64,pub ink:Option<Rect>,pub accent:Option<f64>,
    glyphs:Vec<LocalGlyph>,rules:Vec<Rect>,carets:Vec<(Position,f64,f64,f64)>,children:Vec<Child>,
}
impl Fragment {
    pub fn new(node_id:NodeId,role:&'static str)->Self {Self {node_id,role,advance:0.0,ascent:0.0,descent:0.0,italic:0.0,ink:None,accent:None,glyphs:Vec::new(),rules:Vec::new(),carets:Vec::new(),children:Vec::new()}}
    fn add_ink(&mut self,r:Rect) {self.ink=Some(self.ink.map_or(r,|old|old.union(r)));}
    pub fn child(&mut self,fragment:Arc<Fragment>,x:f64,y:f64) {
        self.advance=self.advance.max(x+fragment.advance);self.ascent=self.ascent.max(fragment.ascent-y);self.descent=self.descent.max(fragment.descent+y);
        if let Some(ink)=fragment.ink {self.add_ink(ink.translated(x,y));}
        self.children.push(Child {fragment,x,y});
    }
    pub(super) fn glyph(&mut self,font:&FontAsset,shape:Arc<GlyphShape>,x:f64,y:f64,scale:f64) {
        if let Some([a,b,c,d])=shape.ink {let ink=Rect::new(a*scale+x,b*scale+y,c*scale+x,d*scale+y);self.ascent=self.ascent.max(-ink.y_min);self.descent=self.descent.max(ink.y_max);self.add_ink(ink);}
        self.glyphs.push(LocalGlyph {font_id:font.identity.id.clone(),shape,x,y,scale});
    }
    pub fn rule(&mut self,r:Rect) {self.ascent=self.ascent.max(-r.y_min);self.descent=self.descent.max(r.y_max);self.add_ink(r);self.rules.push(r);}
}
pub(super) struct Builder<'a> {
    pub math_font:&'a FontAsset,pub text_font:&'a FontAsset,pub math:&'a MathMetrics,
    pub hashes:&'a BTreeMap<NodeId,[u8;32]>,pub cache:&'a mut BTreeMap<Key,Cached>,pub built:usize,pub reused:usize,
}
impl Builder<'_> {
    pub fn node(&mut self,node:&Node,style:MathStyle,cramped:bool,depth:usize)->EngineResult<Arc<Fragment>> {
        if depth>MAX_DEPTH {return Err(EngineError::new(ErrorCode::ResourceLimit,"Layout depth budget exceeded"));}
        let key=(node.id,style,cramped);let hash=self.hashes[&node.id];
        if let Some(c)=self.cache.get(&key) {if c.fingerprint==hash {self.reused+=1;return Ok(Arc::clone(&c.fragment));}}
        self.built+=1;
        let scale=style.scale(self.math);
        let mut f=match &node.kind {
            NodeKind::Row {entries,..}=> {
                let mut f=Fragment::new(node.id,"row");
                let mut classes:Vec<_>=entries.iter().map(|e|atom_class(&e.node)).collect();
                for i in 0..classes.len() {if classes[i]==AtomClass::Binary {
                    let left=if i==0 {None} else {Some(classes[i-1])};let right=classes.get(i+1).copied();
                    if left.is_none_or(|c|matches!(c,AtomClass::Binary|AtomClass::Relation|AtomClass::Open|AtomClass::Punctuation|AtomClass::Operator))
                        || right.is_none_or(|c|matches!(c,AtomClass::Relation|AtomClass::Close|AtomClass::Punctuation)) {classes[i]=AtomClass::Ordinary;}
                }}
                let top=-self.math_font.ascent*scale;let bottom=self.math_font.descent*scale;
                f.carets.push((Position::row(node.id,0),0.0,top,bottom));
                for (i,e) in entries.iter().enumerate() {
                    if i>0 {f.advance+=spacing(classes[i-1],classes[i],style)*scale;}
                    let child=self.node(&e.node,style,cramped,depth+1)?;
                    let x=f.advance;let advance=x+child.advance;f.italic=child.italic;
                    if entries.len()==1 {f.accent=child.accent.map(|a|a+x);}
                    f.child(child,x,0.0);f.advance=advance;
                    f.carets.push((Position::row(node.id,i+1),f.advance,top,bottom));
                }
                if entries.is_empty() {f.advance=0.5*scale;f.ascent=(-top).max(0.0);f.descent=bottom.max(0.0);}
                f
            }
            NodeKind::Symbol {value,class,..}=> {
                let mut f=Fragment::new(node.id,"symbol");
                let single_glyph=value.chars().count()==1;
                for ch in value.chars() {
                    let gid=self.math_font.glyph_id(math_character(ch,*class))?;
                    let shape=self.math_font.glyph(gid)?;
                    let advance=shape.advance*scale;f.italic=shape.italic_correction*scale;
                    if single_glyph {f.accent=Some(self.math_font.accent_attachment(gid)?*scale);}
                    f.glyph(self.math_font,shape,f.advance,0.0,scale);f.advance+=advance;
                }
                f
            }
            NodeKind::Text {text,..}=> {
                let mut f=Fragment::new(node.id,"text");let run=self.text_font.shape_text(text)?;
                f.advance=run.advance*scale;f.ascent=self.text_font.ascent*scale;f.descent=self.text_font.descent*scale;
                let mut boundaries:Vec<_>=text.grapheme_indices(true).map(|(b,_)|b).collect();boundaries.push(text.len());
                for (i,byte) in boundaries.into_iter().enumerate() {
                    let x=if byte==text.len() {run.advance} else {run.glyphs.iter().find(|g|g.cluster as usize>=byte).map_or(run.advance,|g|g.pen_x)};
                    f.carets.push((Position::text(node.id,i),x*scale,-f.ascent,f.descent));
                }
                for g in run.glyphs {f.glyph(self.text_font,g.shape,g.x*scale,g.y*scale,scale);}f
            }
            NodeKind::Fraction {command,numerator,denominator,..}=>self.fraction(node.id,command,numerator,denominator,style,cramped,depth)?,
            NodeKind::Scripts {base,slots}=>self.scripts(node.id,base,slots,style,cramped,depth)?,
            NodeKind::Radical {degree,radicand,..}=>self.radical(node.id,degree.as_deref(),radicand,style,depth)?,
            NodeKind::Fence {left,body,right,..}=>self.fence(node.id,left,body,right,style,cramped,depth)?,
            NodeKind::Accent {command,body,..}=>self.accent(node.id,command,body,style,cramped,depth)?,
            NodeKind::Annotation {command,above,annotation,base,..}=>self.annotation(node.id,command,*above,annotation,base,style,cramped,depth)?,
            NodeKind::EmptySlot {..}=> {let mut f=Fragment::new(node.id,"emptySlot");f.advance=0.5*scale;f.ascent=self.math_font.ascent*scale;f.descent=self.math_font.descent*scale;f}
            NodeKind::UnparsedSource {..}=>return Err(EngineError::new(ErrorCode::UnsupportedSyntax,"Opaque source cannot be typeset by K0")),
        };
        f.ascent=f.ascent.max(0.0);f.descent=f.descent.max(0.0);
        if ![f.advance,f.ascent,f.descent,f.italic].into_iter().all(f64::is_finite) || f.advance<0.0 || f.advance>1_000_000.0 {
            return Err(EngineError::new(ErrorCode::ResourceLimit,"Layout geometry exceeds its finite extent budget"));
        }
        let f=Arc::new(f);if self.cache.len()>=MAX_NODES*4 {self.cache.clear();}
        self.cache.insert(key,Cached {fingerprint:hash,fragment:Arc::clone(&f)});Ok(f)
    }
}
fn atom_class(node:&Node)->AtomClass {match &node.kind {NodeKind::Symbol {class,..}=>*class,NodeKind::Fraction {..}|NodeKind::Fence {..}=>AtomClass::Inner,NodeKind::Scripts {base,..}|NodeKind::Accent {body:base,..}=>atom_class(base),NodeKind::Annotation {command,base,..}=>match command.as_str(){"\\stackrel"=>AtomClass::Relation,"\\stackbin"=>AtomClass::Binary,_=>atom_class(base)}, NodeKind::Row {entries,..} if entries.len()==1=>atom_class(&entries[0].node),_=>AtomClass::Ordinary}}
fn math_character(c:char,class:AtomClass)->char {
    if class!=AtomClass::Ordinary {return c;}
    let cp=match c {'A'..='Z'=>0x1D434+u32::from(c)-u32::from('A'),'h'=>0x210E,'a'..='z'=>0x1D44E+u32::from(c)-u32::from('a'),_=>return c};
    char::from_u32(cp).unwrap_or(c)
}
fn spacing(a:AtomClass,b:AtomClass,style:MathStyle)->f64 {
    use AtomClass::*;
    let idx=|a|match a {Ordinary|Number=>0,Operator=>1,Binary=>2,Relation=>3,Open=>4,Close=>5,Punctuation=>6,Inner=>7};
    const MU:[[u8;8];8]=[[0,3,4,5,0,0,0,3],[3,3,0,5,0,0,0,3],[4,4,0,0,4,0,0,4],[5,5,0,0,5,0,0,5],[0,0,0,0,0,0,0,0],[0,3,4,5,0,0,0,3],[3,3,0,3,3,3,3,3],[3,3,4,5,3,0,3,3]];
    if matches!(style,MathStyle::Script|MathStyle::ScriptScript) && !matches!((a,b),(Ordinary|Number|Close|Inner,Operator)|(Operator,Ordinary|Number|Operator)) {return 0.0;}
    f64::from(MU[idx(a)][idx(b)])/18.0
}
pub(super) fn flatten(f:&Fragment,x:f64,y:f64,depth:usize,scene:&mut SceneBuilder)->EngineResult<()> {
    if depth>MAX_DEPTH || scene.snapshot.glyphs.len()+f.glyphs.len()>16_384 || scene.snapshot.carets.len()+f.carets.len()>32_768 {
        return Err(EngineError::new(ErrorCode::ResourceLimit,"Scene budget exceeded"));
    }
    scene.snapshot.regions.push(NodeRegion {node_id:f.node_id,role:f.role.into(),logical:Rect::new(x,y-f.ascent,x+f.advance,y+f.descent),ink:f.ink.map(|r|r.translated(x,y)),depth});
    for g in &f.glyphs {scene.glyph(f.node_id,&g.font_id,Arc::clone(&g.shape),g.x+x,g.y+y,g.scale);}
    for r in &f.rules {scene.snapshot.rules.push(Rule {node_id:f.node_id,rect:r.translated(x,y)});}
    for (position,cx,top,bottom) in &f.carets {scene.snapshot.carets.push(CaretStop {position:*position,x:x+cx,baseline:y,top:y+top,bottom:y+bottom,depth});}
    for child in &f.children {flatten(&child.fragment,x+child.x,y+child.y,depth+1,scene)?;}Ok(())
}
