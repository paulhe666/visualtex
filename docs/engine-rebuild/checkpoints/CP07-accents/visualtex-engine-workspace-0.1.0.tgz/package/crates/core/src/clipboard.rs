//! Clipboard fragments carry source, not live node/session identities.
//! Pasting is a normal structural transaction and allocates independent IDs.
use serde::Serialize;
use unicode_segmentation::UnicodeSegmentation;
use crate::error::{EngineError,EngineResult,ErrorCode};
use crate::model::{Grouping,LatexMode,Node,NodeKind,latex};
use crate::positions::{NormalizedRange,Selection,TreeIndex};
use crate::session::{EngineSession,Revision};

#[derive(Debug,Clone,Serialize)]
#[serde(rename_all="camelCase")]
pub struct ClipboardFragment {
    pub schema_version:u32,
    pub latex:Option<String>,
    pub revision:Revision,
    pub selection_epoch:u32,
}
impl EngineSession {
    pub fn copy_selection(&self,expected_revision:Revision)->EngineResult<ClipboardFragment> {
        self.check_revision(expected_revision)?;
        self.ensure_no_composition()?;
        let index=TreeIndex::new(&self.document.tree)?;
        let selection=&self.editor.selection;
        let source=match selection {
            Selection::Node {node_id}=>Some(latex(index.node(*node_id)?,LatexMode::Lossless)),
            Selection::Range {..}=>match index.normalize_range(selection)? {
                NormalizedRange::Row {node_id,start,end,..}=> {
                    if start==end {None} else {
                        let row=index.node(node_id)?;
                        let NodeKind::Row {entries,..}=&row.kind else {return Err(copy_error());};
                        let mut selected=entries.get(start as usize..end as usize).ok_or_else(copy_error)?.to_vec();
                        // Trivia preceding the first selected atom belongs to
                        // its old row, not to the selected mathematical object.
                        if let Some(first)=selected.first_mut() {first.leading.clear();}
                        let fragment=Node {id:row.id,origin:None,kind:NodeKind::Row {grouping:Grouping::Bare,entries:selected,trailing:String::new()}};
                        Some(latex(&fragment,LatexMode::Lossless))
                    }
                }
                NormalizedRange::Text {node_id,start,end}=> {
                    if start==end {None} else {
                        let text_node=index.node(node_id)?;
                        let NodeKind::Text {text,command,..}=&text_node.kind else {return Err(copy_error());};
                        let selected=text.graphemes(true).skip(start as usize).take((end-start) as usize).collect();
                        let fragment=Node {id:node_id,origin:None,kind:NodeKind::Text {command:command.clone(),before_body:String::new(),text:selected}};
                        Some(latex(&fragment,LatexMode::Lossless))
                    }
                }
            },
        };
        Ok(ClipboardFragment {schema_version:1,latex:source,revision:self.revision,selection_epoch:self.editor.selection_epoch})
    }
}
fn copy_error()->EngineError {EngineError::new(ErrorCode::InvalidPosition,"Clipboard selection is not a valid mathematical fragment")}
