use std::collections::BTreeMap;
use serde::{Deserialize, Serialize};
use crate::error::{EngineError, EngineResult, ErrorCode};
use crate::session::{DocumentSnapshot, EngineSession, Revision, SessionSnapshot};

pub const PROTOCOL_VERSION: u32 = 1;
pub const MAX_WIRE_BYTES: usize = 1_048_576;
pub const MAX_SESSIONS: usize = 64;

#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct Request {
    pub protocol: u32,
    pub command: Command,
}

#[derive(Debug, Deserialize)]
#[serde(tag = "op", rename_all = "camelCase", rename_all_fields = "camelCase", deny_unknown_fields)]
pub enum Command {
    Create { document_id: String },
    Inspect { handle: u32, expected_revision: Option<Revision> },
    Destroy { handle: u32, expected_revision: Revision },
    ReplaceSource { handle: u32, expected_revision: Revision, source: String },
    PatchSource { handle: u32, expected_revision: Revision, edit: crate::source_edit::SourceEdit },
    InspectDocument { handle: u32, expected_revision: Option<Revision> },
    /// Stateless syntax diagnostics for source editors and headless validation.
    /// Returned node ids are analysis-local and must not be used as edit anchors.
    AnalyzeSource { source: String },
    Stats,
}

#[derive(Debug, Serialize)]
#[serde(tag = "kind", rename_all = "camelCase", rename_all_fields = "camelCase")]
pub enum Reply {
    Session { handle: u32, snapshot: SessionSnapshot },
    Document { handle: u32, snapshot: DocumentSnapshot },
    SourcePatched { handle: u32, snapshot: DocumentSnapshot, mapping: crate::source_edit::SourceChangeMap },
    Destroyed { handle: u32 },
    SourceAnalysis { analysis: crate::parser::ParseResult, lossless: String, canonical: Option<String> },
    Stats { protocol: u32, active_sessions: usize },
}

#[derive(Debug, Serialize)]
#[serde(tag = "status", rename_all = "camelCase")]
pub enum Response {
    Ok { result: Reply },
    Error { error: EngineError },
}

impl Response {
    pub fn json(self) -> String {
        // All response data is finite integer/string data. Keep the public error
        // bounded even if a future response type introduces a serialization error.
        serde_json::to_string(&self).unwrap_or_else(|_| {
            String::from("{\"status\":\"error\",\"error\":{\"code\":\"invalidInput\",\"message\":\"Response serialization failed\"}}")
        })
    }
}

pub fn error_json(code: ErrorCode, message: &str) -> String {
    Response::Error { error: EngineError::new(code, message) }.json()
}

/// Owns sessions, not pointers into WASM memory. Handles are never recycled.
/// This is shared by the native CLI and the thin wasm-bindgen boundary.
pub struct Runtime {
    sessions: BTreeMap<u32, EngineSession>,
    documents: BTreeMap<String, u32>,
    next_handle: u32,
}

impl Default for Runtime {
    fn default() -> Self {
        Self { sessions: BTreeMap::new(), documents: BTreeMap::new(), next_handle: 1 }
    }
}

impl Runtime {
    pub fn active_sessions(&self) -> usize { self.sessions.len() }

    pub fn dispatch_json(&mut self, input: &str) -> String {
        if input.len() > MAX_WIRE_BYTES {
            return error_json(ErrorCode::ResourceLimit, "Request exceeds the byte budget");
        }
        let request: Request = match serde_json::from_str(input) {
            Ok(request) => request,
            Err(_) => return error_json(ErrorCode::InvalidInput, "Invalid engine request schema"),
        };
        match self.dispatch(request) {
            Ok(result) => Response::Ok { result }.json(),
            Err(error) => Response::Error { error }.json(),
        }
    }

    pub fn dispatch(&mut self, request: Request) -> EngineResult<Reply> {
        if request.protocol != PROTOCOL_VERSION {
            return Err(EngineError::new(ErrorCode::UnsupportedProtocol, "Unsupported engine protocol version"));
        }
        match request.command {
            Command::Create { document_id } => {
                if self.documents.contains_key(&document_id) {
                    return Err(EngineError::new(ErrorCode::Conflict, "Document already has an active session"));
                }
                if self.sessions.len() >= MAX_SESSIONS {
                    return Err(EngineError::new(ErrorCode::ResourceLimit, "Active session budget exhausted"));
                }
                let session = EngineSession::new(document_id.clone())?;
                let next = self.next_handle.checked_add(1)
                    .ok_or_else(|| EngineError::new(ErrorCode::ResourceLimit, "Session identity space exhausted"))?;
                let handle = self.next_handle;
                let snapshot = session.snapshot();
                self.sessions.insert(handle, session);
                self.documents.insert(document_id, handle);
                self.next_handle = next;
                Ok(Reply::Session { handle, snapshot })
            }
            Command::Inspect { handle, expected_revision } => {
                let session = self.get(handle)?;
                if let Some(expected) = expected_revision { session.check_revision(expected)?; }
                Ok(Reply::Session { handle, snapshot: session.snapshot() })
            }
            Command::Destroy { handle, expected_revision } => {
                let session = self.get(handle)?;
                session.check_revision(expected_revision)?;
                let document_id = session.document_id().to_owned();
                self.sessions.remove(&handle);
                self.documents.remove(&document_id);
                Ok(Reply::Destroyed { handle })
            }
            Command::AnalyzeSource { source } => {
                let source = crate::source::SourceText::new(1, source)?;
                let analysis = crate::parser::parse(source, crate::session::NodeId(1),
                    &mut crate::model::IdAllocator::new(2))?;
                let lossless = crate::model::latex(&analysis.tree, crate::model::LatexMode::Lossless);
                // Do not offer repaired/opaque input as a normalized replacement.
                let canonical = (analysis.complete && analysis.supported)
                    .then(|| crate::model::latex(&analysis.tree, crate::model::LatexMode::Canonical));
                Ok(Reply::SourceAnalysis { analysis, lossless, canonical })
            }
            Command::ReplaceSource { handle, expected_revision, source } => {
                let session = self.get_mut(handle)?;
                Ok(Reply::Document { handle, snapshot: session.replace_source(expected_revision, source)? })
            }
            Command::PatchSource { handle, expected_revision, edit } => {
                let (snapshot, mapping) = self.get_mut(handle)?.patch_source(expected_revision, edit)?;
                Ok(Reply::SourcePatched { handle, snapshot, mapping })
            }
            Command::InspectDocument { handle, expected_revision } => {
                let session = self.get(handle)?;
                if let Some(expected) = expected_revision { session.check_revision(expected)?; }
                Ok(Reply::Document { handle, snapshot: session.document_snapshot() })
            }
            Command::Stats => Ok(Reply::Stats { protocol: PROTOCOL_VERSION, active_sessions: self.active_sessions() }),
        }
    }

    fn get(&self, handle: u32) -> EngineResult<&EngineSession> {
        self.sessions.get(&handle)
            .ok_or_else(|| EngineError::new(ErrorCode::InvalidHandle, "Unknown or destroyed session handle"))
    }

    fn get_mut(&mut self, handle: u32) -> EngineResult<&mut EngineSession> {
        self.sessions.get_mut(&handle)
            .ok_or_else(|| EngineError::new(ErrorCode::InvalidHandle, "Unknown or destroyed session handle"))
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use serde_json::{Value, json};
    fn send(rt: &mut Runtime, command: Value) -> Value {
        serde_json::from_str(&rt.dispatch_json(&json!({"protocol":1,"command":command}).to_string())).unwrap()
    }
    #[test]
    fn lifecycle_and_stale_requests_are_atomic() {
        let mut rt = Runtime::default();
        assert_eq!(send(&mut rt, json!({"op":"create","documentId":"d"}))["result"]["handle"], 1);
        assert_eq!(send(&mut rt, json!({"op":"create","documentId":"d"}))["error"]["code"], "conflict");
        assert_eq!(send(&mut rt, json!({"op":"destroy","handle":1,"expectedRevision":9}))["error"]["code"], "staleRevision");
        assert_eq!(rt.active_sessions(), 1);
        assert_eq!(send(&mut rt, json!({"op":"destroy","handle":1,"expectedRevision":0}))["status"], "ok");
        assert_eq!(send(&mut rt, json!({"op":"inspect","handle":1}))["error"]["code"], "invalidHandle");
        assert_eq!(send(&mut rt, json!({"op":"create","documentId":"d"}))["result"]["handle"], 2);
    }
    #[test]
    fn unknown_fields_and_bad_numbers_do_not_mutate_state() {
        let mut rt = Runtime::default();
        for input in ["null", "{}", "[]", "not json",
            r#"{"protocol":1,"command":{"op":"create","documentId":"d","unknown":true}}"#,
            r#"{"protocol":1,"command":{"op":"inspect","handle":-1}}"#,
            r#"{"protocol":1,"command":{"op":"inspect","handle":1.2}}"#,
            r#"{"protocol":1,"command":{"op":"stats"},"unexpected":0}"#] {
            let response: Value = serde_json::from_str(&rt.dispatch_json(input)).unwrap();
            assert_eq!(response["error"]["code"], "invalidInput", "{input}");
            assert_eq!(rt.active_sessions(), 0);
        }
    }
    #[test]
    fn protocol_mismatch_and_request_budget() {
        let mut rt = Runtime::default();
        let response: Value = serde_json::from_str(&rt.dispatch_json(r#"{"protocol":2,"command":{"op":"create","documentId":"d"}}"#)).unwrap();
        assert_eq!(response["error"]["code"], "unsupportedProtocol");
        let response: Value = serde_json::from_str(&rt.dispatch_json(&" ".repeat(MAX_WIRE_BYTES + 1))).unwrap();
        assert_eq!(response["error"]["code"], "resourceLimit");
        assert_eq!(rt.active_sessions(), 0);
    }
    #[test]
    fn session_budget_and_released_capacity() {
        let mut rt = Runtime::default();
        for index in 0..MAX_SESSIONS {
            assert_eq!(send(&mut rt, json!({"op":"create","documentId":format!("d{index}")}))["status"], "ok");
        }
        assert_eq!(send(&mut rt, json!({"op":"create","documentId":"overflow"}))["error"]["code"], "resourceLimit");
        send(&mut rt, json!({"op":"destroy","handle":1,"expectedRevision":0}));
        assert_eq!(send(&mut rt, json!({"op":"create","documentId":"replacement"}))["result"]["handle"], 65);
    }
    #[test]
    fn repeated_lifecycle_does_not_leak_or_reuse_handles() {
        let mut rt = Runtime::default();
        for handle in 1..=1000 {
            assert_eq!(send(&mut rt, json!({"op":"create","documentId":"same-document"}))["result"]["handle"], handle);
            send(&mut rt, json!({"op":"destroy","handle":handle,"expectedRevision":0}));
            assert_eq!(rt.active_sessions(), 0);
        }
    }
}
