//! VisualTeX's independent math engine. This crate owns document state and
//! mathematical rules; hosts supply inputs and resources, never DOM geometry.
//! P02 intentionally supports empty sessions only. Capabilities are added with
//! explicit tests; successful lifecycle tests do not imply formula support.
#![forbid(unsafe_code)]

pub mod error;
pub mod protocol;
pub mod session;
pub mod source;
pub mod model;
pub mod parser;
pub mod symbols;
pub mod source_edit;

pub use error::{EngineError, EngineResult, ErrorCode};
pub use protocol::{Runtime, MAX_WIRE_BYTES, PROTOCOL_VERSION, error_json};
