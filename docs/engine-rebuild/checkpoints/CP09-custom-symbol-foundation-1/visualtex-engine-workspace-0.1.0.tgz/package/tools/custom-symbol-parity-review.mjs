// P09 custom-symbol Native/WASM parity. Immutable legacy assets are injected as
// data and never installed as MathLive macros, CSS, DOM HTML or browser fonts.
import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {createInterface} from 'node:readline';
import {once} from 'node:events';
import {createRequire} from 'node:module';
import {createHash} from 'node:crypto';
import {readFileSync,mkdirSync,writeFileSync} from 'node:fs';
import {dirname,resolve,relative} from 'node:path';
import {fileURLToPath} from 'node:url';
const root=resolve(dirname(fileURLToPath(import.meta.url)),'..');
const out=resolve(root,'target/custom-symbol-parity-review',new Date().toISOString().replaceAll(':','-').replaceAll('.','-'));mkdirSync(out,{recursive:true});
const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
const library=JSON.parse(readFileSync(resolve(root,'fixtures/custom-symbol-foundation.json'),'utf8'));const symbols=library.symbols;
const paths={math:resolve(root,'../apps/windows/src-windows/artifacts/office-fonts/latinmodern-math.otf'),text:'C:/Windows/Fonts/NotoSansSC-VF.ttf'};
const expected={math:'6075562b771f8b82f0c179e363389684f2dd09de30038269e2628e504bd7be0f',text:'763146584cf0710223441356b4395e279021b0806c196614377a7a0174ae074a'};
const nativePath=resolve(root,`target/debug/visualtex-engine-test-cli${process.platform==='win32'?'.exe':''}`),wasmPath=resolve(root,'web/pkg-node/visualtex_engine_wasm_bg.wasm');
const {EngineRuntime}=createRequire(import.meta.url)(resolve(root,'web/pkg-node/visualtex_engine_wasm.js'));const wasm=new EngineRuntime(),fonts={};
for(const [name,path] of Object.entries(paths)){const bytes=readFileSync(path);assert.equal(sha(bytes),expected[name]);const r=JSON.parse(wasm.registerFont(bytes,0));assert.equal(r.status,'ok');fonts[name]=r.result.font;}
const native=spawn(nativePath,['--font',paths.math,'--font',paths.text],{stdio:['pipe','pipe','pipe']});const lines=createInterface({input:native.stdout,crlfDelay:Infinity})[Symbol.asyncIterator]();
let stderr='';native.stderr.on('data',d=>{stderr=(stderr+String(d)).slice(-20000);});const timer=setTimeout(()=>native.kill(),120000);
let requests=0,scenes=0,maxNumericDifference=0;const transcript=createHash('sha256'),checks=[];
function compare(a,b,path='response'){
 if(typeof a==='number'&&typeof b==='number'){const d=Math.abs(a-b);assert.ok(Number.isFinite(a)&&Number.isFinite(b),path);maxNumericDifference=Math.max(maxNumericDifference,d);assert.ok(d<=1e-9,`${path}: ${a} vs ${b}`);return;}
 if(a===null||b===null||typeof a!=='object'||typeof b!=='object'){assert.equal(a,b,path);return;}
 assert.equal(Array.isArray(a),Array.isArray(b),path);assert.deepEqual(Object.keys(a),Object.keys(b),path);for(const key of Object.keys(a))compare(a[key],b[key],`${path}.${key}`);
}
async function send(command,error=null){const input=JSON.stringify({protocol:1,command}),a=JSON.parse(wasm.dispatch(input));if(!native.stdin.write(input+'\n'))await once(native.stdin,'drain');const line=await lines.next();assert.equal(line.done,false,stderr);const b=JSON.parse(line.value);compare(a,b,`${requests}:${command.op}`);requests++;transcript.update(input+'\n'+line.value+'\n');if(error){assert.equal(a.status,'error',JSON.stringify(a));assert.equal(a.error.code,error);return a;}assert.equal(a.status,'ok',JSON.stringify(a));return a.result;}
const defaults={mathFont:fonts.math.id,textFont:fonts.text.id,mathFallbacks:[],style:'display',fontSizePx:16,paddingEm:.125};
async function layout(handle,revision=0,options={},error=null){const r=await send({op:'layout',handle,expectedRevision:revision,options:{...defaults,...options},includeSvg:true},error);if(error)return r;scenes++;const s=r.snapshot;assert.ok(s.exportReady);assert.equal(s.width,s.widthEm*s.fontSizePx);assert.equal(s.height,s.heightEm*s.fontSizePx);assert.equal(s.paintOrder.length,s.glyphs.length+s.rules.length+s.artworks.length);assert.ok(s.artworks.every(a=>/^[0-9a-f]{64}$/u.test(a.assetSha256)&&a.shape.path.length>0));for(const bad of ['<text','<image','<mask','foreignObject','href=','data:','assetSha256','userglyph'])assert.ok(!r.svg.includes(bad),bad);return r;}
const caret=(nodeId,offset=0)=>({kind:'range',anchor:{kind:'row',nodeId,offset,affinity:'after'},focus:{kind:'row',nodeId,offset,affinity:'after'}});
function allIds(v,out=new Set()){if(!v||typeof v!=='object')return out;if(Array.isArray(v)){v.forEach(x=>allIds(x,out));return out;}if(Number.isInteger(v.id)){assert.ok(!out.has(v.id));out.add(v.id);}for(const [k,x] of Object.entries(v))if(!['origin','symbolAssets','asset'].includes(k))allIds(x,out);return out;}
let report;
try{
 for(const definition of symbols){const analyzed=await send({op:'analyzeCustomSymbol',definition});assert.equal(analyzed.asset.command,definition.command);assert.equal(analyzed.asset.definition.command,definition.command);assert.equal(analyzed.asset.diagnostics.length,0);assert.ok(analyzed.asset.geometry.length>0);assert.match(analyzed.asset.sha256,/^[0-9a-f]{64}$/u);}
 checks.push('three legacy definitions freeze identically in Native/WASM with bounded vector geometry');
 const sources=[String.raw`\userglyph+\userrel`,String.raw`\textcolor{red}{\userglyph}+\userop_i^n`,String.raw`\frac{\userglyph}{\userrel}+\begin{aligned}\userop_i^n&=x\\y&=\userglyph\end{aligned}`];
 for(const source of sources){const a=await send({op:'analyzeSourceWithSymbols',source,symbols});assert.equal(a.lossless,source);assert.ok(a.analysis.complete&&a.analysis.supported&&a.analysis.exportable);assert.ok(a.analysis.facts.customSymbols>=2);assert.equal(Object.keys(a.analysis.symbolAssets).length,3);}
 checks.push('source analysis binds immutable asset snapshots without normalizing authored commands');
 const source=String.raw`\textcolor{red}{\userglyph}+\userrel+\userop_i^n`;
 const h=(await send({op:'createWithSymbols',documentId:'custom-symbol-parity',source,symbols})).handle;
 const initial=(await send({op:'inspectEditor',handle:h})).snapshot;assert.equal(initial.document.source,source);assert.equal(initial.document.analysis.facts.customSymbols,3);
 for(const style of ['display','text','script','scriptScript']){const a=await layout(h,0,{style}),cached=await layout(h,0,{style}),double=await layout(h,0,{style,fontSizePx:32});assert.equal(cached.svg,a.svg);assert.equal(cached.snapshot.rebuiltFragments,0);assert.equal(double.snapshot.width,a.snapshot.width*2);assert.equal(double.snapshot.height,a.snapshot.height*2);assert.deepEqual(double.snapshot.artworks,a.snapshot.artworks);}
 checks.push('custom artwork and operator limits have exact Native/WASM layout/SVG parity in four styles and two natural sizes');
 let revision=0,sequence=0,state=initial;const action=async action=>{const r=(await send({op:'editorAction',handle:h,expectedRevision:revision,eventSequence:++sequence,action})).result;state=r.editor;revision=state.document.revision;return r;};const edit=command=>action({kind:'edit',command,groupId:null});
 await action({kind:'setSelection',selection:caret(state.document.analysis.tree.id,state.document.analysis.tree.entries.length)});const beforeInsert=state;
 await edit({kind:'insertCustomSymbol',command:String.raw`\userglyph`});assert.equal(state.document.analysis.facts.customSymbols,4);const inserted=state.document.analysis.tree.entries.at(-1).node;assert.equal(inserted.kind,'customSymbol');assert.equal(inserted.command,String.raw`\userglyph`);const insertedIds=allIds(inserted);
 await action({kind:'setSelection',selection:{kind:'node',nodeId:inserted.id}});const copied=(await send({op:'copySelection',handle:h,expectedRevision:revision})).fragment;assert.equal(copied.latex,String.raw`\userglyph`);assert.ok(copied.structure.assets.some(a=>a.kind==='customSymbol'&&a.definition?.command==='userglyph'));
 await edit({kind:'duplicateSelection'});const duplicate=state.document.analysis.tree.entries.at(-1).node;assert.ok([...allIds(duplicate)].every(id=>!insertedIds.has(id)));const afterDuplicate=structuredClone(state);
 await action({kind:'undo'});await action({kind:'redo'});assert.equal(state.document.source,afterDuplicate.document.source);assert.deepEqual(state.document.analysis.tree,afterDuplicate.document.analysis.tree);
 await layout(h,revision);checks.push('structural insertion, read-only copy, fresh-id duplicate and undo/redo keep frozen symbol ownership');
 const target=(await send({op:'create',documentId:'custom-symbol-rich-target',source:''})).handle;let tr=0,ts=0;const targetAction=async action=>{const r=(await send({op:'editorAction',handle:target,expectedRevision:tr,eventSequence:++ts,action})).result;tr=r.editor.document.revision;return r.editor;};
 const pasted=await targetAction({kind:'edit',command:{kind:'pasteStructured',latex:copied.latex,fragment:copied.structure},groupId:null});assert.equal(pasted.document.source,String.raw`\userglyph`);assert.equal(pasted.document.analysis.facts.customSymbols,1);assert.equal(Object.keys(pasted.document.analysis.symbolAssets).length,1);await layout(target,tr);
 await targetAction({kind:'undo'});assert.equal((await send({op:'inspectEditor',handle:target})).snapshot.document.source,'');await targetAction({kind:'redo'});assert.equal((await send({op:'inspectEditor',handle:target})).snapshot.document.source,String.raw`\userglyph`);
 checks.push('rich clipboard carries the exact frozen definition into a symbol-less session without live identities');
 const bad=structuredClone(symbols[0]);bad.id='unsupported-text';bad.command='usertext';bad.name='Unsupported text artwork';bad.artwork.shapes.push({kind:'text',text:'x',x:0,y:700,fontFamily:'Times New Roman',fontSize:1000});
 const badAnalysis=await send({op:'analyzeCustomSymbol',definition:bad});assert.equal(badAnalysis.asset.geometry.length,0);assert.ok(badAnalysis.asset.diagnostics.some(d=>d.code==='unsupportedArtwork'));
 const badHandle=(await send({op:'createWithSymbols',documentId:'custom-symbol-unsupported',source:String.raw`\usertext`,symbols:[bad]})).handle;const badDoc=(await send({op:'inspectDocument',handle:badHandle})).snapshot;assert.ok(badDoc.analysis.complete&&!badDoc.analysis.supported&&!badDoc.analysis.exportable);await layout(badHandle,0,{},'unsupportedSyntax');
 const changed=structuredClone(symbols[0]);changed.name='same command different frozen resource';await send({op:'createWithSymbols',documentId:'custom-symbol-duplicate',source:'x',symbols:[symbols[0],changed]},'invalidInput');
 checks.push('unsupported artwork and conflicting resource snapshots fail closed without browser-font or partial-shape fallback');
 await send({op:'destroy',handle:badHandle,expectedRevision:0});await send({op:'destroy',handle:target,expectedRevision:tr});await send({op:'destroy',handle:h,expectedRevision:revision});assert.equal((await send({op:'stats'})).activeSessions,0);
 report={status:'PASS',actualNativeExecution:true,actualWasmExecution:true,requests,scenes,maxNumericDifference,exactSvgParity:true,definitions:symbols.length,checks,nativeSha256:sha(readFileSync(nativePath)),wasmSha256:sha(readFileSync(wasmPath)),transcriptSha256:transcript.digest('hex'),fontHashes:expected,notCovered:['Unsupported legacy text/clip/erase/general-stroke artwork remains explicitly unsupported','Real browser keyboard/pointer in this runner','Office']};
}finally{clearTimeout(timer);wasm.free();native.stdin.end();lines.return?.();if(native.exitCode===null)native.kill();}
if(report){writeFileSync(resolve(out,'report.json'),JSON.stringify(report,null,2));console.log(JSON.stringify({receipt:relative(root,resolve(out,'report.json')).replaceAll('\\','/'),...report},null,2));}
