import type {PathOp,Rect,RgbColor,LayoutSnapshot} from './layout';
export interface SymbolMetrics {widthEm:number;ascentEm:number;descentEm:number}
export interface ArtworkPath {path:PathOp[];ink:Rect}
export interface CustomSymbolAsset {
  sha256:string;command:string;role:string;limitsBehavior:'auto'|'limits'|'nolimits';metrics:SymbolMetrics;
  definition:Record<string,unknown>;geometry:ArtworkPath[];
  diagnostics:{shapeIndex:number;code:string;message:string}[];
}
export interface ArtworkInstance {
  nodeId:number;assetSha256:string;pathIndex:number;shape:ArtworkPath;x:number;y:number;scale:number;color?:RgbColor;
}
export type PaintItem={kind:'glyph'|'rule'|'artwork';index:number};
const invalid=():never=>{throw new Error('Invalid custom artwork geometry or paint order');};
const rect=(r:Rect)=>r&&[r.xMin,r.yMin,r.xMax,r.yMax].every(Number.isFinite)&&r.xMax>=r.xMin&&r.yMax>=r.yMin;
const contains=(a:Rect,b:Rect)=>b.xMin>=a.xMin-1e-8&&b.yMin>=a.yMin-1e-8&&b.xMax<=a.xMax+1e-8&&b.yMax<=a.yMax+1e-8;
/** Independent host boundary validation. Nothing from the resource's authored
 * JSON is installed as innerHTML/CSS or put into an SVG attribute directly. */
export function validateArtworkGeometry(scene:LayoutSnapshot):void {
  const artworks=scene.artworks??[],order=scene.paintOrder??[];
  if(!Array.isArray(artworks)||!Array.isArray(order))invalid();
  if(!artworks.length){if(order.length)invalid();return;}
  if(artworks.length>4096||order.length!==scene.glyphs.length+scene.rules.length+artworks.length)invalid();
  const used=new Set<string>();
  for(const item of order){
    const length=item?.kind==='glyph'?scene.glyphs.length:item?.kind==='rule'?scene.rules.length:item?.kind==='artwork'?artworks.length:-1;
    if(!Number.isSafeInteger(item.index)||item.index<0||item.index>=length||used.has(`${item.kind}:${item.index}`))invalid();used.add(`${item.kind}:${item.index}`);
  }
  const frame={xMin:0,yMin:0,xMax:scene.widthEm,yMax:scene.heightEm};let total=0;
  for(const a of artworks){
    if(!a||!/^[0-9a-f]{64}$/u.test(a.assetSha256)||!Number.isSafeInteger(a.pathIndex)||a.pathIndex<0||a.pathIndex>=8192
      ||!Number.isSafeInteger(a.nodeId)||a.nodeId<=0||![a.x,a.y,a.scale].every(Number.isFinite)||a.scale<=0||!a.shape||!rect(a.shape.ink)||!Array.isArray(a.shape.path))invalid();
    total+=a.shape.path.length;if(total>131072)invalid();
    const owner=scene.regions.find(r=>r.nodeId===a.nodeId);if(!owner)throw new Error('Invalid custom artwork geometry or paint order');
    if(owner.role!=='customSymbol')invalid();
    const ownerInk=owner.ink;if(!ownerInk)throw new Error('Invalid custom artwork geometry or paint order');
    if(!rect(ownerInk))invalid();
    const r=a.shape.ink,world={xMin:r.xMin*a.scale+a.x,yMin:r.yMin*a.scale+a.y,xMax:r.xMax*a.scale+a.x,yMax:r.yMax*a.scale+a.y};
    if(!contains(frame,world)||!contains(ownerInk,world))invalid();
    let moved=false;for(const op of a.shape.path){
      if(op.op==='move')moved=true;if(!moved)invalid();
      if(op.op==='close')continue;
      const length=op.op==='move'||op.op==='line'?2:op.op==='quad'?4:op.op==='cubic'?6:-1;
      if(!Array.isArray(op.points)||op.points.length!==length||!op.points.every(v=>Number.isFinite(v)&&Math.abs(v)<=10000))invalid();
      for(let i=0;i<op.points.length;i+=2)if(!contains(r,{xMin:op.points[i],yMin:op.points[i+1],xMax:op.points[i],yMax:op.points[i+1]}))invalid();
    }
  }
}
