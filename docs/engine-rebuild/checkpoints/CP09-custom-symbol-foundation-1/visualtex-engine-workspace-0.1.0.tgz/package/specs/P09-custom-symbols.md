# P09 immutable custom-symbol foundation

Status: implemented foundation; advanced legacy artwork remains explicitly bounded below. This is not a P09-complete claim.

## Ownership

A custom symbol inserted into a formula is bound to an immutable `SymbolAsset` snapshot. The snapshot contains the exact legacy definition JSON, a content SHA-256, math role, limits behavior, metrics and compiled self-owned vector geometry. Rendering never looks up a later same-name library record. A later library change therefore cannot silently alter an existing formula.

The document/session owns a bounded `SymbolCatalog`. Node identity and asset identity are separate. Copy/duplicate allocates fresh mathematical NodeIds but retains the same immutable asset content identity. Rich clipboard may carry the exact frozen definition; the destination validates and freezes it before inserting, and conflicting same-name/different-content resources fail atomically.

## Language and layout

Registered commands are parsed as native `CustomSymbol` nodes. Unknown commands remain unknown; the parser never invents a symbol from a command name alone. Reserved core/VisualTeX commands cannot be shadowed.

Role participates in normal atom spacing. Operator symbols use the existing ordered script/limits tail and may use `auto`, `limits` or `nolimits` as their frozen default. Explicit formula-local limits directives override the default without modifying the asset.

Metrics are authored layout inputs. Artwork is a separate scene resource and never masquerades as a font glyph. Font-size changes scale the natural formula output without rebuilding a different asset.

## Vector safety

Supported vector artwork is parsed and validated by Rust. Raw authored SVG/HTML/CSS is never inserted into the DOM or output SVG. The host independently validates artwork node ownership, SHA format, finite geometry, path bounds and paint order before replacing a visible scene.

Current supported legacy shapes include filled path geometry (M/L/H/V/C/S/Q/T/Z), filled/stroked line, filled/stroked circle, filled ellipse, rectangular geometry, polygon, transforms and color inheritance. All coordinates, segment counts, catalog bytes and retained weight are bounded.

The following existing legacy artwork features are deliberately preserved but not yet promoted to export-ready support in this foundation checkpoint: system-font `text` shapes without an explicit verified font-outline binding, clip rectangles, erase/boolean-subtraction artwork, elliptical-arc path commands, general path/ellipse/polygon stroke offset semantics, rounded rectangles and non-miter rectangle joins. If any retained shape needs one of these features, the whole symbol is marked unsupported and no partial artwork is drawn.

## Clipboard

P09 structural clipboard carries only identity-free structure plus referenced immutable definitions. It does not carry live NodeIds, session handles or document identities. Pasting a custom symbol into a session that does not yet own the asset freezes the included definition first. Same command/id with different asset content is a conflict.

## Acceptance evidence

`custom_symbols_review.rs` covers resource freezing, validation, insertion, source edits, copy/duplicate/history, operator limits, vector scene validation, rich clipboard and fail-closed unsupported artwork.

`custom-symbol-parity-review.mjs` compares Native and actual WASM responses field-by-field for three representative symbol roles, four math styles, two natural sizes, editing/history, rich clipboard and invalid resources.

`custom-symbol-browser-review.mjs` uses an owned Edge instance with real pointer/keyboard/clipboard events, three formula hosts, 27 zoom/DPR artwork-pointer cases, structural insertion and cross-session frozen-asset transfer.

No Office, production application, MathLive or MathJax path is exercised or enabled by this checkpoint.