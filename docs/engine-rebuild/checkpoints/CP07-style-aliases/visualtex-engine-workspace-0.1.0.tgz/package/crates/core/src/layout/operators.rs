//! N-ary glyph selection and side/stacked bounds share font metrics with the
//! existing script engine. The operator owns its glyphs; bounds are child rows.
use std::sync::Arc;
use crate::{error::{EngineError,EngineResult,ErrorCode},model::ScriptKind,
    operators::{self,OperatorMark,OperatorPart},session::NodeId};
use super::{MathStyle,boxes::{Builder,Fragment}};

impl Builder<'_> {
    pub fn large_operator(&mut self,id:NodeId,command:&str,parts:&[OperatorPart],style:MathStyle,cramped:bool,depth:usize)->EngineResult<Fragment>{
        let spec=operators::spec(command).ok_or_else(||EngineError::new(ErrorCode::UnsupportedSyntax,"Unknown large operator"))?;
        let scale=style.scale(self.math);let mut f=Fragment::new(id,"largeOperator");
        match spec.mark {
            OperatorMark::Glyph(ch)=>{
                let (font,gid)=self.math_glyph(ch)?;
                let glyph=font.operator_glyph(gid,style==MathStyle::Display)?;
                let ink=glyph.ink.ok_or_else(||EngineError::new(ErrorCode::InvalidInput,"Operator glyph has no ink"))?;
                let y=(-(ink[1]+ink[3])/2.0-self.math.axis)*scale;
                f.advance=glyph.advance*scale;f.italic=glyph.italic_correction*scale;
                f.glyph(font,glyph,0.0,y,scale);
            }
            OperatorMark::Text(text)=>{
                let run=self.math_font.shape_text(text)?;f.advance=run.advance*scale;
                for g in run.glyphs{f.glyph(self.math_font,g.shape,g.x*scale,g.y*scale,scale);}
            }
        }
        let mut sup:Option<Arc<Fragment>>=None;let mut sub:Option<Arc<Fragment>>=None;
        for slot in operators::slots(parts){
            let b=self.node(&slot.argument,style.script_child(),cramped||slot.script==ScriptKind::Subscript,depth+1)?;
            if slot.script==ScriptKind::Superscript{sup=Some(b);}else{sub=Some(b);}
        }
        if sup.is_none()&&sub.is_none(){return Ok(f);}
        if operators::stacked(spec,operators::effective_mode(parts),style==MathStyle::Display){
            let (width,ascent,descent,italic)=(f.advance,f.ascent,f.descent,f.italic);
            let sx=sup.as_ref().map_or(0.0,|s|(width-s.advance)/2.0+italic/2.0);
            let dx=sub.as_ref().map_or(0.0,|s|(width-s.advance)/2.0-italic/2.0);
            let shift=-sx.min(dx).min(0.0);f.translate_x(shift);
            // Lower-first scene order follows the mathematical edit navigation;
            // y positions, not sequence or source offsets, determine display.
            if let Some(b)=sub{
                let y=descent+(self.math.lower_limit_gap*scale+b.ascent).max(self.math.lower_limit_drop*scale);
                f.child(b,dx+shift,y);
            }
            if let Some(b)=sup{
                let y=ascent+(self.math.upper_limit_gap*scale+b.descent).max(self.math.upper_limit_rise*scale);
                f.child(b,sx+shift,-y);
            }
        }else{
            let (u,v)=self.script_shifts(&f,sup.as_deref(),sub.as_deref(),style,cramped,false);
            let (x,italic)=(f.advance,f.italic);
            if let Some(b)=sub{f.child(b,x,v);}
            if let Some(b)=sup{f.child(b,x+italic,-u);}
            f.advance+=self.math.space_after_script*scale;
        }
        // Following ordinary atoms are spaced as operators by their parent row;
        // an attached upper bound's italic correction is not an operator margin.
        f.italic=0.0;Ok(f)
    }
}
