//! Structure-aware vertical landing. Region preorder is emitted by flatten;
//! source lengths, glyph order and DOM rectangles are never used as anchors.
use std::collections::BTreeSet;
use crate::positions::Position;
use crate::scene::{CaretStop, LayoutSnapshot};
use crate::session::NodeId;

fn node_id(position: Position) -> NodeId {
    match position { Position::Row {node_id,..}|Position::Text {node_id,..}=>node_id }
}
fn subtree_end(scene: &LayoutSnapshot, start: usize) -> usize {
    let depth=scene.regions[start].depth;
    (start+1..scene.regions.len()).find(|i|scene.regions[*i].depth<=depth)
        .unwrap_or(scene.regions.len())
}

/// Prefer a sibling mathematical argument before unrelated geometric neighbors.
/// The root row is not an intermediate editable line between fraction arguments
/// or the upper/lower limits of an operator.
pub(crate) fn fraction_target(scene:&LayoutSnapshot, from:Position, down:bool, desired_x:f64)->Option<Position> {
    let index=scene.regions.iter().position(|r|r.node_id==node_id(from))?;
    let mut ancestors=Vec::new();
    for i in 0..=index {
        let depth=scene.regions[i].depth;
        while ancestors.last().is_some_and(|j:&usize|scene.regions[*j].depth>=depth) {ancestors.pop();}
        ancestors.push(i);
    }
    for &parent in ancestors.iter().rev() {
        if !matches!(scene.regions[parent].role.as_str(),"fraction"|"largeOperator") {continue;}
        let end=subtree_end(scene,parent);
        let direct:Vec<_>=(parent+1..end).filter(|i|scene.regions[*i].depth==scene.regions[parent].depth+1).collect();
        if direct.len()!=2 {continue;}
        // Use the children's actual baselines so authored source order never
        // decides the direction of navigation. This also covers side scripts.
        let baseline=|region:usize|scene.carets.iter().find(|c|node_id(c.position)==scene.regions[region].node_id).map(|c|c.baseline);
        let (a,b)=(direct[0],direct[1]);let (ab,bb)=(baseline(a)?,baseline(b)?);
        let (upper,lower)=if ab<bb{(a,b)}else{(b,a)};
        let contains=|region:usize|index>=region&&index<subtree_end(scene,region);
        let target=if down&&contains(upper){Some(lower)}else if !down&&contains(lower){Some(upper)}else{None};
        let Some(target)=target else {continue;};
        let target_end=subtree_end(scene,target);
        let ids:BTreeSet<_>=scene.regions[target..target_end].iter().map(|r|r.node_id).collect();
        let baseline=scene.carets.iter().find(|c|node_id(c.position)==scene.regions[target].node_id)?.baseline;
        let candidate=scene.carets.iter().filter(|c|ids.contains(&node_id(c.position)) && (c.baseline-baseline).abs()<1e-9)
            .min_by(|a,b| {
                let distance=|c:&CaretStop|(c.x-desired_x).abs();
                distance(a).total_cmp(&distance(b)).then(b.depth.cmp(&a.depth))
            });
        if let Some(candidate)=candidate {return Some(candidate.position);}
    }
    None
}
